%% EXAMPLE 07 — Multi-day cause attribution, end to end
%
% The single-day analysis (example_06) established that the per-rev scale
% anti-correlates with modeled drag — a force-model signature — but a single
% day cannot say WHICH force-model term is wrong. This example runs the full
% multi-day separation the roadmap (section 6) calls for:
%
%   analyzeAccScaleArc  --(per-rev scale + startMJD)-->
%   loadSpaceWeatherIndices  --(F10.7/Kp/... per rev)-->
%   scaleFactorDiagnostics   --> named cause per axis
%
% To stay self-contained it (a) SYNTHESIZES a per-rev result whose axes are
% driven by known causes, and (b) writes a tiny GFZ-format index file so the
% real loader runs. Replace both synthetic blocks with your real multi-day
% run and your downloaded GFZ file (https://kp.gfz.de/en/data,
% Kp_ap_Ap_SN_F107_since_1932.txt).
%
%   Authoring provenance
%     Date   : 2026-07-15
%     Author : Claude (Anthropic), model Claude Opus 4.8

addpath(genpath(fullfile(fileparts(mfilename('fullpath')), '..', 'src')));
rng(2020);

nDays   = 20;
revDay  = 16;                       % ~16 revs/day
R       = nDays * revDay;
startMJD = 58849;                   % 2020-01-01
tMid = ((0:R-1).' + 0.5) * 5400;    % per-rev centers [s from startMJD]

% ---- (A) write a small GFZ index file spanning the arc --------------------
% Real use: download Kp_ap_Ap_SN_F107_since_1932.txt and skip this block.
gfzFile = fullfile(tempdir, 'gfz_example07.txt');
writeSyntheticGfz(gfzFile, startMJD, nDays);

% ---- (B) synthesize a per-rev result (replace with a real run) ------------
% obs   = compose("ACT1B_2020-01-%02d_C_04.txt", 1:nDays);
% model = compose("GRACEFO-1_nonConservativeForces_2020-01-%02d.txt", 1:nDays);
% r     = analyzeAccScaleArc(obs, model, 'Plot', false);
% Here we fabricate r.perRev + r.startMJD, with the X axis driven by F10.7.
k = (0:R-1).';
F107day = 100 + 60*sin(2*pi*k/(revDay*18));         % ~18-day solar rotation
beta    = 35*sin(2*pi*k/(revDay*11));
sX = 0.915 + 0.0011*(F107day-100) + 0.003*randn(R,1);   % density-driven
sY = 1.035 + 0.0018*beta           + 0.003*randn(R,1);  % geometry-driven
sZ = 1.057                         + 0.003*randn(R,1);  % flat / calibrated
r.perRev.tMid    = tMid;
r.perRev.scale   = [sX, sY, sZ];
r.perRev.dragMag = 3e-8 + 1e-8*abs(sin(2*pi*k/revDay));
r.startMJD       = startMJD;

% ---- (C) load indices from the GFZ file and attach orbit geometry ---------
% F10.7/F10.7a/Kp/Ap/SN come straight from the file; beta/argLat are orbit
% geometry you compute yourself (from an orbit file) and pass via 'Extra'.
argLat = mod(k*23, 360);
indices = loadSpaceWeatherIndices(r, 'File', gfzFile, ...
    'Extra', struct('beta', beta, 'argLat', argLat));

% ---- (D) diagnose the cause of the scale on each axis ---------------------
d = scaleFactorDiagnostics(r, indices);

% Expected: X -> DENSITY (tracks F10.7), Y -> GEOMETRY (tracks beta),
%           Z -> unresolved / flat.
fprintf('\nCauses: %s | %s | %s\n', d.axis(1).cause, d.axis(2).cause, d.axis(3).cause);


% ===================================================================
function writeSyntheticGfz(fname, startMJD, nDays)
% Minimal GFZ Kp_ap_Ap_SN_F107 daily file: one line per UT day, 28 fields.
% F10.7obs follows the same ~18-day rotation used to drive the X-axis scale.
fid = fopen(fname, 'w');
fprintf(fid, '# Synthetic GFZ Kp_ap_Ap_SN_F107 file for example_07\n');
fprintf(fid, '#YYY MM DD days days_m BSR dB Kp1..8 ap1..8 Ap SN F107obs F107adj D\n');
base = datenum(1858,11,17) + startMJD;      % datenum of startMJD
for d = 0:nDays-1
    dv = base + d;
    [Y,Mo,Da] = datevec(dv);
    days = dv - datenum(1932,1,1);
    f107 = 100 + 60*sin(2*pi*(d*16)/(16*18));   % daily value at day d
    kp8 = 2 + 1.0*abs(sin(2*pi*(0:7)/8));
    ap8 = round(7 + 4*abs(sin(2*pi*(0:7)/8)));
    Ap = round(mean(ap8)); SN = round(50 + 20*sin(2*pi*d/25));
    fprintf(fid, '%4d %02d %02d %5d %10.5f %4d %2d ', Y,Mo,Da,days,days+0.5,2500,d+1);
    fprintf(fid, '%6.3f ', kp8);
    fprintf(fid, '%4d ', ap8);
    fprintf(fid, '%4d %3d %8.1f %8.1f %d\n', Ap, SN, f107, f107-2, 2);
end
fclose(fid);
end
