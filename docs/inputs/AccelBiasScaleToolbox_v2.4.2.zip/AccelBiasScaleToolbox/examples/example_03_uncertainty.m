%EXAMPLE_03_UNCERTAINTY  Honest error bars.
%
% Naive OLS sigmas on smooth, autocorrelated residuals are typically
% several times too small. Reference experiment (AR(1), rho = 0.95):
% block-bootstrap sigmas were 5.5-6.5x the naive iid sigmas.

[tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair('NoiseRho', 0.9);

[tA, Y1A, Y2A] = alignAccelSeries(tObs, Yobs, tMod, Ymod, 'InterpMethod','pchip');
for j = 1:3
    [Y1A(:,j), Y2A(:,j)] = filterConsistency(tA, Y1A(:,j), Y2A(:,j), ...
        'explicit', 'FilterCoef', truth.filterCoef);
end

spec = struct('ScaleModel','full', ...
    'BiasModel', struct('type','pspline','numInteriorKnots',30,'placement','quantile'));

fit = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, ...
    'Robust',     true, ...
    'NoiseModel', true, ...    % feasible GLS with an AR noise model
    'Bootstrap',  true, ...    % moving-block CIs on top
    'NumBoot',    300);

for i = 1:3
    nm = fit.axis(i).noiseModel;
    fprintf('axis %d: %s, n_eff/n = %.2f, sigma inflation = %.1fx\n', ...
        i, nm.verdict, nm.nEffRatio, mean(fit.axis(i).sigmaInflation));
    fprintf('        scale = %.4f, bootstrap 95%% CI = [%.4f, %.4f]\n', ...
        fit.S(i,i), fit.axis(i).boot.ci(end,1), fit.axis(i).boot.ci(end,2));
end

% Compare against the truth the generator injected:
disp([diag(fit.S), truth.scales]);
