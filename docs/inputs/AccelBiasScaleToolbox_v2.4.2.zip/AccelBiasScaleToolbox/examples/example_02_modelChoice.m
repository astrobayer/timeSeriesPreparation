%EXAMPLE_02_MODELCHOICE  Choose the bias/scale parameterization by blocked CV.

[tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair();

specs = {};

specs{end+1} = struct('label','diag / const', ...
    'ScaleModel','diagonal', 'BiasModel', struct('type','constant'));

specs{end+1} = struct('label','diag / poly3', ...
    'ScaleModel','diagonal', 'BiasModel', struct('type','polynomial','order',3));

specs{end+1} = struct('label','diag / pspline', ...
    'ScaleModel','diagonal', ...
    'BiasModel', struct('type','pspline','numInteriorKnots',30,'placement','quantile'));

specs{end+1} = struct('label','full / pspline', ...
    'ScaleModel','full', ...
    'BiasModel', struct('type','pspline','numInteriorKnots',30,'placement','quantile'));

% Custom coupling mask: only the cross-terms you believe are physical
% mask = [true true false; true true false; false false true];
% specs{end+1} = struct('label','mask / pspline', 'ScaleModel', mask, ...
%     'BiasModel', struct('type','pspline','numInteriorKnots',30));

cmp = accelBiasScaleModelCompare(tObs, Yobs, tMod, Ymod, specs, ...
    'InterpMethod',   'pchip', ...
    'FilterStrategy', 'explicit', ...     % use the REAL ACC1B coefficients here
    'FilterCoef',     truth.filterCoef, ...
    'NumFolds',       5, ...
    'PlotDiagnostics', true);

disp(cmp.table);   % ranked by CV_RSS -- NOT by AIC/BIC, which are invalid here

% Physical decomposition of the winning model's scale matrix:
best = cmp.fits{find(strcmp(cmp.labels, cmp.table.Model{1}), 1)};
disp(best.decomp.anglesUrad);   % misalignment [urad]
disp(best.decomp.scales);       % per-axis scale factors
disp(best.decomp.nonOrtho);     % non-orthogonality
