%EXAMPLE_06_SINGLECALLREALDATA  One call, real GRACE-FO data, single or multi-day.
%
% Point these at real files. The wrapper reads them (via the user's L1B
% readers + the GROOPS reader), reconciles the time systems, makes the
% model CRN-consistent, and returns per-axis scale factors with honest
% uncertainty, a drift/drag diagnosis, and a plain-language interpretation.

% --- single day ---
r = analyzeAccScaleArc( ...
    'ACT1B_2020-01-01_C_04.txt', ...
    'GRACEFO-1_nonConservativeForces_2020-01-01.txt', ...
    'Product', 'ACC', 'FilterModel', true, 'Plot', true);

disp(r.interpretation');
fprintf('\nScale: X %.3f  Y %.3f  Z %.3f\n', r.scaleGlobal);
fprintf('Drag correlation: X %+.2f  Y %+.2f  Z %+.2f\n', r.dragCorr);

% --- multi-day arc: just pass lists (chronological order) ---
% obs   = compose("ACT1B_2020-01-%02d_C_04.txt", 1:31);
% model = compose("GRACEFO-1_nonConservativeForces_2020-01-%02d.txt", 1:31);
% r = analyzeAccScaleArc(obs, model, 'Save', 'jan2020_calibration.mat');
%
% With many days spanning varied space weather, r.dragCorr and the per-rev
% scale become separable into density-model vs Cd vs sensor-drift causes.
