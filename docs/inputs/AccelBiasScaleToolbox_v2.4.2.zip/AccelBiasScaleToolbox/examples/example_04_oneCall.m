%EXAMPLE_04_ONECALL  The recommended entry point: one call, all defaults.

[tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair('NoiseRho', 0.85);

out = analyzeAccArc(tObs, Yobs, tMod, Ymod, ...
    'FilterStrategy',    'explicit', ...   % exact ATBD CRN kernel
    'ScaleModel',        'full', ...
    'TimeVaryingScale',  'auto', ...       % fit s(t) only if drift is indicated
    'Bootstrap',         true, ...
    'Save',              'arc_calibration.mat');

disp(out.summary);
disp(out.flags');

% ingest later, in the adjustment:
cal = accelCalibrationIO('load', 'arc_calibration.mat');
S   = cal.S;                 % the scale/coupling matrix
fprintf('filter DC gain used: %.7f\n', cal.provenance.meta.filterDCGain);
