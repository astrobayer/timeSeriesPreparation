%EXAMPLE_01_PREFLIGHT  Preflight an observed/modeled acceleration pair.
%
% Start here. This runs no adjustment: it only tells you what would go
% wrong if you did, and why.

% --- your data ---
% tObs, Yobs : ACC1B epochs and Nx3 accelerations
% tMod, Ymod : satforce epochs and Kx3 accelerations (own sampling)
%
% For a runnable demo, generate a synthetic pair with known truth:
[tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair();

report = accelSeriesPreflight(tObs, Yobs, tMod, Ymod, ...
    'InterpMethod',   'pchip', ...      % NOT 'linear': it attenuates and biases scale
    'FilterStrategy', 'commonmode', ... % ACC1B is filtered; the model is not
    'FilterCutoff',   0.02, ...
    'PlotDiagnostics', true);

% The flag list is the headline output.
for k = 1:numel(report.axis)
    fprintf('\n--- axis %d ---\n', k);
    fprintf('  scale observable over arc : %d\n', report.axis(k).observability.observable);
    fprintf('  windows w/ unidentifiable scale : %d / %d\n', ...
        report.axis(k).slidingFit.nUnobservable, report.axis(k).slidingFit.nWindows);
    fprintf('  residual noise : %s (n_eff/n = %.2f)\n', ...
        report.axis(k).noiseModel.verdict, report.axis(k).noiseModel.nEffRatio);
    disp(report.axis(k).flags');
end

% READ THIS FIRST: if a large fraction of windows report an unidentifiable
% scale, then a scale factor that "varies wildly" in your full adjustment is
% an estimation artifact, not physics -- and constraining it near 1 hides the
% symptom rather than fixing the cause.
