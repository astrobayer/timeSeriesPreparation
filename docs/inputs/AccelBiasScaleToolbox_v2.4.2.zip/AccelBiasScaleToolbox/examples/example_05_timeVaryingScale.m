%EXAMPLE_05_TIMEVARYINGSCALE  When the scale drifts: fit s(t), read its band.

[tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair('NoiseStd', 0.005);

% filter-consistent, single axis
h = crnFilter('ACC');
[tA, Y1A, Y2A] = alignAccelSeries(tObs, Yobs, tMod, Ymod, 'InterpMethod','pchip');
[y1, y2] = filterConsistency(tA, Y1A(:,1), Y2A(:,1), 'explicit', 'FilterCoef', h);

% down-weight CRN-contaminated segment ends
w = flagEdgeEffects(tA, h);

tv = accelTimeVaryingScaleFit(tA, y1, y2, ...
    'BiasKnots', 30, 'ScaleKnots', 3, 'Weights', w);

fprintf('scale mean %.5f, drift %.5f (SNR %.1f)\n', ...
    tv.scaleMean, tv.scaleDrift, tv.scaleDriftSNR);
if tv.isDriftSignificant
    fprintf('  -> drift is RESOLVED: a static scale is inadequate for this axis.\n');
else
    fprintf('  -> drift within uncertainty: a static scale is fine; do not over-read s(t).\n');
end

% s(t) with its 1-sigma band is in tv.scale / tv.scaleSigma
