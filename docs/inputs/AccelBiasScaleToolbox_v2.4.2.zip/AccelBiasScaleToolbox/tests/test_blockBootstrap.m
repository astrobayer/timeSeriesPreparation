classdef test_blockBootstrap < matlab.unittest.TestCase
%TEST_BLOCKBOOTSTRAP  Unit tests for blockBootstrap.m
%   Python reference (AR(1) rho=0.95, n=1000, blockLen=100): bootstrap
%   sigmas exceeded the naive iid sigmas by a factor of 5.5-6.5.

    methods (Test)

        function inflatesSigmaUnderColoredNoise(tc)
            rng(1);
            n = 1000;
            t = linspace(0,100,n)';
            X = [ones(n,1), sin(0.3*t)];
            nz = zeros(n,1); e = 0.1*randn(n,1);
            for k = 2:n, nz(k) = 0.95*nz(k-1) + e(k); end
            y = X*[0.5;2.0] + nz;

            bs = blockBootstrap(X, y, 'NumBoot', 200, 'BlockLen', 100, 'Seed', 1);

            % the naive iid bootstrap/OLS would say the error bars are tiny;
            % the block bootstrap must say otherwise
            tc.verifyGreaterThan(mean(bs.inflation), 2);
        end

        function agreesWithNaiveSigmaUnderWhiteNoise(tc)
            rng(2);
            n = 800;
            X = [ones(n,1), randn(n,1)];
            y = X*[1;2] + 0.5*randn(n,1);
            bs = blockBootstrap(X, y, 'NumBoot', 200, 'BlockLen', 10, 'Seed', 2);
            % with white noise, blocking buys nothing: inflation ~ 1
            tc.verifyEqual(mean(bs.inflation), 1, 'AbsTol', 0.35);
        end

        function confidenceIntervalCoversTruth(tc)
            rng(3);
            n = 1000;
            t = linspace(0,100,n)';
            X = [ones(n,1), sin(0.3*t)];
            beta = [0.5; 2.0];
            nz = zeros(n,1); e = 0.05*randn(n,1);
            for k = 2:n, nz(k) = 0.8*nz(k-1) + e(k); end
            y = X*beta + nz;

            bs = blockBootstrap(X, y, 'NumBoot', 300, 'Seed', 3);
            for j = 1:2
                tc.verifyGreaterThanOrEqual(beta(j), bs.ci(j,1));
                tc.verifyLessThanOrEqual(   beta(j), bs.ci(j,2));
            end
        end

        function blockLengthDerivedFromCorrelationLength(tc)
            rng(4);
            n = 2000;
            X = [ones(n,1), randn(n,1)];
            nz = zeros(n,1); e = randn(n,1);
            for k = 2:n, nz(k) = 0.9*nz(k-1) + e(k); end
            y = X*[1;1] + nz;

            bs = blockBootstrap(X, y, 'NumBoot', 50, 'Seed', 4);
            % correlated residuals => a non-trivial block length is chosen
            tc.verifyGreaterThan(bs.blockLen, 10);
            tc.verifyLessThanOrEqual(bs.blockLen, n/5 + 1);
        end

        function reproducibleWithSeed(tc)
            X = [ones(200,1), (1:200)'];
            y = X*[1;0.01] + 0.1*randn(200,1);
            b1 = blockBootstrap(X, y, 'NumBoot', 50, 'Seed', 99);
            b2 = blockBootstrap(X, y, 'NumBoot', 50, 'Seed', 99);
            tc.verifyEqual(b1.sigma, b2.sigma, 'AbsTol', 1e-12);
        end

    end
end
