classdef test_scaleObservability < matlab.unittest.TestCase
%TEST_SCALEOBSERVABILITY  Unit tests for scaleObservability.m
%   This is the diagnostic that explains a "stable bias, wild scale"
%   pattern as an estimation artifact rather than physics.

    methods (Test)

        function constantRegressorIsUnobservable(tc)
            obs = scaleObservability(ones(200,1));
            tc.verifyFalse(obs.observable);
            tc.verifyGreaterThan(numel(obs.reason), 0);
        end

        function lowDynamicRangeIsUnobservable(tc)
            % a nearly constant drag signal: bias and scale are collinear
            t = linspace(0,10,500)';
            yMod = 1 + 0.001*sin(t);          % std/|mean| = 1e-3
            obs = scaleObservability(yMod);
            tc.verifyFalse(obs.observable);
            tc.verifyLessThan(obs.relRange, 0.05);
        end

        function healthyDynamicRangeIsObservable(tc)
            t = linspace(0,100,1000)';
            yMod = 1 + 0.8*sin(t);            % large excursions
            obs = scaleObservability(yMod);
            tc.verifyTrue(obs.observable);
            tc.verifyLessThan(obs.cond, 100);
        end

        function demeaningDecorrelatesBiasAndScale(tc)
            t = linspace(0,10,500)';
            yMod = 10 + 0.5*sin(t);           % large nonzero mean

            obsRaw = scaleObservability(yMod, 'Demean', false);
            obsDem = scaleObservability(yMod, 'Demean', true);

            % without centering, bias and scale trade off almost exactly;
            % centering makes the two design columns orthogonal
            tc.verifyGreaterThan(abs(obsRaw.biasScaleCorr), 0.95);
            tc.verifyLessThan(abs(obsDem.biasScaleCorr), 1e-8);
            tc.verifyLessThan(obsDem.cond, obsRaw.cond);
        end

        function scaleVarianceIsAmplifiedWhenIllConditioned(tc)
            t = linspace(0,10,500)';
            yQuiet = 1 + 0.002*sin(t);
            yLively = 1 + 0.9*sin(t);
            oQ = scaleObservability(yQuiet,  'Demean', false);
            oL = scaleObservability(yLively, 'Demean', false);
            tc.verifyGreaterThan(oQ.scaleVarFactor, oL.scaleVarFactor);
        end

        function acceptsAnExplicitBiasDesign(tc)
            t = linspace(0,10,300)';
            B = bsplineBasis(t, 5, 4);
            yMod = 1 + 0.5*sin(t);
            obs = scaleObservability(yMod, 'BiasDesign', B);
            tc.verifyTrue(isfinite(obs.cond));
            tc.verifyTrue(isfinite(obs.biasScaleCorr));
        end

        function zeroMeanRegressorIsWellPosed(tc)
            t = linspace(0,10,400)';
            s = sin(t);
            obs = scaleObservability(s - mean(s));   % genuinely zero-mean
            tc.verifyTrue(obs.observable);
            tc.verifyEqual(obs.relRange, Inf);
        end

    end
end
