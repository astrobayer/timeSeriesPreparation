classdef test_analyzeAccScaleArc < matlab.unittest.TestCase
%TEST_ANALYZEACCSCALEARC  Integration tests for the single-call wrapper.
%   Writes small synthetic ACC1B + GROOPS files with a KNOWN injected
%   scale, and checks the wrapper recovers it end to end.

    properties
        workDir
    end

    methods (TestMethodSetup)
        function makeWorkDir(tc)
            tc.workDir = tempname; mkdir(tc.workDir);
            tc.addTeardown(@() rmdir(tc.workDir,'s'));
        end
    end

    methods (Access = private)
        function [obsF, modF, truth] = writePair(tc, day, scale, noiseStd, noiseRho)
            % one day of synthetic data at model 10 s / obs 1 s.
            % noiseStd/noiseRho (optional) add AR(1) coloured noise to the
            % OBSERVED series; default 0 => clean data (most tests rely on
            % clean data to hit tight tolerances).
            if nargin < 4 || isempty(noiseStd), noiseStd = 0; end
            if nargin < 5 || isempty(noiseRho), noiseRho = 0; end
            Torb = 5400; fs = 1;
            nSec = 86400;
            tsec = (0:nSec-1)';
            % modeled non-grav accel: orbital signal + higher harmonic
            frev = 1/Torb;
            base = @(a,ph) a.*sin(2*pi*frev*tsec+ph);
            Amod = [1.5e-8*sin(2*pi*frev*tsec) + 0.4e-8*sin(4*pi*frev*tsec), ...
                    1.3e-8*cos(2*pi*frev*tsec) + 0.3e-8*sin(4*pi*frev*tsec), ...
                    0.8e-8*sin(2*pi*frev*tsec + 1)];
            bias = [-3e-7, -1.1e-5, -1.6e-7];
            Aobs = bias + Amod .* scale;   % inject known diagonal scale
            if noiseStd > 0
                % AR(1) coloured noise per axis: e_k = rho*e_{k-1} + w_k
                for j = 1:3
                    e = zeros(nSec,1);
                    w = noiseStd * randn(nSec,1);
                    for k = 2:nSec
                        e(k) = noiseRho*e(k-1) + w(k);
                    end
                    Aobs(:,j) = Aobs(:,j) + e;
                end
            end

            % write GROOPS model at 10 s
            mjd0 = 58849 + (day-1);
            idx10 = 1:10:nSec;
            modF = fullfile(tc.workDir, sprintf('model_%02d.txt', day));
            fid = fopen(modF,'w');
            fprintf(fid,'groops instrument version=20200123\n# ACCELEROMETER\n  -8   1\n');
            fprintf(fid,'# Time [MJD]  data0: x [m/s^2]  data1: y [m/s^2]  data2: z [m/s^2]\n# =====\n');
            fprintf(fid,'%d\n', numel(idx10));
            for k = idx10
                fprintf(fid,'%.12f %.12e %.12e %.12e\n', ...
                    mjd0 + (tsec(k))/86400, Amod(k,1), Amod(k,2), Amod(k,3));
            end
            fclose(fid);

            % write ACC1B-like observed at 1 s
            gps0 = (mjd0 - 51544)*86400 - 43200;  % gps_time of this day's 00:00
            obsF = fullfile(tc.workDir, sprintf('ACC1B_%02d.txt', day));
            fid = fopen(obsF,'w');
            fprintf(fid,'header:\n  variable_descriptions:\n');
            fprintf(fid,'    - name: gps_time\n      units: second\n');
            fprintf(fid,'    - name: GRACEFO_id\n      units: char\n');
            fprintf(fid,'    - name: lin_accl_x\n      units: m/s^2\n');
            fprintf(fid,'    - name: lin_accl_y\n      units: m/s^2\n');
            fprintf(fid,'    - name: lin_accl_z\n      units: m/s^2\n');
            fprintf(fid,'    - name: qualflg\n      units: char\n');
            fprintf(fid,'# End of YAML header\n');
            for k = 1:nSec
                fprintf(fid,'%d C %.10e %.10e %.10e 00000000\n', ...
                    gps0 + tsec(k), Aobs(k,1), Aobs(k,2), Aobs(k,3));
            end
            fclose(fid);

            truth.scale = scale;
        end
    end

    methods (Test)

        function recoversInjectedScaleSingleDay(tc)
            [obsF, modF, truth] = tc.writePair(1, [0.92 1.03 1.05]);
            r = analyzeAccScaleArc(obsF, modF, ...
                'FilterModel', false, ...   % synthetic obs is not CRN-filtered
                'Plot', false, 'Verbose', false);
            tc.verifyEqual(r.scaleGlobal, truth.scale, 'AbsTol', 0.02);
            tc.verifyEqual(r.nDays, 1);
        end

        function multiDayConcatenates(tc)
            [o1,m1] = tc.writePair(1, [0.95 1.02 1.04]);
            [o2,m2] = tc.writePair(2, [0.95 1.02 1.04]);
            r = analyzeAccScaleArc([string(o1) string(o2)], [string(m1) string(m2)], ...
                'FilterModel', false, 'Plot', false, 'Verbose', false);
            tc.verifyGreaterThanOrEqual(r.nRevs, 25);   % ~32 revs/day
            tc.verifyEqual(r.scaleGlobal, [0.95 1.02 1.04], 'AbsTol', 0.02);
        end

        function producesInterpretationAndFlags(tc)
            [obsF, modF] = tc.writePair(1, [0.92 1.03 1.05]);
            r = analyzeAccScaleArc(obsF, modF, ...
                'FilterModel', false, 'Plot', false, 'Verbose', false);
            tc.verifyEqual(numel(r.interpretation), 3);
            tc.verifyClass(r.flags, 'cell');
            % single-day caveat must be present
            tc.verifyTrue(any(contains(r.flags, 'Single day')));
        end

        function reportsSigmaInflation(tc)
            rng(7);
            % inject AR(1) coloured noise so the residual is genuinely
            % autocorrelated; only then does block-bootstrap sigma exceed the
            % naive iid sigma (the effect this field is meant to report).
            [obsF, modF] = tc.writePair(1, [1 1 1], 3e-9, 0.98);
            r = analyzeAccScaleArc(obsF, modF, ...
                'FilterModel', false, 'Plot', false, 'Verbose', false);
            tc.verifyGreaterThan(max(r.sigmaInflation), 1.5);
        end

        function returnsInputAccelerations(tc)
            % .accel must expose both series on the common analysis grid,
            % with matching lengths and 3 axes each.
            scale = [0.92 1.03 1.05];
            [obsF, modF] = tc.writePair(1, scale);
            r = analyzeAccScaleArc(obsF, modF, ...
                'FilterModel', false, 'Plot', false, 'Verbose', false);
            tc.verifyTrue(isfield(r, 'accel'));
            n = r.nSamples;
            tc.verifySize(r.accel.t,     [n 1]);
            tc.verifySize(r.accel.obs,   [n 3]);
            tc.verifySize(r.accel.model, [n 3]);
            tc.verifyEqual(numel(r.accel.axisNames), 3);
            tc.verifyFalse(r.accel.filtered);           % FilterModel=false
            tc.verifyTrue(all(isfinite(r.accel.obs(:))));
            tc.verifyTrue(all(isfinite(r.accel.model(:))));
        end

        function correctionReconstructsObservation(tc)
            % modelToObs.apply on the returned model must reproduce the
            % returned observation to within the fit residual (synthetic
            % data is essentially noise-free here).
            scale = [0.92 1.03 1.05];
            [obsF, modF] = tc.writePair(1, scale);
            r = analyzeAccScaleArc(obsF, modF, ...
                'FilterModel', false, 'Plot', false, 'Verbose', false);
            tc.verifyTrue(isfield(r, 'correction'));

            c = r.correction;
            % fitted scale/bias match the top-level scale and truth
            tc.verifyEqual(c.scale, r.scaleGlobal, 'AbsTol', 1e-12);
            tc.verifyEqual(c.scale, scale, 'AbsTol', 0.02);
            tc.verifyEqual(c.scalePpm, (c.scale-1)*1e6, 'RelTol', 1e-9);

            % model -> obs prediction reproduces the observation
            pred = c.modelToObs.apply(r.accel.model);
            tc.verifyEqual(pred, r.accel.obs, ...
                'AbsTol', 6*max(c.residualStd) + 1e-12);

            % obs -> model correction inverts it (round-trip identity)
            back = c.obsToModel.apply(r.accel.obs);
            fwd  = c.modelToObs.apply(back);
            tc.verifyEqual(fwd, r.accel.obs, 'AbsTol', 1e-9*max(abs(r.accel.obs(:))) + eps);

            % obs->model factors are the exact inverse of the forward ones
            tc.verifyEqual(c.obsToModel.scaleFactor, 1./c.scale, 'RelTol', 1e-12);
            tc.verifyEqual(c.obsToModel.biasOffset, -c.bias./c.scale, 'RelTol', 1e-12);
        end

        function correctionRoundTripRecoversModel(tc)
            % (y_obs - bias)./S must recover y_mod for clean data.
            scale = [0.90 1.00 1.10];
            [obsF, modF] = tc.writePair(1, scale);
            r = analyzeAccScaleArc(obsF, modF, ...
                'FilterModel', false, 'Plot', false, 'Verbose', false);
            recoveredModel = r.correction.obsToModel.apply(r.accel.obs);
            tol = 6*max(r.correction.residualStd) ...
                  ./ min(r.correction.scale) + 1e-12;
            tc.verifyEqual(recoveredModel, r.accel.model, 'AbsTol', tol);
        end

        function stampsProvenance(tc)
            % run-time provenance + authoring stamp must be present.
            [obsF, modF] = tc.writePair(1, [1 1 1]);
            r = analyzeAccScaleArc(obsF, modF, ...
                'FilterModel', false, 'Plot', false, 'Verbose', false);
            tc.verifyTrue(isfield(r, 'provenance'));
            p = r.provenance;
            tc.verifyClass(p.runDatetime, 'char');
            tc.verifyGreaterThan(p.runDatenum, datenum(2020,1,1));
            tc.verifyEqual(p.toolbox, 'AccelBiasScaleToolbox');
            tc.verifyTrue(contains(p.claudeVersion, 'Claude'));
        end

        function savesResult(tc)
            [obsF, modF] = tc.writePair(1, [0.9 1.0 1.1]);
            sf = fullfile(tc.workDir, 'cal.mat');
            analyzeAccScaleArc(obsF, modF, 'FilterModel', false, ...
                'Plot', false, 'Verbose', false, 'Save', sf);
            tc.verifyTrue(isfile(sf));
            cal = accelCalibrationIO('load', sf);
            tc.verifyEqual(diag(cal.S)', [0.9 1.0 1.1], 'AbsTol', 0.03);
        end

    end
end
