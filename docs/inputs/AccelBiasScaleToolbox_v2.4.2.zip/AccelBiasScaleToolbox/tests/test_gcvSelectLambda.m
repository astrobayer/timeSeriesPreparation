classdef test_gcvSelectLambda < matlab.unittest.TestCase
%TEST_GCVSELECTLAMBDA  Unit tests for gcvSelectLambda.m
%   Python reference on the smooth-truth + white-noise case: GCV selected
%   edf = 13.4 from an over-rich 34-parameter basis, achieving RMSE 0.0075
%   vs the truth, against 0.0125 for the unpenalized fit.

    methods (Test)

        function pSplineBeatsUnpenalizedOverRichBasis(tc)
            rng(42);
            t = linspace(0, 100, 400)';
            truth = 0.5*sin(2*pi*t/80) + 0.01*t;
            y = truth + 0.05*randn(size(t));

            B = bsplineBasis(t, 30, 4, 'uniform');
            P = diffPenaltyMatrix(size(B,2), 2);

            [~, out] = gcvSelectLambda(B, y, P);
            rmsePen = sqrt(mean((B*out.coef - truth).^2));

            coefUn = B \ y;
            rmseUn = sqrt(mean((B*coefUn - truth).^2));

            tc.verifyLessThan(rmsePen, rmseUn);
            tc.verifyLessThan(rmsePen, 0.02);
        end

        function edfDecreasesWithLambda(tc)
            t = linspace(0,10,200)';
            B = bsplineBasis(t, 20, 4);
            P = diffPenaltyMatrix(size(B,2), 2);
            y = sin(t) + 0.01*randn(size(t));

            [~, out] = gcvSelectLambda(B, y, P, [1e-6 1e0 1e6]);
            % more smoothing => fewer effective parameters, monotonically
            tc.verifyGreaterThan(out.edf(1), out.edf(2));
            tc.verifyGreaterThan(out.edf(2), out.edf(3));
        end

        function heavyPenaltyApproachesLinearFit(tc)
            % with d=2 the null space is {const, linear}, so lambda -> inf
            % must converge to a straight line, NOT to zero
            t = linspace(0,10,200)';
            B = bsplineBasis(t, 20, 4);
            P = diffPenaltyMatrix(size(B,2), 2);
            truthLine = 2 + 0.5*t;
            y = truthLine;

            [~, out] = gcvSelectLambda(B, y, P, 1e10);
            fitted = B*out.coef;
            tc.verifyEqual(fitted, truthLine, 'AbsTol', 1e-3);
        end

        function edfAtOptimumIsLessThanParameterCount(tc)
            rng(1);
            t = linspace(0,50,300)';
            B = bsplineBasis(t, 25, 4);
            P = diffPenaltyMatrix(size(B,2), 2);
            y = sin(t/5) + 0.1*randn(size(t));
            [~, out] = gcvSelectLambda(B, y, P);
            tc.verifyLessThan(out.edfOpt, size(B,2));
            tc.verifyGreaterThan(out.edfOpt, 2);
        end

    end
end
