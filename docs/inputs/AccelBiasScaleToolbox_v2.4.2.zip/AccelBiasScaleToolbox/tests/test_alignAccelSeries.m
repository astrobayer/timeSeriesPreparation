classdef test_alignAccelSeries < matlab.unittest.TestCase
%TEST_ALIGNACCELSERIES  Unit tests for alignAccelSeries.m

    methods (Test)

        function identicalGridsAlignExactly(tc)
            t = (0:0.1:10)';
            Y1 = [sin(t), cos(t)];
            Y2 = Y1 + 0.01;
            [tA, Y1A, Y2A, info] = alignAccelSeries(t, Y1, t, Y2);
            tc.verifyEqual(numel(tA), numel(t));
            tc.verifyEqual(info.nCommonSamples, numel(t));
            tc.verifyEqual(Y1A, Y1, 'AbsTol', 1e-12);
            tc.verifyEqual(Y2A, Y2, 'AbsTol', 1e-8);
        end

        function differentSamplingInterpolates(tc)
            t1 = (0:0.1:10)';
            t2 = (0:0.05:10)';
            [~, Y1A, Y2A] = alignAccelSeries(t1, sin(t1), t2, sin(t2));
            tc.verifyEqual(Y1A, Y2A, 'AbsTol', 1e-4);
        end

        function pchipPreservesAmplitudeBetterThanLinear(tc)
            % linear interpolation chords across each interval, shrinking
            % amplitude -- a shrinkage the SCALE parameter then absorbs
            t2 = (0:0.5:100)';            % coarse model grid
            t1 = (0:0.1:100)';            % fine observation grid
            y2 = sin(t2);
            truth = sin(t1);

            [~, ~, yLin]   = alignAccelSeries(t1, truth, t2, y2, 'linear', 10);
            [~, ~, yPchip] = alignAccelSeries(t1, truth, t2, y2, 'pchip',  10);

            errLin   = std(yLin   - truth);
            errPchip = std(yPchip - truth);
            tc.verifyLessThan(errPchip, errLin);

            % and the induced scale bias is smaller with pchip
            sLin   = (yLin'*truth)   / (yLin'*yLin);
            sPchip = (yPchip'*truth) / (yPchip'*yPchip);
            tc.verifyLessThan(abs(sPchip - 1), abs(sLin - 1));
        end

        function largeGapDropsSamples(tc)
            t1 = (0:1:100)';
            t2 = [(0:1:40), (60:1:100)]';
            [tA, ~, ~, info] = alignAccelSeries(t1, ones(size(t1)), t2, ones(size(t2)), ...
                'linear', 2);
            tc.verifyLessThan(numel(tA), numel(t1));
            tc.verifyGreaterThan(info.droppedFraction, 0);
        end

        function jointAcrossAxes(tc)
            % an epoch is kept only if EVERY model column is valid there
            t1 = (0:1:20)';
            t2 = (0:1:20)';
            Y1 = ones(21,3);
            Y2 = ones(21,3);
            Y2(10,2) = NaN;
            [tA, ~, Y2A] = alignAccelSeries(t1, Y1, t2, Y2);
            tc.verifyFalse(any(isnan(Y2A(:))));
            tc.verifyLessThan(numel(tA), 21);
        end

        function nameValueAndPositionalFormsAgree(tc)
            t = (0:0.5:20)';
            Y1 = sin(t); Y2 = cos(t);
            [~,~,a] = alignAccelSeries(t, Y1, t, Y2, 'pchip', 5);
            [~,~,b] = alignAccelSeries(t, Y1, t, Y2, 'InterpMethod','pchip','MaxInterpGap',5);
            tc.verifyEqual(a, b, 'AbsTol', 1e-12);
        end

        function nearestNeighbourScreenIsCorrect(tc)
            t1 = [0; 5; 50];
            t2 = [0; 5; 10];
            [tA, ~, ~] = alignAccelSeries(t1, ones(3,1), t2, ones(3,1), 'linear', 3);
            % t1 = 50 is 40 away from the nearest model sample => dropped
            tc.verifyEqual(tA, [0; 5], 'AbsTol', 1e-12);
        end

    end
end
