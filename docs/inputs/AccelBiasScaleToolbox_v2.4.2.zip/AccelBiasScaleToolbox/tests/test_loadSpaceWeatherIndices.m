classdef test_loadSpaceWeatherIndices < matlab.unittest.TestCase
%TEST_LOADSPACEWEATHERINDICES  Unit tests for the GFZ index loader.
%   Writes a small synthetic GFZ Kp_ap_Ap_SN_F107 daily file with KNOWN
%   values and checks the loader parses it and maps the indices onto
%   per-rev windows correctly.
%
%   Authoring provenance
%     Date   : 2026-07-15
%     Author : Claude (Anthropic), model Claude Opus 4.8

    properties
        workDir
        gfzFile
        startMJD = 58849            % 2020-01-01
    end

    methods (TestMethodSetup)
        function makeFile(tc)
            tc.workDir = tempname; mkdir(tc.workDir);
            tc.addTeardown(@() rmdir(tc.workDir,'s'));
            tc.gfzFile = fullfile(tc.workDir, 'gfz.txt');
            tc.writeGfz(tc.gfzFile);
        end
    end

    methods (Access = private)
        function writeGfz(~, fname)
            % 5 consecutive days from 2020-01-01, with a KNOWN daily-ramping
            % F10.7 and a distinctive Kp diurnal shape.
            fid = fopen(fname, 'w');
            % header (a few '#' lines; loader counts them, count is not checked)
            fprintf(fid, '# GFZ Kp_ap_Ap_SN_F107 synthetic test file\n');
            fprintf(fid, '#YYY MM DD days days_m BSR dB Kp1..8 ap1..8 Ap SN F107obs F107adj D\n');
            base = datenum(2020,1,1);
            for d = 0:4
                dv = base + d;
                [Y,Mo,Da] = datevec(dv);
                days = dv - datenum(1932,1,1);
                kp8 = 1.0 + 0.25*(0:7);              % 1.00 .. 2.75 within a day
                ap8 = round(4 + 2*(0:7));
                Ap  = round(mean(ap8));
                SN  = 10 + d;
                f107obs = 70 + 5*d;                  % 70,75,80,85,90
                f107adj = f107obs - 2;
                fprintf(fid, '%4d %02d %02d %5d %10.5f %4d %2d ', ...
                    Y, Mo, Da, days, days+0.5, 2500, d+1);
                fprintf(fid, '%6.3f ', kp8);
                fprintf(fid, '%4d ', ap8);
                fprintf(fid, '%4d %3d %8.1f %8.1f %d\n', Ap, SN, f107obs, f107adj, 2);
            end
            fclose(fid);
        end
    end

    methods (Test)

        function parsesDailyTable(tc)
            [~, raw] = loadSpaceWeatherIndices(tc.gfzFile, (0:31).'*5400, ...
                tc.startMJD, 'Verbose', false);
            tc.verifyEqual(numel(raw.mjd), 5);
            tc.verifyEqual(raw.mjd(1), tc.startMJD);           % 2020-01-01
            tc.verifyEqual(raw.F107obs.', [70 75 80 85 90], 'AbsTol', 1e-6);
            tc.verifyEqual(raw.F107adj.', [68 73 78 83 88], 'AbsTol', 1e-6);
            tc.verifySize(raw.Kp8, [5 8]);
            tc.verifyEqual(raw.Kp8(1,:), 1.0+0.25*(0:7), 'AbsTol', 1e-6);
        end

        function mapsF107OntoRevs(tc)
            % 15 revs on day 0 (15*5400 s < 86400) must all sample the
            % day-0 F10.7 value (70), held across the whole UT day
            tMid = ((1:15).' - 0.5) * 5400;         % all within first UT day
            ix = loadSpaceWeatherIndices(tc.gfzFile, tMid, tc.startMJD, ...
                'Verbose', false, 'DailyInterp', 'nearest');
            tc.verifyEqual(numel(ix.F107), 15);
            tc.verifyEqual(ix.F107, 70*ones(15,1), 'AbsTol', 1e-6);
        end

        function holdsDailyValueAcrossWholeDay(tc)
            % a rev late in day 0 (23:00) must still read day-0 F10.7 (70),
            % NOT flip to day-1 -- the day-membership sampling guarantee
            tMid = (23/24) * 86400;                 % 23:00 on day 0
            ix = loadSpaceWeatherIndices(tc.gfzFile, tMid, tc.startMJD, ...
                'Verbose', false, 'DailyInterp', 'nearest');
            tc.verifyEqual(ix.F107, 70, 'AbsTol', 1e-6);
        end

        function f107RampsAcrossDays(tc)
            % one rev at the middle of each of the 5 days -> 70..90
            tMid = ((0:4).' + 0.5) * 86400;         % midday of each UT day
            ix = loadSpaceWeatherIndices(tc.gfzFile, tMid, tc.startMJD, ...
                'Verbose', false, 'DailyInterp', 'nearest');
            tc.verifyEqual(ix.F107, (70:5:90).', 'AbsTol', 1e-6);
        end

        function kpInterpolatesWithinDay(tc)
            % sample near the last 3-hour interval mid-time (22:30) of day 0
            tMid = (22.5/24) * 86400;               % 22:30 on day 0
            ix = loadSpaceWeatherIndices(tc.gfzFile, tMid, tc.startMJD, ...
                'Verbose', false, 'KpInterp', 'linear');
            tc.verifyEqual(ix.Kp, 2.75, 'AbsTol', 1e-6);   % Kp8 = 2.75
        end

        function selectsAdjustedF107(tc)
            tMid = 0.5*86400;                       % midday day 0
            ix = loadSpaceWeatherIndices(tc.gfzFile, tMid, tc.startMJD, ...
                'Verbose', false, 'UseAdjustedF107', true);
            tc.verifyEqual(ix.F107, 68, 'AbsTol', 1e-6);   % 70 - 2
        end

        function computesF107a(tc)
            % 81-day window but only 5 days present -> F107a = mean of the
            % available observed F10.7 for a central day
            tMid = 2.5*86400;                       % midday of day 2 (2020-01-03)
            [ix, raw] = loadSpaceWeatherIndices(tc.gfzFile, tMid, tc.startMJD, ...
                'Verbose', false);
            tc.verifyEqual(ix.F107a, mean(70:5:90), 'AbsTol', 1e-6);   % =80
            tc.verifyEqual(raw.F107a(3), 80, 'AbsTol', 1e-6);
        end

        function flagsOutOfRangeWindows(tc)
            % ask for windows well beyond the 5-day file
            tMid = (0:100).' * 86400;               % 101 days
            [ix, raw] = loadSpaceWeatherIndices(tc.gfzFile, tMid, tc.startMJD, ...
                'Verbose', false);
            tc.verifyTrue(any(isnan(ix.F107)));               % out-of-range NaN
            tc.verifyTrue(any(contains(raw.provenance.notes, 'outside')));
        end

        function acceptsResultStruct(tc)
            % struct-first form pulls tMid/startMJD from the result
            result.perRev.tMid = ((1:15).'-0.5)*5400;   % within day 0
            result.startMJD = tc.startMJD;
            ix = loadSpaceWeatherIndices(result, 'File', tc.gfzFile, ...
                'Verbose', false);
            tc.verifyEqual(numel(ix.F107), 15);
            tc.verifyEqual(ix.F107, 70*ones(15,1), 'AbsTol', 1e-6);
        end

        function mergesExtraFields(tc)
            tMid = ((1:10).'-0.5)*5400;
            beta = linspace(-30,30,10).';
            ix = loadSpaceWeatherIndices(tc.gfzFile, tMid, tc.startMJD, ...
                'Verbose', false, 'Extra', struct('beta', beta));
            tc.verifyTrue(isfield(ix, 'beta'));
            tc.verifyEqual(ix.beta, beta, 'AbsTol', 1e-12);
        end

        function integratesWithDiagnostics(tc)
            % end-to-end: loader output feeds scaleFactorDiagnostics and a
            % F10.7-driven scale is attributed to 'density'
            R = 5*16;                                % 16 revs/day, 5 days
            tMid = ((0:R-1).'+0.5)*5400;
            ix = loadSpaceWeatherIndices(tc.gfzFile, tMid, tc.startMJD, ...
                'Verbose', false);
            % build a per-rev scale that tracks the loaded F10.7
            rng(0);
            s = 0.9 + 0.002*(ix.F107 - 70) + 0.002*randn(R,1);
            perRev.tMid = tMid;
            perRev.scale = [s s s];
            perRev.dragMag = 3e-8 + zeros(R,1);
            d = scaleFactorDiagnostics(perRev, ix, 'Axes', 1, ...
                'Verbose', false, 'MinRevs', 12, 'NumBoot', 300);
            tc.verifyEqual(d.axis(1).cause, 'density');
        end

        function producesProvenance(tc)
            [~, raw] = loadSpaceWeatherIndices(tc.gfzFile, (0:31).'*5400, ...
                tc.startMJD, 'Verbose', false);
            tc.verifyTrue(isfield(raw, 'provenance'));
            tc.verifyTrue(contains(raw.provenance.claudeVersion, 'Claude'));
            tc.verifyEqual(raw.provenance.toolbox, 'AccelBiasScaleToolbox');
        end

    end
end
