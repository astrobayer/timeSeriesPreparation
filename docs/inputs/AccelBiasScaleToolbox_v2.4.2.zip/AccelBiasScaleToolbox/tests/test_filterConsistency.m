classdef test_filterConsistency < matlab.unittest.TestCase
%TEST_FILTERCONSISTENCY  Unit tests for filterConsistency.m and crnFilter.m

    methods (Test)

        function crnFilterHasUnitDCGain(tc)
            % a constant acceleration must pass through unchanged, else the
            % filter itself introduces a bias
            h = crnFilter(1, 'Cutoff', 0.02);
            tc.verifyEqual(sum(h), 1, 'AbsTol', 1e-12);
        end

        function crnFilterIsSymmetricHenceLinearPhase(tc)
            h = crnFilter(1, 'Cutoff', 0.02);
            tc.verifyEqual(h, flipud(h), 'AbsTol', 1e-12);
        end

        function crnFilterAttenuatesHighFrequencies(tc)
            fs = 1; fc = 0.02;
            h = crnFilter(fs, 'Cutoff', fc);
            H = @(f) abs(sum(h .* exp(-2i*pi*f*(0:numel(h)-1)')));
            tc.verifyEqual(H(0), 1, 'AbsTol', 1e-10);
            tc.verifyLessThan(H(0.2), 0.1);      % well above cutoff
            tc.verifyGreaterThan(H(0.002), 0.9); % well below cutoff
        end

        function badCutoffThrows(tc)
            tc.verifyError(@() crnFilter(1, 'Cutoff', 0.9), 'crnFilter:badCutoff');
        end

        function commonModeFiltersBothSeries(tc)
            rng(1);
            n = 2000;
            t = (0:n-1)';
            lf = sin(2*pi*0.005*t);
            yObs = lf + 0.3*randn(n,1);
            yMod = lf + 0.3*randn(n,1);

            [o, m] = filterConsistency(t, yObs, yMod, 'commonmode', 'Cutoff', 0.02);
            % both series must lose their high-frequency content
            tc.verifyLessThan(std(diff(o)), std(diff(yObs)));
            tc.verifyLessThan(std(diff(m)), std(diff(yMod)));
        end

        function filterMismatchBiasesScaleAndCorrectionRemovesIt(tc)
            % THE headline test: an unfiltered model compared against a
            % filtered observation yields a biased scale estimate; making
            % them filter-consistent recovers the truth.
            rng(2);
            n = 4000;
            t = (0:n-1)';
            % model has real broadband content the ACC pipeline removes
            yMod = sin(2*pi*0.004*t) + 0.5*sin(2*pi*0.15*t);
            trueScale = 1.0;

            h = crnFilter(1, 'Cutoff', 0.02, 'NumConv', 5);
            % Apply the filter ONCE, centred, exactly as the L1 processor does
            % and as filterConsistency('explicit') assumes (centredFIR). Using
            % a forward-backward double pass here would square the response and
            % leave a residual the single-pass correction cannot match.
            yObs = centredFIRLocal(trueScale*yMod, h);   % ACC1B-like

            % (a) naive: fit unfiltered model against filtered observation
            Xn = [ones(n,1), yMod - mean(yMod)];
            cn = Xn \ yObs;
            scaleNaive = cn(2);

            % (b) filter-consistent
            [o, m] = filterConsistency(t, yObs, yMod, 'explicit', 'FilterCoef', h);
            Xc = [ones(n,1), m - mean(m)];
            cc = Xc \ o;
            scaleCorrected = cc(2);

            % the naive scale is dragged well away from 1 ...
            tc.verifyGreaterThan(abs(scaleNaive - trueScale), 0.05);
            % ... and the correction restores it
            tc.verifyEqual(scaleCorrected, trueScale, 'AbsTol', 0.02);
        end

        function zeroPhaseFilteringIntroducesNoLag(tc)
            % a causal filter would add a group delay that crossCorrLag
            % would then misreport as a clock offset
            n = 2000;
            t = (0:n-1)';
            y = sin(2*pi*0.005*t);
            [~, m] = filterConsistency(t, y, y, 'commonmode', 'Cutoff', 0.02);
            lag = crossCorrLag(t, y, m, 0.1);
            tc.verifyEqual(lag, 0, 'AbsTol', 2);
        end

        function noneStrategyPassesThrough(tc)
            t = (1:100)'; y1 = randn(100,1); y2 = randn(100,1);
            [o, m] = filterConsistency(t, y1, y2, 'none');
            tc.verifyEqual(o, y1);
            tc.verifyEqual(m, y2);
        end

        function empiricalResponseIsLowPassAndBounded(tc)
            rng(3);
            n = 4000;
            t = (0:n-1)';
            yMod = sin(2*pi*0.004*t) + 0.5*sin(2*pi*0.15*t);
            h = crnFilter(1, 'Cutoff', 0.02, 'NumConv', 5);
            yObs = zeroPhaseLocal(yMod, h);

            [~, ~, fc] = filterConsistency(t, yObs, yMod, 'empirical');
            tc.verifyLessThanOrEqual(max(fc.Hmag), 1 + 1e-9);  % cannot amplify
            tc.verifyEqual(fc.Hmag(1), 1, 'AbsTol', 1e-9);     % DC preserved
        end

        function badStrategyThrows(tc)
            t = (1:10)';
            tc.verifyError(@() filterConsistency(t, randn(10,1), randn(10,1), 'bogus'), ...
                'filterConsistency:badStrategy');
        end

    end
end

function y = zeroPhaseLocal(x, h)
h = h(:);
L = numel(h);
npad = min(3*L, numel(x)-1);
xp = [2*x(1) - flipud(x(2:npad+1)); x; 2*x(end) - flipud(x(end-npad:end-1))];
y1 = filter(h, 1, xp);
y1 = flipud(filter(h, 1, flipud(y1)));
y = y1(npad+1 : npad+numel(x));
end

function y = centredFIRLocal(x, h)
%CENTREDFIRLOCAL  Single centred FIR pass, matching filterConsistency's
%   internal centredFIR: symmetric kernel applied once, group delay removed
%   by centring. This is how ACC_1B is actually produced (one filter, not a
%   forward-backward double pass).
h = h(:); x = x(:);
L = numel(h);
d = (L-1)/2;                       % symmetric kernel group delay
npad = min(3*L, numel(x)-1);
xp = [2*x(1) - flipud(x(2:npad+1)); x; 2*x(end) - flipud(x(end-npad:end-1))];
yf = filter(h, 1, xp);
yf = yf(npad + (1:numel(x)) + floor(d));   % undo the group delay (centre)
y = yf;
end
