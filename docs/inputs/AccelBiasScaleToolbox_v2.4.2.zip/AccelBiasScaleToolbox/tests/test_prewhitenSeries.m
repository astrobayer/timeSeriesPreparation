classdef test_prewhitenSeries < matlab.unittest.TestCase
%TEST_PREWHITENSERIES  Unit tests for prewhitenSeries.m
%   Python reference: whitening an AR(2) series with the fitted
%   coefficients drove the lag-1 autocorrelation from 0.632 to 0.005.

    methods (Test)

        function whiteningRemovesAutocorrelation(tc)
            rng(7);
            n = 4000;
            phiTrue = [0.75; -0.20];
            e = randn(n+200,1);
            x = zeros(n+200,1);
            for k = 3:(n+200)
                x(k) = phiTrue(1)*x(k-1) + phiTrue(2)*x(k-2) + e(k);
            end
            x = x(201:end);

            nm = estimateNoiseModel(x, 'Order', 2);
            w = prewhitenSeries(x, nm.phi);

            acfBefore = localACF1(x);
            acfAfter  = localACF1(w);

            tc.verifyGreaterThan(abs(acfBefore), 0.4);
            tc.verifyLessThan(abs(acfAfter), 0.08);
        end

        function outputLengthIsReducedByAROrder(tc)
            x = randn(100, 3);
            w = prewhitenSeries(x, [0.5; -0.2]);
            tc.verifyEqual(size(w), [98, 3]);
        end

        function emptyPhiIsIdentity(tc)
            x = randn(50,2);
            tc.verifyEqual(prewhitenSeries(x, []), x);
        end

        function knownFilterAppliedExactly(tc)
            x = (1:6)';
            phi = 0.5;
            % w_t = x_t - 0.5*x_{t-1}, for t = 2..6
            expected = [2-0.5*1; 3-0.5*2; 4-0.5*3; 5-0.5*4; 6-0.5*5];
            tc.verifyEqual(prewhitenSeries(x, phi), expected, 'AbsTol', 1e-12);
        end

        function multipleColumnsFilteredIndependently(tc)
            x = [(1:6)', (10:10:60)'];
            phi = 0.5;
            w = prewhitenSeries(x, phi);
            w1 = prewhitenSeries(x(:,1), phi);
            w2 = prewhitenSeries(x(:,2), phi);
            tc.verifyEqual(w, [w1, w2], 'AbsTol', 1e-12);
        end

        function tooShortThrows(tc)
            tc.verifyError(@() prewhitenSeries((1:2)', [0.1;0.2;0.3]), ...
                'prewhitenSeries:tooShort');
        end

    end
end

function a = localACF1(x)
x = x(:) - mean(x);
a = sum(x(1:end-1).*x(2:end)) / sum(x.^2);
end
