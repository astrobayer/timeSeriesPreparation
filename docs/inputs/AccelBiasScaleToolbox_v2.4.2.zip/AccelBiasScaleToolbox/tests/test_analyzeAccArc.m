classdef test_analyzeAccArc < matlab.unittest.TestCase
%TEST_ANALYZEACCARC  Integration tests for the analyzeAccArc wrapper.

    methods (Test)

        function runsEndToEndAndRecoversScales(tc)
            [tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair( ...
                'Seed', 20, 'NoiseStd', 0.005, 'NoiseRho', 0.7);
            out = analyzeAccArc(tObs, Yobs, tMod, Ymod, ...
                'FilterStrategy', 'explicit', ...
                'Bootstrap', false, 'TimeVaryingScale', 'never', ...
                'Verbose', false);
            tc.verifyTrue(isfield(out, 'fit'));
            tc.verifyTrue(isfield(out, 'decomp'));
            tc.verifyTrue(isfield(out, 'frameCheck'));
            % diagonal scales recovered
            tc.verifyEqual(diag(out.fit.S), truth.scales, 'AbsTol', 0.06);
        end

        function producesConsolidatedFlagList(tc)
            [tObs, Yobs, tMod, Ymod] = syntheticAccelPair('Seed', 21);
            out = analyzeAccArc(tObs, Yobs, tMod, Ymod, ...
                'Bootstrap', false, 'TimeVaryingScale', 'never', 'Verbose', false);
            tc.verifyTrue(iscell(out.flags));
            % flags are de-duplicated
            tc.verifyEqual(numel(out.flags), numel(unique(out.flags)));
        end

        function frameCheckCatchesAPermutationError(tc)
            % feed data where the model axes are permuted vs the observation
            [tObs, Yobs, tMod, Ymod] = syntheticAccelPair('Seed', 22, ...
                'MisalignUrad',[0 0 0], 'NonOrtho',[0 0 0]);
            P = accFrameToSRF();            % scramble the model axes
            YmodPerm = Ymod * P';
            out = analyzeAccArc(tObs, Yobs, tMod, YmodPerm, ...
                'FilterStrategy','none', 'Bootstrap', false, ...
                'TimeVaryingScale','never', 'Verbose', false);
            tc.verifyEqual(out.frameCheck.verdict, 'FRAME ERROR');
        end

        function savesCalibrationWhenRequested(tc)
            [tObs, Yobs, tMod, Ymod] = syntheticAccelPair('Seed', 23);
            f = [tempname '.mat'];
            analyzeAccArc(tObs, Yobs, tMod, Ymod, ...
                'FilterStrategy','explicit', 'Bootstrap', false, ...
                'TimeVaryingScale','never', 'Verbose', false, 'Save', f);
            tc.verifyTrue(isfile(f));
            cal = accelCalibrationIO('load', f);
            delete(f);
            tc.verifyEqual(cal.type, 'static');
            tc.verifyTrue(isfield(cal.provenance.meta, 'filterDCGain'));
        end

        function alwaysModeRunsTimeVaryingScale(tc)
            [tObs, Yobs, tMod, Ymod] = syntheticAccelPair('Seed', 24, 'NoiseStd', 0.005);
            out = analyzeAccArc(tObs, Yobs, tMod, Ymod, ...
                'FilterStrategy','explicit', 'Bootstrap', false, ...
                'TimeVaryingScale','always', 'Verbose', false);
            tc.verifyNotEmpty(out.timeVarying);
            tc.verifyTrue(isfield(out.timeVarying(1).fit, 'scale'));
        end

    end
end
