classdef test_bsplineBasis < matlab.unittest.TestCase
%TEST_BSPLINEBASIS  Unit tests for bsplineBasis.m
%   Reference values cross-checked against an independent Python
%   implementation of the Cox-de Boor recursion.

    methods (Test)

        function partitionOfUnity(tc)
            t = linspace(0, 10, 200)';
            B = bsplineBasis(t, 5, 4);
            tc.verifyEqual(sum(B,2), ones(size(t)), 'AbsTol', 1e-10);
        end

        function correctColumnCount(tc)
            B = bsplineBasis((0:0.1:10)', 6, 4);
            tc.verifyEqual(size(B,2), 6 + 4);
        end

        function basisIsNonnegative(tc)
            B = bsplineBasis(linspace(-5,5,300)', 4, 4);
            tc.verifyGreaterThanOrEqual(B, -1e-12);
        end

        function endpointsAreCovered(tc)
            t = linspace(0, 10, 100)';
            B = bsplineBasis(t, 5, 4);
            tc.verifyFalse(any(isnan(B(:))));
            tc.verifyEqual(sum(B(1,:)),   1, 'AbsTol', 1e-10);
            tc.verifyEqual(sum(B(end,:)), 1, 'AbsTol', 1e-10);
        end

        function zeroInteriorKnotsIsSinglePolynomialSegment(tc)
            t = linspace(0,1,50)';
            B = bsplineBasis(t, 0, 4);
            tc.verifyEqual(size(B,2), 4);
            tc.verifyEqual(sum(B,2), ones(size(t)), 'AbsTol', 1e-10);
        end

        function degenerateTimeRangeDoesNotError(tc)
            B = bsplineBasis(ones(10,1)*5, 3, 4);
            tc.verifyEqual(size(B,1), 10);
            tc.verifyFalse(any(isnan(B(:))));
        end

        % --- the quantile-placement fix ---

        function quantileKnotsAvoidGapsAndImproveConditioning(tc)
            % epochs with a large hole between t=3 and t=8
            t = [linspace(0,3,100), linspace(8,10,100)]';

            [Bu, knU] = bsplineBasis(t, 5, 4, 'uniform');
            [Bq, knQ] = bsplineBasis(t, 5, 4, 'quantile');

            intU = knU(5:end-4);
            intQ = knQ(5:end-4);

            % uniform placement puts knots INSIDE the hole; quantile does not
            inGapU = nnz(intU > 3 & intU < 8);
            inGapQ = nnz(intQ > 3 & intQ < 8);
            tc.verifyGreaterThan(inGapU, 0);
            tc.verifyLessThanOrEqual(inGapQ, 1);

            % and the resulting basis is much better conditioned.
            % Python reference on this configuration: cond 6.19e3 -> 6.69e2
            cU = cond(Bu'*Bu);
            cQ = cond(Bq'*Bq);
            tc.verifyLessThan(cQ, cU);
        end

        function quantilePlacementStillPartitionsUnity(tc)
            t = [linspace(0,3,100), linspace(8,10,100)]';
            B = bsplineBasis(t, 5, 4, 'quantile');
            tc.verifyEqual(sum(B,2), ones(size(t)), 'AbsTol', 1e-10);
        end

        function badPlacementThrows(tc)
            tc.verifyError(@() bsplineBasis((0:10)', 3, 4, 'bogus'), ...
                'bsplineBasis:badPlacement');
        end

    end
end
