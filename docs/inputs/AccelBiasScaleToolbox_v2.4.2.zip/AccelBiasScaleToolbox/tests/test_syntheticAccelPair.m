classdef test_syntheticAccelPair < matlab.unittest.TestCase
%TEST_SYNTHETICACCELPAIR  Unit tests for the synthetic generator itself.
%   The generator is test infrastructure, so it needs its own tests: if it
%   silently fails to inject a defect, the integration tests below become
%   vacuous (they would "pass" by testing nothing).

    methods (Test)

        function truthScaleMatrixIsConsistent(tc)
            [~,~,~,~, truth] = syntheticAccelPair('Seed', 1);
            tc.verifyEqual(truth.R * truth.U, truth.S, 'AbsTol', 1e-12);
            tc.verifyEqual(truth.R * truth.R', eye(3), 'AbsTol', 1e-12);
            tc.verifyEqual(truth.U, truth.U', 'AbsTol', 1e-12);
            tc.verifyGreaterThan(det(truth.R), 0);
        end

        function injectedTruthIsRecoverableByDecomposition(tc)
            [~,~,~,~, truth] = syntheticAccelPair('Seed', 2);
            d = decomposeScaleMatrix(truth.S);
            tc.verifyEqual(d.scales, truth.scales, 'AbsTol', 1e-8);
            tc.verifyEqual(d.anglesUrad, truth.anglesUrad, 'AbsTol', 5);
            tc.verifyEqual(d.nonOrtho, truth.nonOrtho, 'AbsTol', 1e-8);
        end

        function gapsAreActuallyCut(tc)
            [tObs,~,~,~, truth] = syntheticAccelPair('NumGaps', 3, 'GapLen', 600);
            for k = 1:size(truth.gapIntervals,1)
                g = truth.gapIntervals(k,:);
                inGap = nnz(tObs > g(1) + 1 & tObs < g(2) - 1);
                tc.verifyEqual(inGap, 0);
            end
        end

        function observedAndModelGridsDiffer(tc)
            [tObs,~,tMod,~] = syntheticAccelPair('DtObs', 1, 'DtMod', 5);
            tc.verifyNotEqual(numel(tObs), numel(tMod));
            tc.verifyEqual(median(diff(tMod)), 5, 'AbsTol', 1e-9);
        end

        function noiseIsColouredNotWhite(tc)
            [~, Yobs, ~, ~, truth] = syntheticAccelPair('NoiseRho', 0.9, 'Seed', 3);
            % the residual about the deterministic part must be correlated
            nm = estimateNoiseModel(diff(Yobs(:,1)));
            tc.verifyGreaterThan(truth.noiseRho, 0.5);
            tc.verifyNotEmpty(nm);
        end

        function observedIsLowPassRelativeToModel(tc)
            [~, Yobs, ~, Ymod] = syntheticAccelPair('FilterObs', true, 'Seed', 4);
            % high-frequency content, measured by successive differencing,
            % must be suppressed in the observation relative to the model
            hfObs = std(diff(Yobs(:,3))) / std(Yobs(:,3));
            hfMod = std(diff(Ymod(:,3))) / std(Ymod(:,3));
            tc.verifyLessThan(hfObs, hfMod);
        end

        function glitchesArePresent(tc)
            [~, Yobs, ~, ~, truth] = syntheticAccelPair('NumGlitches', 8, ...
                'GlitchAmp', 30, 'Seed', 5);
            tc.verifyEqual(numel(truth.glitchIdx), 8);
            q = qualityCheck((1:size(Yobs,1))', Yobs(:,1), 5);
            tc.verifyGreaterThanOrEqual(q.outlierFraction, 0);
        end

        function reproducibleWithSeed(tc)
            [t1, Y1] = syntheticAccelPair('Seed', 99);
            [t2, Y2] = syntheticAccelPair('Seed', 99);
            tc.verifyEqual(t1, t2);
            tc.verifyEqual(Y1, Y2);
        end

    end
end
