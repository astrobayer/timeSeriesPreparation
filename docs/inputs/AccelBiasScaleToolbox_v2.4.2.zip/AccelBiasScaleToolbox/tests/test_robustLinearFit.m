classdef test_robustLinearFit < matlab.unittest.TestCase
%TEST_ROBUSTLINEARFIT  Unit tests for robustLinearFit.m

    methods (Test)

        function recoversExactLinearRelationNoNoise(tc)
            x = (1:100)';
            X = [ones(size(x)), x];
            trueCoef = [2.5; -0.7];
            y = X*trueCoef;
            coef = robustLinearFit(X, y);
            tc.verifyEqual(coef, trueCoef, 'AbsTol', 1e-8);
        end

        function matchesOLSWhenNoOutliers(tc)
            x = (1:200)';
            X = [ones(size(x)), x];
            trueCoef = [1; 0.3];
            noise = pseudoNoise(200)*0.01;
            y = X*trueCoef + noise;
            coefRobust = robustLinearFit(X, y);
            coefOLS = X \ y;
            tc.verifyEqual(coefRobust, coefOLS, 'AbsTol', 1e-2);
        end

        function downweightsGrossOutliers(tc)
            x = (1:200)';
            X = [ones(size(x)), x];
            trueCoef = [1; 0.3];
            y = X*trueCoef;
            y([50 100 150]) = y([50 100 150]) + 1000; % gross outliers
            coefRobust = robustLinearFit(X, y);
            coefOLS = X \ y;
            errRobust = norm(coefRobust - trueCoef);
            errOLS = norm(coefOLS - trueCoef);
            tc.verifyLessThan(errRobust, errOLS);
            tc.verifyEqual(coefRobust, trueCoef, 'AbsTol', 1e-2);
        end

        function honorsMaxIterWithoutError(tc)
            x = (1:50)'; X = [ones(size(x)), x]; y = X*[1;1];
            coef = robustLinearFit(X, y, 'MaxIter', 2); %#ok<NASGU>
            tc.verifyTrue(true); % just confirm no error/crash
        end


        function penaltyShrinksTowardNullSpace(tc)
            t = linspace(0,10,200)';
            B = bsplineBasis(t, 15, 4);
            P = diffPenaltyMatrix(size(B,2), 2);
            y = 2 + 0.5*t;      % lies exactly in the d=2 null space
            coef = robustLinearFit(B, y, 'Penalty', P, 'Lambda', 1e8);
            tc.verifyEqual(B*coef, y, 'AbsTol', 1e-2);
        end

        function zeroLambdaMatchesUnpenalizedFit(tc)
            rng(21);
            X = [ones(100,1), randn(100,2)];
            y = X*[1;2;3] + 0.01*randn(100,1);
            a = robustLinearFit(X, y);
            b = robustLinearFit(X, y, 'Penalty', eye(3), 'Lambda', 0);
            tc.verifyEqual(a, b, 'AbsTol', 1e-10);
        end

        function weightsAreZeroedForGrossOutliers(tc)
            x = (1:200)';
            X = [ones(size(x)), x];
            y = X*[1;0.3];
            y([50 150]) = y([50 150]) + 1e4;
            [~, w] = robustLinearFit(X, y);
            tc.verifyEqual(w([50 150]), [0;0], 'AbsTol', 1e-12);
        end

    end
end

function y = pseudoNoise(n)
s = (1:n)';
y = mod(sin(s*12.9898)*43758.5453, 1) - 0.5;
end
