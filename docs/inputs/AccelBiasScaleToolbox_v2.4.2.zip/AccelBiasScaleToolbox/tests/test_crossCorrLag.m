classdef test_crossCorrLag < matlab.unittest.TestCase
%TEST_CROSSCORRLAG  Unit tests for crossCorrLag.m

    methods (Test)

        function zeroLagForIdenticalSignal(tc)
            t = (0:0.01:50)';
            y = sin(2*pi*0.05*t);
            [lagEst, corrMax] = crossCorrLag(t, y, y, 0.05);
            tc.verifyEqual(lagEst, 0, 'AbsTol', 1e-9);
            tc.verifyGreaterThan(corrMax, 0.99);
        end

        function detectsKnownLag(tc)
            dt = 0.01;
            t = (0:dt:50)';
            y1 = sin(2*pi*0.05*t);
            shiftSamples = 20;
            y2 = [nan(shiftSamples,1); y1(1:end-shiftSamples)]; % y2 delayed
            valid = isfinite(y2);
            [lagEst, corrMax] = crossCorrLag(t(valid), y1(valid), y2(valid), 0.05);
            % Magnitude of the estimated lag should match the known shift;
            % sign convention is documented but not asserted here to keep
            % the test robust to XCORR's internal indexing.
            tc.verifyEqual(abs(lagEst), shiftSamples*dt, 'AbsTol', 2*dt);
            tc.verifyGreaterThan(corrMax, 0.8);
        end

        function tooFewSamplesReturnsNaN(tc)
            t = (1:5)'; y1 = (1:5)'; y2 = (1:5)';
            [lagEst, corrMax] = crossCorrLag(t, y1, y2, 0.05);
            tc.verifyTrue(isnan(lagEst));
            tc.verifyTrue(isnan(corrMax));
        end

    end
end
