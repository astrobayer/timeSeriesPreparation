classdef test_qualityCheck < matlab.unittest.TestCase
%TEST_QUALITYCHECK  Unit tests for qualityCheck.m

    methods (Test)

        function cleanSeriesNoFlags(tc)
            t = (0:0.1:100)';
            y = sin(t);
            q = qualityCheck(t, y, 5);
            tc.verifyFalse(q.nonMonotonic);
            tc.verifyEqual(q.duplicateTimestamps, 0);
            tc.verifyEqual(q.nGaps, 0);
            tc.verifyEqual(q.nNaN, 0);
            tc.verifyEqual(q.outlierFraction, 0, 'AbsTol', 1e-12);
        end

        function detectsNonMonotonic(tc)
            t = [0 1 2 1.5 3]';
            y = [1 2 3 4 5]';
            q = qualityCheck(t, y, 5);
            tc.verifyTrue(q.nonMonotonic);
        end

        function detectsDuplicateTimestamps(tc)
            t = [0 1 1 2 3]';
            y = [1 2 3 4 5]';
            q = qualityCheck(t, y, 5);
            tc.verifyEqual(q.duplicateTimestamps, 1);
        end

        function detectsGap(tc)
            t = [(0:0.1:10) (20:0.1:30)]'; % large jump between segments
            y = sin(t);
            q = qualityCheck(t, y, 5);
            tc.verifyGreaterThan(q.nGaps, 0);
            tc.verifyGreaterThan(q.gapFraction, 0);
        end

        function detectsOutliers(tc)
            t = (1:1000)';
            y = randnStable(1000, 1);
            y(500) = 1000; % single extreme spike
            q = qualityCheck(t, y, 5);
            tc.verifyGreaterThan(q.outlierFraction, 0);
        end

        function countsNaN(tc)
            t = (1:100)';
            y = ones(100,1);
            y([10 20 30]) = NaN;
            q = qualityCheck(t, y, 5);
            tc.verifyEqual(q.nNaN, 3);
        end

    end
end

function y = randnStable(n, m)
% deterministic pseudo-random values without relying on rng state
s = (1:n*m)';
y = reshape(mod(sin(s*12.9898)*43758.5453, 1) - 0.5, n, m);
end
