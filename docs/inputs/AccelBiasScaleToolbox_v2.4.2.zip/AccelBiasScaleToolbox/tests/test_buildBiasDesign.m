classdef test_buildBiasDesign < matlab.unittest.TestCase
%TEST_BUILDBIASDESIGN  Unit tests for buildBiasDesign.m

    methods (Test)

        function constantIsOnesColumn(tc)
            t = (0:0.1:10)';
            [B, info] = buildBiasDesign(t, struct('type','constant'));
            tc.verifyEqual(B, ones(numel(t),1));
            tc.verifyEqual(info.nParams, 1);
            tc.verifyFalse(info.isPenalized);
        end

        function polynomialIsOrthonormalAndFullRank(tc)
            t = (0:0.1:10)';
            [B, info] = buildBiasDesign(t, struct('type','polynomial','order',3));
            tc.verifyEqual(info.nParams, 4);
            tc.verifyEqual(B'*B, eye(4), 'AbsTol', 1e-10);
        end

        function polynomialFitsAPolynomialExactly(tc)
            t = linspace(0,10,200)';
            truth = 3 - 2*t + 0.5*t.^2;
            B = buildBiasDesign(t, struct('type','polynomial','order',2));
            tc.verifyEqual(B*(B\truth), truth, 'AbsTol', 1e-6);
        end

        function polynomialOrthogonalizationSurvivesHugeTimeOffsets(tc)
            % raw MJD-like epochs would make a Vandermonde hopelessly
            % ill-conditioned; the QR basis must not care
            t = 59000 + (0:0.01:10)';
            B = buildBiasDesign(t, struct('type','polynomial','order',5));
            tc.verifyLessThan(cond(B), 10);
        end

        function splineDefaultsToQuantilePlacement(tc)
            t = [linspace(0,3,100), linspace(8,10,100)]';
            [~, info] = buildBiasDesign(t, ...
                struct('type','spline','numInteriorKnots',5));
            interior = info.knots(5:end-4);
            tc.verifyLessThanOrEqual(nnz(interior > 3 & interior < 8), 1);
        end

        function psplineReturnsAPenalty(tc)
            t = (0:0.1:10)';
            [B, info] = buildBiasDesign(t, ...
                struct('type','pspline','numInteriorKnots',20,'penaltyOrder',2));
            tc.verifyTrue(info.isPenalized);
            tc.verifyEqual(size(info.penalty), [size(B,2), size(B,2)]);
            tc.verifyEqual(rank(info.penalty), size(B,2) - 2);
        end

        function unpenalizedTypesHaveZeroPenaltyBlock(tc)
            t = (0:0.1:10)';
            [~, info] = buildBiasDesign(t, struct('type','constant'));
            tc.verifyEqual(info.penalty, 0);
        end

        function unknownTypeThrows(tc)
            tc.verifyError(@() buildBiasDesign((0:10)', struct('type','bogus')), ...
                'buildBiasDesign:unknownType');
        end

    end
end
