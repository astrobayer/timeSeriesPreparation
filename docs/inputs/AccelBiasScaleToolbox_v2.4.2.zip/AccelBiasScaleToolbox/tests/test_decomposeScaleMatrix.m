classdef test_decomposeScaleMatrix < matlab.unittest.TestCase
%TEST_DECOMPOSESCALEMATRIX  Unit tests for decomposeScaleMatrix.m
%   Cross-checked against scipy.linalg.polar: for S = R_true*U_true with
%   [2000, -1000, 1500] urad misalignment, both R and U were recovered to
%   ~1e-15 and the angles to 0.01 urad.

    methods (Test)

        function recoversRotationAndStretchExactly(tc)
            angTrue = [2000; -1000; 1500] * 1e-6;
            W = [    0      -angTrue(3)  angTrue(2)
                 angTrue(3)     0       -angTrue(1)
                -angTrue(2)  angTrue(1)     0      ];
            th = norm(angTrue);
            Rtrue = eye(3) + (sin(th)/th)*W + ((1-cos(th))/th^2)*(W*W);

            Utrue = [0.96 0.01 0.00
                     0.01 1.03 0.005
                     0.00 0.005 1.10];

            S = Rtrue * Utrue;
            d = decomposeScaleMatrix(S);

            tc.verifyEqual(d.R, Rtrue, 'AbsTol', 1e-10);
            tc.verifyEqual(d.U, Utrue, 'AbsTol', 1e-10);
            tc.verifyEqual(d.anglesUrad, [2000; -1000; 1500], 'AbsTol', 5);
            tc.verifyEqual(d.scales, [0.96; 1.03; 1.10], 'AbsTol', 1e-8);
            tc.verifyEqual(d.nonOrtho, [0.01; 0.00; 0.005], 'AbsTol', 1e-8);
        end

        function pureScalingGivesIdentityRotation(tc)
            S = diag([1.05, 0.97, 1.20]);
            d = decomposeScaleMatrix(S);
            tc.verifyEqual(d.R, eye(3), 'AbsTol', 1e-10);
            tc.verifyEqual(d.anglesUrad, zeros(3,1), 'AbsTol', 1e-4);
            tc.verifyEqual(d.scales, [1.05;0.97;1.20], 'AbsTol', 1e-10);
        end

        function pureRotationGivesUnitScales(tc)
            th = 0.003;
            Rz = [cos(th) -sin(th) 0; sin(th) cos(th) 0; 0 0 1];
            d = decomposeScaleMatrix(Rz);
            tc.verifyEqual(d.scales, ones(3,1), 'AbsTol', 1e-10);
            tc.verifyEqual(d.nonOrtho, zeros(3,1), 'AbsTol', 1e-10);
            tc.verifyEqual(d.anglesUrad(3), th*1e6, 'RelTol', 1e-3);
        end

        function UIsSymmetricAndRIsOrthogonal(tc)
            rng(1);
            S = eye(3) + 0.05*randn(3);
            d = decomposeScaleMatrix(S);
            tc.verifyEqual(d.U, d.U', 'AbsTol', 1e-12);
            tc.verifyEqual(d.R*d.R', eye(3), 'AbsTol', 1e-10);
            tc.verifyTrue(d.isProper);
        end

        function productReconstructsS(tc)
            rng(2);
            S = eye(3) + 0.08*randn(3);
            d = decomposeScaleMatrix(S);
            tc.verifyEqual(d.R * d.U, S, 'AbsTol', 1e-10);
        end

        function nanEntriesSubstitutedAndFlagged(tc)
            S = [1.0 NaN 0; NaN 1.0 0; 0 0 1.1];
            d = decomposeScaleMatrix(S);
            tc.verifyTrue(d.hadMissing);
            tc.verifyFalse(any(isnan(d.R(:))));
        end

        function angleUncertaintyPropagates(tc)
            S = eye(3);
            covS = 1e-8 * eye(9);
            d = decomposeScaleMatrix(S, covS);
            tc.verifyNotEmpty(d.anglesSigmaUrad);
            tc.verifyEqual(numel(d.anglesSigmaUrad), 3);
            tc.verifyGreaterThan(min(d.anglesSigmaUrad), 0);
        end

        function nonSquareThrows(tc)
            tc.verifyError(@() decomposeScaleMatrix(ones(3,2)), ...
                'decomposeScaleMatrix:notSquare');
        end

    end
end
