classdef test_crnFilterATBD < matlab.unittest.TestCase
%TEST_CRNFILTERATBD  Unit tests for the EXACT CRN filter (crnFilter.m).
%
%   Reference values computed independently in Python from the ATBD
%   (JPL D-27672) Appendix B formulae. These are not tolerances invented to
%   make the code pass -- they are what the specification produces.

    methods (Test)

        function accPresetMatchesATBDParameters(tc)
            [~, info] = crnFilter('ACC');
            tc.verifyEqual(info.fs, 10);
            tc.verifyEqual(info.Nc, 7);
            tc.verifyEqual(info.Tf, 140.7);
            tc.verifyEqual(info.Nf, 1407);       % fs*Tf, odd
            tc.verifyEqual(info.Nh, 703);
            tc.verifyEqual(info.NB, 5);          % round(0.035 * 140.7)
            tc.verifyEqual(info.spanSeconds, 140.7, 'AbsTol', 1e-9);
            % the REALISED bandwidth, NB/Tf, not the nominal 0.035
            tc.verifyEqual(info.bandwidth, 5/140.7, 'RelTol', 1e-12);
            tc.verifyEqual(info.bandwidth, 0.035537, 'AbsTol', 1e-5);
        end

        function kbrPresetMatchesATBDParameters(tc)
            [~, info] = crnFilter('KBR');
            tc.verifyEqual(info.Tf, 70.7);
            tc.verifyEqual(info.Nf, 707);
            tc.verifyEqual(info.NB, 7);          % round(0.1 * 70.7)
            tc.verifyEqual(info.bandwidth, 7/70.7, 'RelTol', 1e-12);
        end

        function kernelIsSymmetricHenceLinearPhase(tc)
            h = crnFilter('ACC');
            tc.verifyEqual(h, flipud(h), 'AbsTol', 1e-12);
            tc.verifyEqual(mod(numel(h), 2), 1);   % odd length
        end

        function gainIsExactlyOneAtF0NotAtDC(tc)
            % THE subtle point. The ATBD normalises at the dominant (J2)
            % signal frequency f0 = 0.37 mHz, NOT at DC. Anyone who
            % "fixes" this by forcing sum(h) = 1 introduces a 4.5e-4 error
            % -- comparable to the scale factors being estimated.
            [h, info] = crnFilter('ACC');
            tc.verifyEqual(info.gainAtF0, 1, 'AbsTol', 1e-9);

            tc.verifyNotEqual(info.dcGain, 1);
            tc.verifyEqual(info.dcGain, 1.0004533, 'AbsTol', 1e-6);
            tc.verifyEqual(sum(h), info.dcGain, 'AbsTol', 1e-12);
        end

        function passbandAndStopbandMatchReference(tc)
            [h, info] = crnFilter('ACC');
            n = (0:numel(h)-1).' - info.Nh;
            g = @(f) abs(sum(h .* exp(-2i*pi*f*n/info.fs)));

            % Python reference values from the ATBD formulae
            tc.verifyEqual(g(0.0010), 0.997147, 'AbsTol', 1e-4);
            tc.verifyEqual(g(0.0100), 0.716851, 'AbsTol', 1e-4);
            tc.verifyEqual(g(0.0200), 0.256060, 'AbsTol', 1e-4);
            tc.verifyEqual(g(0.0500), 0.000025, 'AbsTol', 1e-4);
            tc.verifyLessThan(g(0.1000), 1e-5);   % deep stopband
            tc.verifyLessThan(g(0.5000), 1e-5);
        end

        function removableSingularityHandledAtKEqualsM(tc)
            % sin(pi*0/Nc)/sin(pi*0/Nf) is 0/0; the limit is Nf/Nc
            h = crnFilter('ACC');
            tc.verifyFalse(any(isnan(h)));
            tc.verifyFalse(any(isinf(h)));
        end

        function derivativeKernelsAreProducedAndAntisymmetric(tc)
            [~, ~, hDot, hDDot] = crnFilter('ACC');
            % d/dt of a symmetric kernel is antisymmetric; d2/dt2 symmetric
            tc.verifyEqual(hDot,  -flipud(hDot),  'AbsTol', 1e-9);
            tc.verifyEqual(hDDot,  flipud(hDDot), 'AbsTol', 1e-9);
        end

        function derivativeKernelDifferentiatesASinusoid(tc)
            [h, info, hDot] = crnFilter('ACC');
            f = 0.002;                        % well inside the passband
            t = (0:1/info.fs:400).';
            x = sin(2*pi*f*t);

            Nh = info.Nh;
            mid = (Nh+1) : (numel(x)-Nh);     % interior, no edge effects
            y  = conv(x, h,    'same');
            yd = conv(x, hDot, 'same');

            expected = 2*pi*f*cos(2*pi*f*t);
            tc.verifyEqual(yd(mid), expected(mid), 'AbsTol', 2e-4);
            tc.verifyEqual(y(mid),  x(mid),        'AbsTol', 2e-3);
        end

        function evenNcThrows(tc)
            tc.verifyError(@() crnFilter('ACC', 'Nc', 6), 'crnFilter:evenNc');
        end

        function badProductThrows(tc)
            tc.verifyError(@() crnFilter('LRI'), 'crnFilter:badProduct');
        end

        % --- the headline result ---
        function exactFilterRemovesScaleBiasThatAnApproximationDoesNot(tc)
            rng(0);
            [h, info] = crnFilter('ACC');
            fs = info.fs;
            N = 60000;
            t = (0:N-1).'/fs;

            yMod = sin(2*pi*t/5400) + 0.4*sin(4*pi*t/5400) ...
                 + 0.3*sin(2*pi*0.05*t) + 0.2*randn(N,1);

            trueScale = 1.0;
            yObs = centred(trueScale*yMod, h);      % ACC1B-like

            fitScale = @(m, o) localScale(m, o);

            sNone  = fitScale(yMod, yObs);              % no correction
            sExact = fitScale(centred(yMod, h), yObs);  % exact CRN

            % an approximate CRN of the kind one might guess at
            hApprox = approxCRN(fs, 0.035, 7);
            sApprox = fitScale(centred(yMod, hApprox), yObs);

            % uncorrected: badly biased
            tc.verifyLessThan(sNone, 0.95);
            % approximate correction: STILL biased by ~1%, which is exactly
            % the magnitude one would misread as a density/Cd deficiency
            tc.verifyGreaterThan(abs(sApprox - trueScale), 0.005);
            % exact correction: unbiased
            tc.verifyEqual(sExact, trueScale, 'AbsTol', 1e-3);
        end

    end
end

% -------------------------------------------------------------------
function s = localScale(m, o)
X = [ones(numel(m),1), m - mean(m)];
c = X \ o;
s = c(2);
end

function y = centred(x, h)
h = h(:);
Nh = (numel(h)-1)/2;
np = min(round(Nh), numel(x)-1);
xp = [2*x(1) - flipud(x(2:np+1)); x; 2*x(end) - flipud(x(end-np:end-1))];
yf = conv(xp, h, 'same');
y = yf(np+1 : np+numel(x));
end

function h = approxCRN(fs, fc, nconv)
L = 2*ceil(fs/fc) + 1;
w = max(3, round(fs/(fc*nconv)));
h = 1;
for k = 1:nconv, h = conv(h, ones(w,1)); end
h = h(:);
if numel(h) > L
    c = (numel(h)+1)/2;
    lo = max(1, round(c-(L-1)/2));
    h = h(lo : min(numel(h), lo+L-1));
end
m = (numel(h)-1)/2;
idx = (0:numel(h)-1).' - m;
h = h .* exp(-0.5*(idx/(0.3*m)).^2);
h = h / sum(h);
end
