classdef test_slidingWindowFit < matlab.unittest.TestCase
%TEST_SLIDINGWINDOWFIT  Unit tests for slidingWindowFit.m

    methods (Test)

        function recoversConstantBiasAndScale(tc)
            t = (0:0.1:100)';
            y2 = 1 + sin(0.2*t);
            y1 = 0.3 + 1.7*y2;
            sw = slidingWindowFit(t, y1, y2, 10, 0.5, 'Robust', false);
            v = isfinite(sw.scale);
            tc.verifyGreaterThan(nnz(v), 5);
            tc.verifyEqual(mean(sw.scale(v)), 1.7, 'AbsTol', 1e-6);
            tc.verifyEqual(mean(sw.bias(v)),  0.3, 'AbsTol', 1e-6);
        end

        function biasIsReportedInUncenteredParameterization(tc)
            % demeaning must not change the REPORTED bias
            t = (0:0.1:100)';
            y2 = 50 + sin(0.2*t);       % large offset
            y1 = 0.3 + 1.7*y2;
            % this test targets the bias parameterization, not observability;
            % the large offset gives a low relRange, so switch off gating
            % (otherwise every window is correctly gated unobservable -> NaN)
            swD = slidingWindowFit(t, y1, y2, 20, 0.5, 'Demean', true,  ...
                'Robust', false, 'GateObservable', false);
            swR = slidingWindowFit(t, y1, y2, 20, 0.5, 'Demean', false, ...
                'Robust', false, 'GateObservable', false);
            v = isfinite(swD.bias) & isfinite(swR.bias);
            tc.verifyEqual(mean(swD.bias(v)), 0.3, 'AbsTol', 1e-5);
            tc.verifyEqual(mean(swD.bias(v)), mean(swR.bias(v)), 'AbsTol', 1e-4);
        end

        function unobservableWindowsAreGatedNotFitted(tc)
            % constant model signal => scale is not identifiable anywhere
            t = (0:0.1:200)';
            y2 = ones(size(t));
            y1 = 2*y2 + 0.001*randn(size(t));
            sw = slidingWindowFit(t, y1, y2, 20, 0.5);
            tc.verifyGreaterThan(sw.nUnobservable, 0);
            tc.verifyTrue(all(isnan(sw.scale(~sw.observable))));
        end

        function gatingCanBeDisabled(tc)
            t = (0:0.1:200)';
            y2 = ones(size(t));
            y1 = 2*y2;
            sw = slidingWindowFit(t, y1, y2, 20, 0.5, 'GateObservable', false);
            tc.verifyGreaterThan(nnz(isfinite(sw.scale)), 0);
        end

        function detectsGenuineScaleVariation(tc)
            t = (0:0.1:300)';
            y2 = 1 + 0.8*sin(0.5*t);              % healthy dynamic range
            scaleTrue = 1 + 0.3*sin(2*pi*t/300);
            y1 = scaleTrue .* y2;
            sw = slidingWindowFit(t, y1, y2, 20, 0.5, 'Robust', false);
            tc.verifyGreaterThan(sw.scaleStd, 0.05);
            tc.verifyEqual(nnz(~sw.observable), 0);   % all windows are fine
        end

        function emptyInputReturnsNaNSummary(tc)
            sw = slidingWindowFit([], [], [], 1, 0.5);
            tc.verifyTrue(isnan(sw.scaleStd));
        end

        function badOverlapThrows(tc)
            t = (0:0.1:10)';
            tc.verifyError(@() slidingWindowFit(t, t, t, 1, 1.0), ...
                'slidingWindowFit:badOverlap');
        end

    end
end
