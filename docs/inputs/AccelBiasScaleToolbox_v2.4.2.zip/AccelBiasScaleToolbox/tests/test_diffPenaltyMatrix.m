classdef test_diffPenaltyMatrix < matlab.unittest.TestCase
%TEST_DIFFPENALTYMATRIX  Unit tests for diffPenaltyMatrix.m

    methods (Test)

        function isSymmetricPSD(tc)
            P = diffPenaltyMatrix(12, 2);
            tc.verifyEqual(P, P', 'AbsTol', 1e-12);
            tc.verifyGreaterThanOrEqual(min(eig(P)), -1e-10);
        end

        function nullSpaceDimensionEqualsDifferenceOrder(tc)
            % d=2 => penalty must NOT shrink a linear trend (null space {1,t})
            for d = 1:3
                P = diffPenaltyMatrix(15, d);
                tc.verifyEqual(rank(P), 15 - d, 'AbsTol', 0);
            end
        end

        function linearCoefficientsAreUnpenalized(tc)
            n = 10;
            P = diffPenaltyMatrix(n, 2);
            c = (1:n)';                      % perfectly linear coefficients
            tc.verifyEqual(c'*P*c, 0, 'AbsTol', 1e-10);
            cConst = ones(n,1);
            tc.verifyEqual(cConst'*P*cConst, 0, 'AbsTol', 1e-10);
        end

        function curvedCoefficientsArePenalized(tc)
            n = 10;
            P = diffPenaltyMatrix(n, 2);
            c = ((1:n)').^2;                 % quadratic => nonzero 2nd diff
            tc.verifyGreaterThan(c'*P*c, 1);
        end

        function tooFewBasisThrows(tc)
            tc.verifyError(@() diffPenaltyMatrix(2, 2), ...
                'diffPenaltyMatrix:tooFewBasis');
        end

    end
end
