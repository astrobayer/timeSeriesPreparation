classdef test_flagEdgeEffects < matlab.unittest.TestCase
%TEST_FLAGEDGEEFFECTS  Unit tests for flagEdgeEffects.m

    methods (Test)

        function zeroesHalfSpanAtBothEndsOfASingleSegment(tc)
            fs = 10; t = (0:1/fs:1000)';
            h = ones(201,1);            % Nh = 100 samples
            w = flagEdgeEffects(t, h, 'Mode', 'zero');
            tc.verifyEqual(w(1:100), zeros(100,1));
            tc.verifyEqual(w(end-99:end), zeros(100,1));
            tc.verifyEqual(w(round(numel(w)/2)), 1);
        end

        function everyGapCreatesTwoContaminatedRegions(tc)
            fs = 10;
            seg = (0:1/fs:200)';
            t = [seg; seg(end)+50 + seg];      % one big gap in the middle
            h = ones(201,1);
            [w, info] = flagEdgeEffects(t, h, 'Mode','zero','GapFactor',5);
            tc.verifyEqual(info.nSegments, 2);
            % 4 contaminated ends (2 per segment)
            tc.verifyGreaterThan(info.nContaminated, 0);
            tc.verifyEqual(info.contaminatedFraction, info.nContaminated/numel(t), 'AbsTol', 1e-12);
        end

        function taperModeRampsSmoothly(tc)
            fs = 10; t = (0:1/fs:1000)';
            h = ones(201,1);
            w = flagEdgeEffects(t, h, 'Mode','taper');
            tc.verifyEqual(w(1), 0, 'AbsTol', 1e-9);        % 0 at the boundary
            tc.verifyGreaterThan(w(50), 0);                 % ramping up
            tc.verifyLessThan(w(50), 1);
            tc.verifyEqual(w(round(end/2)), 1, 'AbsTol', 1e-9);
        end

        function reportsCorrectHalfSpanInSeconds(tc)
            fs = 10; t = (0:1/fs:1000)';
            h = crnFilter('ACC');           % Nh = 703 => 70.3 s
            [~, info] = flagEdgeEffects(t, h);
            tc.verifyEqual(info.halfSpanSamples, 703);
            tc.verifyEqual(info.halfSpanSeconds, 70.3, 'AbsTol', 0.5);
        end

        function contaminatedFractionGrowsWithGapCount(tc)
            fs = 10;
            h = ones(201,1);
            % no gaps
            t0 = (0:1/fs:4000)';
            [~, i0] = flagEdgeEffects(t0, h);
            % many gaps
            seg = (0:1/fs:200)';
            t1 = [];
            for k = 0:9, t1 = [t1; k*250 + seg]; end %#ok<AGROW>
            [~, i1] = flagEdgeEffects(t1, h, 'GapFactor', 5);
            tc.verifyGreaterThan(i1.contaminatedFraction, i0.contaminatedFraction);
        end

        function badModeThrows(tc)
            t = (0:0.1:100)'; h = ones(11,1);
            tc.verifyError(@() flagEdgeEffects(t, h, 'Mode','bogus'), ...
                'flagEdgeEffects:badMode');
        end

    end
end
