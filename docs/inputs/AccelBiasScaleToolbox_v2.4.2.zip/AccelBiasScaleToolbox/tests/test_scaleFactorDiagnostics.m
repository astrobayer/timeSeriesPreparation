classdef test_scaleFactorDiagnostics < matlab.unittest.TestCase
%TEST_SCALEFACTORDIAGNOSTICS  Unit tests for the multi-day index-regression
%   cause-attribution function. Builds synthetic per-rev scale series each
%   driven by a KNOWN cause (density / geometry / sensor / none) and checks
%   the function names the right one.
%
%   Authoring provenance
%     Date   : 2026-07-15
%     Author : Claude (Anthropic), model Claude Opus 4.8

    methods (Access = private)

        function ix = makeIndices(~, R)
            % realistic-ish per-rev index vectors spanning a useful range
            k = (0:R-1).';
            ix.F107   = 120 + 45*sin(2*pi*k/180) + 5*randn(R,1);
            ix.Kp     = 2   + 1.2*abs(sin(2*pi*k/40)) + 0.3*randn(R,1);
            ix.beta   = 35*sin(2*pi*k/260);
            ix.argLat = mod(k*23, 360);
        end

        function per = makePerRev(~, R, scaleCol)
            % a perRev-like struct with a given 3-axis scale matrix
            per.tMid   = (0:R-1).' * 5400;
            per.scale  = scaleCol;
            per.dragMag = 3e-8 + 1e-8*abs(sin(2*pi*(0:R-1).'/32));
        end

    end

    methods (Test)

        function attributesDensityCause(tc)
            rng(1); R = 350;
            ix  = tc.makeIndices(R);
            % axis-1 scale tracks F10.7 (density); others flat
            s = 0.90 + 0.0010*(ix.F107-120) + 0.003*randn(R,1);
            per = tc.makePerRev(R, [s, 1.0+0.003*randn(R,1), 1.0+0.003*randn(R,1)]);
            d = scaleFactorDiagnostics(per, ix, 'Axes', 1, 'Verbose', false, 'NumBoot', 300, ...
                'AxisNames', {'X','Y','Z'});
            tc.verifyEqual(d.axis(1).cause, 'density');
            tc.verifyEqual(d.axis(1).dominant, 'F107');
            tc.verifyGreaterThan(d.axis(1).R2, 0.5);
        end

        function attributesGeometryCause(tc)
            rng(2); R = 350;
            ix = tc.makeIndices(R);
            s = 1.00 + 0.0020*ix.beta + 0.003*randn(R,1);
            per = tc.makePerRev(R, [s, s, s]);
            d = scaleFactorDiagnostics(per, ix, 'Axes', 1, 'Verbose', false, 'NumBoot', 300);
            tc.verifyEqual(d.axis(1).cause, 'geometry');
        end

        function attributesSensorDrift(tc)
            rng(3); R = 350;
            ix = tc.makeIndices(R);
            % pure secular ramp, independent of any drag index
            drift = 25e-6 * (0:R-1).';
            s = 1.00 + drift + 0.002*randn(R,1);
            per = tc.makePerRev(R, [s, s, s]);
            d = scaleFactorDiagnostics(per, ix, 'Axes', 1, 'Verbose', false, 'NumBoot', 300);
            tc.verifyEqual(d.axis(1).cause, 'sensor');
            tc.verifyEqual(d.axis(1).dominant, 'secular');
        end

        function flatScaleIsUnresolved(tc)
            rng(4); R = 300;
            ix = tc.makeIndices(R);
            s = 1.03 + 0.003*randn(R,1);        % no structure
            per = tc.makePerRev(R, [s, s, s]);
            d = scaleFactorDiagnostics(per, ix, 'Axes', 1, 'Verbose', false, 'NumBoot', 300);
            tc.verifyEqual(d.axis(1).cause, 'unresolved');
        end

        function acceptsFullResultStruct(tc)
            % passing an analyzeAccScaleArc-like result (with .perRev) works
            rng(5); R = 250;
            ix = tc.makeIndices(R);
            s = 0.9 + 0.001*(ix.F107-120) + 0.003*randn(R,1);
            result.perRev = tc.makePerRev(R, [s, s, s]);
            result.scaleGlobal = [0.9 0.9 0.9];   % extra fields ignored
            d = scaleFactorDiagnostics(result, ix, 'Axes', 1, 'Verbose', false, 'NumBoot', 300);
            tc.verifyEqual(d.axis(1).cause, 'density');
        end

        function warnsWhenNoActivityIndex(tc)
            rng(6); R = 200;
            % only geometry indices supplied -> density/Cd not separable
            k = (0:R-1).';
            ix.beta = 30*sin(2*pi*k/260);
            ix.argLat = mod(k*23,360);
            s = 1.0 + 0.002*ix.beta + 0.003*randn(R,1);
            per = tc.makePerRev(R, [s s s]);
            d = scaleFactorDiagnostics(per, ix, 'Axes', 1, 'Verbose', false, 'NumBoot', 300);
            tc.verifyTrue(any(contains(d.flags, 'activity index')));
        end

        function warnsOnQuietActivity(tc)
            rng(7); R = 250;
            k = (0:R-1).';
            ix.F107 = 70 + 0.5*randn(R,1);     % barely varies (<10%)
            ix.beta = 30*sin(2*pi*k/260);
            s = 1.0 + 0.002*ix.beta + 0.003*randn(R,1);
            per = tc.makePerRev(R, [s s s]);
            d = scaleFactorDiagnostics(per, ix, 'Axes', 1, 'Verbose', false, 'NumBoot', 300);
            tc.verifyTrue(any(contains(d.flags, 'too quiet')));
        end

        function tooFewRevsIsUnresolved(tc)
            rng(8); R = 8;
            ix = tc.makeIndices(R);
            s = 0.9 + 0.001*(ix.F107-120);
            per = tc.makePerRev(R, [s s s]);
            d = scaleFactorDiagnostics(per, ix, 'Axes', 1, 'Verbose', false, 'NumBoot', 300, ...
                'MinRevs', 12);
            tc.verifyEqual(d.axis(1).cause, 'unresolved');
            tc.verifyTrue(contains(d.axis(1).verdict, 'too few') || ...
                          contains(d.axis(1).verdict, 'observable rev'));
        end

        function respectsNaNUnobservableRevs(tc)
            rng(9); R = 350;
            ix = tc.makeIndices(R);
            s = 0.9 + 0.001*(ix.F107-120) + 0.003*randn(R,1);
            s(1:5:end) = NaN;                 % scatter unobservable revs
            per = tc.makePerRev(R, [s s s]);
            d = scaleFactorDiagnostics(per, ix, 'Axes', 1, 'Verbose', false, 'NumBoot', 300);
            tc.verifyLessThan(d.axis(1).nRevs, R);      % NaNs dropped
            tc.verifyEqual(d.axis(1).cause, 'density');
        end

        function producesProvenanceAndTable(tc)
            rng(10); R = 200;
            ix = tc.makeIndices(R);
            s = 0.9 + 0.001*(ix.F107-120) + 0.003*randn(R,1);
            per = tc.makePerRev(R, [s s s]);
            d = scaleFactorDiagnostics(per, ix, 'Verbose', false, 'NumBoot', 300);
            tc.verifyTrue(isfield(d, 'provenance'));
            tc.verifyTrue(contains(d.provenance.claudeVersion, 'Claude'));
            tc.verifyEqual(numel(d.summary), 3);
            if ~isempty(d.table)
                tc.verifyEqual(height(d.table), 3);
            end
        end

        function coefCIExcludesZeroForRealDriver(tc)
            rng(11); R = 350;
            ix = tc.makeIndices(R);
            s = 0.9 + 0.0012*(ix.F107-120) + 0.002*randn(R,1);
            per = tc.makePerRev(R, [s s s]);
            d = scaleFactorDiagnostics(per, ix, 'Axes', 1, 'Verbose', false, 'NumBoot', 300);
            iF = find(strcmp(d.axis(1).predictors, 'F107'), 1);
            tc.verifyTrue(d.axis(1).coefSig(iF));       % F107 CI excludes 0
        end

    end
end
