classdef test_glsLinearFit < matlab.unittest.TestCase
%TEST_GLSLINEARFIT  Unit tests for glsLinearFit.m
%   Python reference (AR(1) rho=0.95, n=1000): the naive iid sigmas were
%   5.5-6.5x smaller than honest block-bootstrap sigmas. GLS must report
%   a sigmaInflation well above 1 in that regime.

    methods (Test)

        function recoversCoefficientsWithWhiteNoise(tc)
            rng(1);
            n = 500;
            t = linspace(0,10,n)';
            X = [ones(n,1), sin(t)];
            beta = [0.5; 2.0];
            y = X*beta + 0.01*randn(n,1);

            fit = glsLinearFit(X, y, 'Robust', false);
            tc.verifyEqual(fit.coef, beta, 'AbsTol', 0.02);
        end

        function recoversCoefficientsWithColoredNoise(tc)
            rng(2);
            n = 2000;
            t = linspace(0,100,n)';
            X = [ones(n,1), sin(0.3*t)];
            beta = [0.5; 2.0];

            nz = zeros(n,1); e = 0.1*randn(n,1);
            for k = 2:n, nz(k) = 0.9*nz(k-1) + e(k); end
            y = X*beta + nz;

            fit = glsLinearFit(X, y, 'Robust', false);
            % coefficients stay unbiased under colored noise ...
            tc.verifyEqual(fit.coef, beta, 'AbsTol', 0.25);
        end

        function sigmaIsInflatedUnderColoredNoise(tc)
            rng(3);
            n = 1000;
            t = linspace(0,100,n)';
            X = [ones(n,1), sin(0.3*t)];
            nz = zeros(n,1); e = 0.1*randn(n,1);
            for k = 2:n, nz(k) = 0.95*nz(k-1) + e(k); end
            y = X*[0.5;2.0] + nz;

            fit = glsLinearFit(X, y, 'Robust', false, 'NoiseModel', true);
            % ... but the ERROR BARS must grow. This is the whole point.
            tc.verifyGreaterThan(mean(fit.sigmaInflation), 1.5);
            tc.verifyEqual(fit.noiseModel.verdict, 'strongly-correlated');
        end

        function noiseModelOffGivesNaiveSigmas(tc)
            rng(4);
            n = 500;
            X = [ones(n,1), randn(n,1)];
            y = X*[1;2] + randn(n,1);
            fit = glsLinearFit(X, y, 'Robust', false, 'NoiseModel', false);
            tc.verifyEqual(fit.sigmaInflation, ones(2,1), 'AbsTol', 1e-8);
        end

        function penaltyShrinksTowardNullSpace(tc)
            rng(5);
            t = linspace(0,10,200)';
            B = bsplineBasis(t, 15, 4);
            P = diffPenaltyMatrix(size(B,2), 2);
            y = 2 + 0.5*t;    % exactly in the d=2 null space

            fit = glsLinearFit(B, y, 'Robust', false, 'NoiseModel', false, ...
                'Penalty', P, 'Lambda', 1e8);
            tc.verifyEqual(fit.fitted, y, 'AbsTol', 1e-2);
        end

        function edfEqualsParamCountWhenUnpenalized(tc)
            rng(6);
            X = [ones(100,1), randn(100,2)];
            y = randn(100,1);
            fit = glsLinearFit(X, y, 'Robust', false, 'NoiseModel', false);
            tc.verifyEqual(fit.edf, 3, 'AbsTol', 1e-8);
        end

        function robustFitResistsOutliers(tc)
            rng(7);
            n = 300;
            X = [ones(n,1), linspace(0,10,n)'];
            beta = [1; 2];
            y = X*beta;
            y([50 150 250]) = y([50 150 250]) + 500;

            fitR = glsLinearFit(X, y, 'Robust', true,  'NoiseModel', false);
            fitO = glsLinearFit(X, y, 'Robust', false, 'NoiseModel', false);

            tc.verifyLessThan(norm(fitR.coef - beta), norm(fitO.coef - beta));
            tc.verifyEqual(fitR.coef, beta, 'AbsTol', 0.05);
        end

    end
end
