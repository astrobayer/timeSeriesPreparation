classdef test_integration_endToEnd < matlab.unittest.TestCase
%TEST_INTEGRATION_ENDTOEND  End-to-end tests against injected ground truth.
%
%   These are the tests that matter. The per-unit tests verify that each
%   function inverts its own forward model on clean data -- necessary, but
%   structurally incapable of catching the bugs that actually corrupt real
%   analyses, because those bugs are INTERACTIONS:
%
%     * a spline knot landing inside a data gap
%     * an unfiltered model compared against a filtered observation, the
%       mismatch leaking into scale
%     * autocorrelated residuals producing confident-but-wrong error bars
%     * a quiet arc where scale is not identifiable at all
%     * amplitude attenuation from linear interpolation biasing scale low
%
%   SYNTHETICACCELPAIR injects all of them at once. The pipeline is then
%   scored against the known truth.

    methods (Test)

        %% ---------------------------------------------------------
        function recoversScaleMatrixFromFullyDefectiveData(tc)
            [tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair( ...
                'Seed', 11, 'NoiseStd', 0.01, 'NoiseRho', 0.9, ...
                'FilterObs', true, 'Cutoff', 0.02);

            [tA, Y1A, Y2A] = alignAccelSeries(tObs, Yobs, tMod, Ymod, ...
                'InterpMethod', 'pchip');

            % make the pair filter-consistent before fitting
            h = truth.filterCoef;
            for j = 1:3
                [Y1A(:,j), Y2A(:,j)] = filterConsistency(tA, Y1A(:,j), Y2A(:,j), ...
                    'explicit', 'FilterCoef', h);
            end

            spec = struct('ScaleModel','full', ...
                'BiasModel', struct('type','pspline','numInteriorKnots',25, ...
                                    'placement','quantile'));
            fit = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, ...
                'Robust', true, 'NoiseModel', true, 'LambdaSelect', 'gcv');

            % the diagonal (scale factors) must be recovered
            tc.verifyEqual(diag(fit.S), diag(truth.S), 'AbsTol', 0.05);
            % and so must the full matrix, to looser tolerance
            tc.verifyEqual(fit.S, truth.S, 'AbsTol', 0.08);
        end

        %% ---------------------------------------------------------
        function recoversMisalignmentAnglesAndScales(tc)
            [tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair( ...
                'Seed', 12, 'NoiseStd', 0.005, 'NoiseRho', 0.8, ...
                'MisalignUrad', [2000 -1000 1500], ...
                'Scales', [0.96 1.03 1.10]);

            [tA, Y1A, Y2A] = alignAccelSeries(tObs, Yobs, tMod, Ymod, ...
                'InterpMethod','pchip');
            for j = 1:3
                [Y1A(:,j), Y2A(:,j)] = filterConsistency(tA, Y1A(:,j), Y2A(:,j), ...
                    'explicit', 'FilterCoef', truth.filterCoef);
            end

            spec = struct('ScaleModel','full', ...
                'BiasModel', struct('type','pspline','numInteriorKnots',25, ...
                                    'placement','quantile'));
            fit = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, ...
                'Robust', true, 'LambdaSelect', 'gcv');

            d = fit.decomp;
            tc.verifyTrue(d.isProper);
            tc.verifyEqual(d.scales, truth.scales, 'AbsTol', 0.05);
            % misalignment recovered to well within its own magnitude
            tc.verifyEqual(d.anglesUrad, truth.anglesUrad, 'AbsTol', 800);
        end

        %% ---------------------------------------------------------
        function biasCurveIsRecovered(tc)
            [tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair( ...
                'Seed', 13, 'NoiseStd', 0.005, 'BiasAmp', 0.05);

            [tA, Y1A, Y2A, info] = alignAccelSeries(tObs, Yobs, tMod, Ymod, ...
                'InterpMethod','pchip');
            for j = 1:3
                [Y1A(:,j), Y2A(:,j)] = filterConsistency(tA, Y1A(:,j), Y2A(:,j), ...
                    'explicit', 'FilterCoef', truth.filterCoef);
            end

            spec = struct('ScaleModel','full', ...
                'BiasModel', struct('type','pspline','numInteriorKnots',25, ...
                                    'placement','quantile'));
            fit = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, 'LambdaSelect','gcv');

            biasTrue = truth.biasFun(tA);
            for i = 1:3
                err = fit.axis(i).biasFitted - biasTrue(:,i);
                % the fitted bias curve tracks the injected drift
                tc.verifyLessThan(std(err), 0.35 * std(biasTrue(:,i)) + 0.02);
            end
        end

        %% ---------------------------------------------------------
        function filterMismatchBiasesScaleWhenUncorrected(tc)
            % A/B: the SAME data, fitted with and without the filter
            % correction. The uncorrected scale must be measurably worse.
            [tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair( ...
                'Seed', 14, 'NoiseStd', 0.002, 'NoiseRho', 0.5, ...
                'FilterObs', true, 'Cutoff', 0.015);

            [tA, Y1A, Y2A] = alignAccelSeries(tObs, Yobs, tMod, Ymod, ...
                'InterpMethod','pchip');

            spec = struct('ScaleModel','diagonal', ...
                'BiasModel', struct('type','pspline','numInteriorKnots',20, ...
                                    'placement','quantile'));

            % (a) uncorrected
            fitBad = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, 'LambdaSelect','gcv');
            errBad = abs(diag(fitBad.S) - truth.scales);

            % (b) filter-consistent
            Y1C = Y1A; Y2C = Y2A;
            for j = 1:3
                [Y1C(:,j), Y2C(:,j)] = filterConsistency(tA, Y1A(:,j), Y2A(:,j), ...
                    'explicit', 'FilterCoef', truth.filterCoef);
            end
            fitGood = accelBiasScaleModelFit(tA, Y1C, Y2C, spec, 'LambdaSelect','gcv');
            errGood = abs(diag(fitGood.S) - truth.scales);

            tc.verifyLessThan(mean(errGood), mean(errBad));
        end

        %% ---------------------------------------------------------
        function noiseModelDetectsColouredResiduals(tc)
            [tObs, Yobs, tMod, Ymod, ~] = syntheticAccelPair( ...
                'Seed', 15, 'NoiseRho', 0.95, 'NoiseStd', 0.02);

            [tA, Y1A, Y2A] = alignAccelSeries(tObs, Yobs, tMod, Ymod);
            spec = struct('ScaleModel','diagonal', ...
                'BiasModel', struct('type','constant'));
            fit = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, 'NoiseModel', true);

            for i = 1:3
                nm = fit.axis(i).noiseModel;
                tc.verifyLessThan(nm.nEffRatio, 0.8);
                % honest sigmas must exceed the naive iid ones
                tc.verifyGreaterThan(mean(fit.axis(i).sigmaInflation), 1);
            end
        end

        %% ---------------------------------------------------------
        function quietArcIsFlaggedUnobservableRatherThanFitted(tc)
            % A near-constant model signal: scale is NOT identifiable.
            % The pipeline must say so, not return a confident number.
            t = (0:1:20000)';
            yMod = 1 + 0.001*sin(2*pi*t/5400);      % negligible dynamic range
            yObs = 0.2 + 1.0*yMod + 0.01*randn(size(t));

            report = accelSeriesPreflight(t, yObs, t, yMod, ...
                'PlotDiagnostics', false, 'Spectral', false);

            tc.verifyFalse(report.axis(1).observability.observable);
            hasFlag = any(contains(report.axis(1).flags, 'SCALE NOT OBSERVABLE'));
            tc.verifyTrue(hasFlag);
        end

        %% ---------------------------------------------------------
        function preflightRunsOnFullyDefectiveDataAndFlagsIssues(tc)
            [tObs, Yobs, tMod, Ymod] = syntheticAccelPair('Seed', 16);

            report = accelSeriesPreflight(tObs, Yobs, tMod, Ymod, ...
                'PlotDiagnostics', false, 'Spectral', false);

            tc.verifyEqual(numel(report.axis), 3);
            % colored noise was injected, so this must be caught
            tc.verifyLessThan(report.axis(1).noiseModel.nEffRatio, 0.9);
            % and at least one caveat must be raised
            tc.verifyGreaterThan(numel(report.axis(1).flags), 0);
        end

        %% ---------------------------------------------------------
        function blockedCVPrefersTheTrueBiasComplexity(tc)
            % the truth has a SMOOTH bias drift. Blocked CV must not be
            % seduced into selecting a wildly over-rich spline, even though
            % the over-rich model wins on in-sample RSS.
            [tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair( ...
                'Seed', 17, 'NoiseRho', 0.9, 'NoiseStd', 0.02);

            specs = {};
            specs{end+1} = struct('label','const', 'ScaleModel','diagonal', ...
                'BiasModel', struct('type','constant'));
            specs{end+1} = struct('label','spline8', 'ScaleModel','diagonal', ...
                'BiasModel', struct('type','spline','numInteriorKnots',8, ...
                                    'placement','quantile'));
            specs{end+1} = struct('label','spline120', 'ScaleModel','diagonal', ...
                'BiasModel', struct('type','spline','numInteriorKnots',120, ...
                                    'placement','quantile'));

            cmp = accelBiasScaleModelCompare(tObs, Yobs, tMod, Ymod, specs, ...
                'FilterStrategy', 'explicit', 'FilterCoef', truth.filterCoef, ...
                'PlotDiagnostics', false, 'NumFolds', 5);

            % the grossly over-parameterized model must NOT rank first
            tc.verifyNotEqual(cmp.table.Model{1}, 'spline120');
        end

        %% ---------------------------------------------------------
        function bootstrapIntervalsCoverTheTrueScale(tc)
            [tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair( ...
                'Seed', 18, 'NoiseStd', 0.005, 'NoiseRho', 0.85);

            [tA, Y1A, Y2A] = alignAccelSeries(tObs, Yobs, tMod, Ymod, ...
                'InterpMethod','pchip');
            for j = 1:3
                [Y1A(:,j), Y2A(:,j)] = filterConsistency(tA, Y1A(:,j), Y2A(:,j), ...
                    'explicit', 'FilterCoef', truth.filterCoef);
            end

            spec = struct('ScaleModel','diagonal', ...
                'BiasModel', struct('type','pspline','numInteriorKnots',20, ...
                                    'placement','quantile'));
            fit = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, ...
                'Bootstrap', true, 'NumBoot', 150, 'LambdaSelect','gcv');

            for i = 1:3
                bs = fit.axis(i).boot;
                tc.verifyNotEmpty(bs);
                % the scale coefficient is the last parameter in the design
                ciScale = bs.ci(end,:);
                tc.verifyGreaterThanOrEqual(truth.scales(i), ciScale(1) - 0.03);
                tc.verifyLessThanOrEqual(   truth.scales(i), ciScale(2) + 0.03);
            end
        end

    end
end
