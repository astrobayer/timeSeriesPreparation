classdef test_readGroopsInstrument < matlab.unittest.TestCase
%TEST_READGROOPSINSTRUMENT  Unit tests for readGroopsInstrument.m
%   Synthetic GROOPS instrument files, so the tests are self-contained.

    properties
        workDir
    end

    methods (TestMethodSetup)
        function makeWorkDir(tc)
            tc.workDir = tempname; mkdir(tc.workDir);
            tc.addTeardown(@() rmdir(tc.workDir,'s'));
        end
    end

    methods (Access = private)
        function f = writeFile(tc, lines)
            f = fullfile(tc.workDir, 'model.txt');
            fid = fopen(f,'w');
            fprintf(fid, '%s\n', lines{:});
            fclose(fid);
        end
    end

    methods (Test)

        function readsAcceleratorFile(tc)
            lines = {
                'groops instrument version=20200123'
                '# ACCELEROMETER'
                '         -8          1'
                '# Time [MJD]               data0: x [m/s^2]          data1: y [m/s^2]          data2: z [m/s^2]'
                '# ================================================================='
                '          3'
                ' 58849.000000000000000000 -1.2e-08  2.1e-08 -4.1e-09'
                ' 58849.000115740740739056 -1.2e-08  2.1e-08 -4.1e-09'
                ' 58849.500000000000000000 -1.0e-08  1.9e-08 -5.0e-09'
            };
            f = tc.writeFile(lines);
            [time, data, aux] = readGroopsInstrument(f);

            tc.verifyEqual(size(data), [3 3]);
            tc.verifyEqual(aux.type, 'ACCELEROMETER');
            tc.verifyEqual(aux.version, '20200123');
            tc.verifyEqual(aux.columnNames, {'x','y','z'});
            tc.verifyEqual(aux.numRecordsHeader, 3);
            tc.verifyEqual(aux.numRecordsActual, 3);
        end

        function convertsMjdToIntPlusSecOfDay(tc)
            lines = {
                'groops instrument version=20200123'
                '# ACCELEROMETER'
                '         -8          1'
                '# Time [MJD]  data0: x'
                '# ====='
                '          2'
                ' 58849.000000000000000000  1.0'
                ' 58849.500000000000000000  2.0'
            };
            f = tc.writeFile(lines);
            time = readGroopsInstrument(f);
            tc.verifyEqual(time(1,1), 58849);          % int MJD
            tc.verifyEqual(time(1,2), 0, 'AbsTol', 1e-6);
            tc.verifyEqual(time(2,1), 58849);
            tc.verifyEqual(time(2,2), 43200, 'AbsTol', 1e-3);  % noon
        end

        function dataValuesMatch(tc)
            lines = {
                'groops instrument version=20200123'
                '# ACCELEROMETER'
                '  -8   1'
                '# Time [MJD]  data0: x  data1: y  data2: z'
                '# ====='
                '   1'
                ' 58849.0  -1.244511187751508e-08  2.162361233255300e-08 -4.105381848786317e-09'
            };
            f = tc.writeFile(lines);
            [~, data] = readGroopsInstrument(f);
            tc.verifyEqual(data(1,:), ...
                [-1.244511187751508e-08, 2.162361233255300e-08, -4.105381848786317e-09], ...
                'RelTol', 1e-12);
        end

        function missingFileThrows(tc)
            tc.verifyError(@() readGroopsInstrument(fullfile(tc.workDir,'nope.txt')), ...
                'readGroopsInstrument:notFound');
        end

        function recordCountMismatchWarns(tc)
            lines = {
                'groops instrument version=1'
                '# ACCELEROMETER'
                '  -8   1'
                '# Time [MJD]  data0: x'
                '# ====='
                '          5'
                ' 58849.0  1.0'
                ' 58849.1  2.0'
            };
            f = tc.writeFile(lines);
            tc.verifyWarning(@() readGroopsInstrument(f), ...
                'readGroopsInstrument:recordCountMismatch');
        end

        function fallsBackToGenericColumnNames(tc)
            lines = {
                'groops instrument version=1'
                '# ACCELEROMETER'
                '  -8   1'
                '          1'
                ' 58849.0  1.0  2.0'
            };
            f = tc.writeFile(lines);
            [~,~,aux] = readGroopsInstrument(f);
            tc.verifyEqual(aux.columnNames, {'data0','data1'});
        end

    end
end
