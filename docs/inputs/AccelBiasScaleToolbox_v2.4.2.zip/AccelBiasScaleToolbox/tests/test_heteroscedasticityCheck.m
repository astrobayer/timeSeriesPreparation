classdef test_heteroscedasticityCheck < matlab.unittest.TestCase
%TEST_HETEROSCEDASTICITYCHECK  Unit tests for heteroscedasticityCheck.m

    methods (Test)

        function detectsMultiplicativeError(tc)
            n = 500;
            modelValue = linspace(1, 10, n)';
            residual = modelValue .* pseudoNoise(n); % error scales with |model|
            [rho, verdict] = heteroscedasticityCheck(residual, modelValue);
            tc.verifyGreaterThan(rho, 0.4);
            tc.verifyEqual(verdict, 'multiplicative-dominated');
        end

        function detectsAdditiveError(tc)
            n = 500;
            modelValue = linspace(1, 10, n)';
            residual = pseudoNoise(n); % error independent of |model|
            [rho, verdict] = heteroscedasticityCheck(residual, modelValue);
            tc.verifyLessThan(rho, 0.15);
            tc.verifyEqual(verdict, 'additive-dominated');
        end

        function constantModelIsIndeterminate(tc)
            n = 100;
            modelValue = ones(n,1);
            residual = pseudoNoise(n);
            [rho, verdict] = heteroscedasticityCheck(residual, modelValue);
            tc.verifyTrue(isnan(rho));
            tc.verifyEqual(verdict, 'indeterminate');
        end

        function fewSamplesIsIndeterminate(tc)
            [rho, verdict] = heteroscedasticityCheck([1;2;3], [1;2;3]);
            tc.verifyTrue(isnan(rho));
            tc.verifyEqual(verdict, 'indeterminate');
        end

    end
end

function y = pseudoNoise(n)
s = (1:n)';
y = mod(sin(s*12.9898)*43758.5453, 1) - 0.5;
end
