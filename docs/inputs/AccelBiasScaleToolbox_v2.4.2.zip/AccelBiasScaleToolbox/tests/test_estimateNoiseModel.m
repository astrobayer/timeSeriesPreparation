classdef test_estimateNoiseModel < matlab.unittest.TestCase
%TEST_ESTIMATENOISEMODEL  Unit tests for estimateNoiseModel.m
%   Python reference: for a true AR(2) with phi = [0.75, -0.20] and
%   n = 4000, Yule-Walker recovered [0.7648, -0.2098]; the lag-1
%   autocorrelation was 0.632 and n_eff/n = 0.328.

    methods (Test)

        function recoversKnownAR2Coefficients(tc)
            rng(7);
            n = 4000;
            phiTrue = [0.75; -0.20];
            e = randn(n+200, 1);
            x = zeros(n+200, 1);
            for k = 3:(n+200)
                x(k) = phiTrue(1)*x(k-1) + phiTrue(2)*x(k-2) + e(k);
            end
            x = x(201:end);

            nm = estimateNoiseModel(x, 'Order', 2);
            tc.verifyEqual(nm.phi, phiTrue, 'AbsTol', 0.05);
        end

        function whiteNoiseIsIidLike(tc)
            rng(3);
            x = randn(3000,1);
            nm = estimateNoiseModel(x);
            tc.verifyGreaterThan(nm.nEffRatio, 0.8);
            tc.verifyEqual(nm.verdict, 'iid-like');
            tc.verifyLessThan(abs(nm.acf1), 0.1);
        end

        function strongAR1IsFlaggedStronglyCorrelated(tc)
            rng(5);
            n = 3000;
            rho = 0.95;
            x = zeros(n,1);
            e = randn(n,1);
            for k = 2:n
                x(k) = rho*x(k-1) + e(k);
            end
            nm = estimateNoiseModel(x);
            tc.verifyLessThan(nm.nEffRatio, 0.3);
            tc.verifyEqual(nm.verdict, 'strongly-correlated');
            tc.verifyGreaterThan(nm.acf1, 0.8);
        end

        function effectiveSampleSizeNeverExceedsN(tc)
            rng(11);
            x = randn(500,1);
            nm = estimateNoiseModel(x);
            tc.verifyLessThanOrEqual(nm.nEff, 500 * 1.05);
        end

        function orderSelectionPrefersLowOrderForWhiteNoise(tc)
            rng(13);
            nm = estimateNoiseModel(randn(2000,1), 'MaxOrder', 8);
            tc.verifyLessThanOrEqual(nm.order, 2);
        end

        function shortSeriesDegradesGracefully(tc)
            nm = estimateNoiseModel(randn(5,1));
            tc.verifyEqual(nm.order, 0);
            tc.verifyEqual(nm.verdict, 'indeterminate');
        end

    end
end
