classdef test_accFrameToSRF < matlab.unittest.TestCase
%TEST_ACCFRAMETOSRF  Unit tests for accFrameToSRF.m
%   ATBD (JPL D-27672) section 3, step 7:
%       X_SRF = Z_ACC,  Y_SRF = X_ACC,  Z_SRF = Y_ACC

    methods (Test)

        function permutationMatrixIsCorrect(tc)
            P = accFrameToSRF();
            tc.verifyEqual(P, [0 0 1; 1 0 0; 0 1 0]);
        end

        function permutationIsAProperRotation(tc)
            % this is the trap: it is orthogonal with det = +1, so a
            % forgotten permutation looks like a legitimate rotation
            P = accFrameToSRF();
            tc.verifyEqual(P*P', eye(3), 'AbsTol', 1e-12);
            tc.verifyEqual(det(P), 1, 'AbsTol', 1e-12);
        end

        function permutationIs120DegreesAboutTheDiagonal(tc)
            P = accFrameToSRF();
            theta = acos((trace(P)-1)/2) * 180/pi;
            tc.verifyEqual(theta, 120, 'AbsTol', 1e-6);
        end

        function appliesTheRelabellingToAVectorSeries(tc)
            vACC = [1 2 3; 4 5 6];
            vSRF = accFrameToSRF(vACC);
            % X_SRF = Z_ACC, Y_SRF = X_ACC, Z_SRF = Y_ACC
            tc.verifyEqual(vSRF, [3 1 2; 6 4 5], 'AbsTol', 1e-12);
        end

        function checkFlagsAForgottenPermutationAsAFrameError(tc)
            % a scale matrix that is really just the permutation
            P = accFrameToSRF();
            S = P * diag([1.02 0.98 1.05]);
            d = accFrameToSRF('check', S);
            tc.verifyEqual(d.verdict, 'FRAME ERROR');
            tc.verifyTrue(d.isPermutation);
            tc.verifyEqual(d.angleDeg, 120, 'AbsTol', 1);
        end

        function checkAcceptsAPlausibleSmallMisalignment(tc)
            ang = [2000; -1000; 1500] * 1e-6;    % urad -- realistic
            W = [0 -ang(3) ang(2); ang(3) 0 -ang(1); -ang(2) ang(1) 0];
            th = norm(ang);
            R = eye(3) + (sin(th)/th)*W + ((1-cos(th))/th^2)*(W*W);
            S = R * diag([0.96 1.03 1.10]);

            d = accFrameToSRF('check', S);
            tc.verifyEqual(d.verdict, 'plausible');
            tc.verifyFalse(d.isPermutation);
            tc.verifyLessThan(d.angleDeg, 1);
        end

        function checkFlagsIdentityAsPlausible(tc)
            d = accFrameToSRF('check', eye(3));
            tc.verifyEqual(d.verdict, 'plausible');
            tc.verifyFalse(d.isPermutation);
        end

        function badSizeThrows(tc)
            tc.verifyError(@() accFrameToSRF(ones(4,2)), 'accFrameToSRF:badSize');
        end

        function badModeThrows(tc)
            tc.verifyError(@() accFrameToSRF('bogus', eye(3)), 'accFrameToSRF:badMode');
        end

    end
end
