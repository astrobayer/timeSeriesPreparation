classdef test_accelTimeVaryingScaleFit < matlab.unittest.TestCase
%TEST_ACCELTIMEVARYINGSCALEFIT  Unit tests for accelTimeVaryingScaleFit.m

    methods (Test)

        function recoversConstantScaleAsFlat(tc)
            rng(1);
            n = 3000; t = linspace(0, 6*3600, n)';
            y2 = 1 + 0.8*sin(2*pi*t/5400);
            y1 = 0.2 + 0.97*y2 + 0.005*randn(n,1);
            fit = accelTimeVaryingScaleFit(t, y1, y2, ...
                'NoiseModel', false, 'Robust', false);
            % a constant true scale should come back nearly flat, near 0.97
            tc.verifyEqual(mean(fit.scale), 0.97, 'AbsTol', 0.01);
            tc.verifyLessThan(fit.scaleDrift, 0.02);
            tc.verifyFalse(fit.isDriftSignificant);
        end

        function detectsAndRecoversSlowScaleDrift(tc)
            rng(2);
            n = 6000; t = linspace(0, 12*3600, n)';
            y2 = 1 + 0.8*sin(2*pi*t/5400) + 0.3*sin(2*pi*t/1200);
            sTrue = 1.0 + 0.05*sin(2*pi*t/(12*3600));
            y1 = 0.2 + sTrue.*y2 + 0.008*randn(n,1);
            fit = accelTimeVaryingScaleFit(t, y1, y2, ...
                'BiasKnots', 30, 'ScaleKnots', 3, 'NoiseModel', false);
            % mean recovered well; drift resolved above noise
            tc.verifyEqual(fit.scaleMean, mean(sTrue), 'AbsTol', 0.01);
            tc.verifyGreaterThan(fit.scaleDrift, 0.04);
            tc.verifyTrue(fit.isDriftSignificant);
        end

        function returnsPointwiseUncertaintyBands(tc)
            rng(3);
            n = 3000; t = linspace(0, 6*3600, n)';
            y2 = 1 + 0.8*sin(2*pi*t/5400);
            y1 = 0.2 + 1.0*y2 + 0.01*randn(n,1);
            fit = accelTimeVaryingScaleFit(t, y1, y2, 'NoiseModel', false);
            tc.verifyEqual(numel(fit.scaleSigma), n);
            tc.verifyEqual(numel(fit.biasSigma), n);
            tc.verifyGreaterThan(min(fit.scaleSigma), 0);
        end

        function smootherScaleReducesBiasScaleAliasing(tc)
            % the design choice: making the scale spline smoother than the
            % bias spline should IMPROVE bias recovery
            rng(4);
            n = 6000; t = linspace(0, 12*3600, n)';
            y2 = 1 + 0.8*sin(2*pi*t/5400) + 0.3*sin(2*pi*t/1200);
            sTrue = 1.0 + 0.05*sin(2*pi*t/(12*3600));
            bTrue = 0.2 + 0.1*cos(2*pi*t/(3*3600));
            y1 = bTrue + sTrue.*y2 + 0.008*randn(n,1);

            fitSmooth = accelTimeVaryingScaleFit(t, y1, y2, ...
                'BiasKnots', 30, 'ScaleKnots', 3, 'NoiseModel', false);
            fitEqual  = accelTimeVaryingScaleFit(t, y1, y2, ...
                'BiasKnots', 12, 'ScaleKnots', 12, 'ScaleLambda', 1e2, ...
                'NoiseModel', false);

            eSmooth = sqrt(mean((fitSmooth.bias - bTrue).^2));
            eEqual  = sqrt(mean((fitEqual.bias  - bTrue).^2));
            tc.verifyLessThan(eSmooth, eEqual);
        end

        function respectsZeroWeights(tc)
            rng(5);
            n = 3000; t = linspace(0, 6*3600, n)';
            y2 = 1 + 0.8*sin(2*pi*t/5400);
            y1 = 0.2 + 1.0*y2 + 0.01*randn(n,1);
            % corrupt a chunk but zero-weight it
            bad = 1000:1200;
            y1(bad) = y1(bad) + 100;
            w = ones(n,1); w(bad) = 0;
            fit = accelTimeVaryingScaleFit(t, y1, y2, 'Weights', w, ...
                'Robust', false, 'NoiseModel', false);
            % the corruption must not blow up the fit
            tc.verifyEqual(fit.scaleMean, 1.0, 'AbsTol', 0.05);
        end

    end
end
