classdef test_crnNormalization < matlab.unittest.TestCase
%TEST_CRNNORMALIZATION  The f0 (J2) normalisation of the CRN filter, and
%   what it does -- and does NOT -- do to the fitted bias and scale.
%
%   Reference numbers from an independent Python computation of the ATBD
%   Appendix B formulae.

    methods (Test)

        function gainDroopsAcrossTheOrbitalBand(tc)
            [h, info] = crnFilter('ACC');
            n = (0:numel(h)-1).' - info.Nh;
            g = @(f) abs(sum(h .* exp(-2i*pi*f*n/info.fs)));

            Torb = 5400;
            fRev = 1/Torb;

            % f0 = 0.37 mHz IS 2/rev -- the J2 line. Unit gain is pinned there.
            tc.verifyEqual(2*fRev, info.f0, 'RelTol', 0.01);

            tc.verifyEqual(g(0),        1.0004533, 'AbsTol', 1e-6);  % DC
            tc.verifyEqual(g(1*fRev),   1.0003397, 'AbsTol', 1e-6);
            tc.verifyEqual(g(2*fRev),   0.9999991, 'AbsTol', 1e-6);  % == f0
            tc.verifyEqual(g(3*fRev),   0.9994316, 'AbsTol', 1e-6);

            % the response is monotonically decreasing -- there is no
            % resonance or peculiarity, just a droop
            tc.verifyGreaterThan(g(0), g(fRev));
            tc.verifyGreaterThan(g(fRev), g(2*fRev));
            tc.verifyGreaterThan(g(2*fRev), g(3*fRev));
        end

        function correctlyNormalisedKernelRecoversTheScaleEXACTLY(tc)
            % The key result. The f0 normalisation does NOT entangle bias
            % with scale: filter the model with the SAME kernel the L1
            % processor used, and the scale comes back exactly.
            [h, info] = crnFilter('ACC');
            fs = info.fs;
            N = 60000;
            t = (0:N-1).'/fs;
            fRev = 1/5400;

            a = sin(2*pi*fRev*t) + 0.5*sin(4*pi*fRev*t) + 0.25*sin(2*pi*0.004*t);
            sTrue = 0.97;  bTrue = 0.30;

            acc1b = centred(bTrue + sTrue*a, h);      % the L1 product

            sFit = localScale(centred(a, h), acc1b);
            tc.verifyEqual(sFit, sTrue, 'RelTol', 1e-4);   % < 100 ppm
        end

        function wrongDCNormalisationCosts453ppmOfScale(tc)
            % THIS is the actual consequence of the f0 normalisation, and it
            % is why forcing sum(h) = 1 -- the natural thing to do -- is a bug.
            % The fitted scale is inversely proportional to the regressor's
            % overall gain, so renormalising the kernel scales the answer.
            [h, info] = crnFilter('ACC');
            fs = info.fs;
            N = 60000;
            t = (0:N-1).'/fs;
            fRev = 1/5400;

            a = sin(2*pi*fRev*t) + 0.5*sin(4*pi*fRev*t) + 0.25*sin(2*pi*0.004*t);
            sTrue = 0.97;
            acc1b = centred(0.30 + sTrue*a, h);

            hDC = h / sum(h);                          % WRONG: unit DC gain
            sWrong = localScale(centred(a, hDC), acc1b);

            ppm = (sWrong/sTrue - 1) * 1e6;
            tc.verifyEqual(ppm, 453.3, 'AbsTol', 20);
            tc.verifyEqual(sWrong/sTrue, info.dcGain, 'RelTol', 1e-4);
        end

        function fittedBiasIsInflatedByTheDCGain(tc)
            % The one irreducible residue: the observed bias is the TRUE bias
            % times |H(0)|. Not recoverable from the data -- and not a problem,
            % unless you compare it to an independently known physical bias.
            [h, info] = crnFilter('ACC');
            fs = info.fs;
            N = 60000;
            t = (0:N-1).'/fs;
            fRev = 1/5400;

            a = sin(2*pi*fRev*t) + 0.5*sin(4*pi*fRev*t);
            bTrue = 0.30;
            acc1b = centred(bTrue + 0.97*a, h);

            af = centred(a, h);
            X = [ones(N,1), af - mean(af)];
            c = X \ acc1b;
            bFit = c(1) - c(2)*mean(af);

            tc.verifyEqual(bFit/bTrue, info.dcGain, 'RelTol', 1e-3);
        end

        function biasKnotsFasterThanTheKernelSpanAreWarnedAbout(tc)
            % Bias structure faster than the 140.7 s kernel span cannot be
            % present in ACC1B at all: those coefficients estimate the
            % filter's null space.
            h = crnFilter('ACC');
            fs = 10;
            t = (0:1/fs:1800).';
            y2 = 1 + sin(2*pi*t/5400);
            y1 = 0.2 + 0.97*y2;

            spec = struct('ScaleModel','diagonal', ...
                'BiasModel', struct('type','spline', 'numInteriorKnots', 60, ...
                                    'placement','uniform'));   % ~30 s spacing

            tc.verifyWarning(@() accelBiasScaleModelFit(t, y1, y2, spec, ...
                'BiasFilter', h, 'Robust', false, 'NoiseModel', false), ...
                'accelBiasScaleModelFit:knotsBelowFilterSpan');
        end

        function wideBiasKnotsRaiseNoWarning(tc)
            h = crnFilter('ACC');
            fs = 10;
            t = (0:1/fs:18000).';
            y2 = 1 + sin(2*pi*t/5400);
            y1 = 0.2 + 0.97*y2;

            spec = struct('ScaleModel','diagonal', ...
                'BiasModel', struct('type','spline', 'numInteriorKnots', 5, ...
                                    'placement','uniform'));   % ~3000 s spacing

            tc.verifyWarningFree(@() accelBiasScaleModelFit(t, y1, y2, spec, ...
                'BiasFilter', h, 'Robust', false, 'NoiseModel', false));
        end

    end
end

% -------------------------------------------------------------------
function s = localScale(m, o)
X = [ones(numel(m),1), m - mean(m)];
c = X \ o;
s = c(2);
end

function y = centred(x, h)
h = h(:);
Nh = (numel(h)-1)/2;
np = min(round(Nh), numel(x)-1);
xp = [2*x(1) - flipud(x(2:np+1)); x; 2*x(end) - flipud(x(end-np:end-1))];
yf = conv(xp, h, 'same');
y = yf(np+1 : np+numel(x));
end
