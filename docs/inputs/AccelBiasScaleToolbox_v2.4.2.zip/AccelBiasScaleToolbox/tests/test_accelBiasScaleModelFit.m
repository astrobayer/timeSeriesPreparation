classdef test_accelBiasScaleModelFit < matlab.unittest.TestCase
%TEST_ACCELBIASSCALEMODELFIT  Unit tests for accelBiasScaleModelFit.m

    methods (Test)

        function diagonalConstantRecoversTruth(tc)
            n = 800;
            tA = linspace(0,100,n)';
            Y2A = [1+sin(0.1*tA), 1+cos(0.1*tA), 1+sin(0.05*tA)];
            biasTrue  = [0.10, -0.20, 0.05];
            scaleTrue = [1.02, 0.98, 1.10];
            Y1A = biasTrue + scaleTrue .* Y2A;

            spec = struct('ScaleModel','diagonal', ...
                'BiasModel', struct('type','constant'));
            fit = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, ...
                'Robust', false, 'NoiseModel', false);

            tc.verifyEqual(diag(fit.S)', scaleTrue, 'AbsTol', 1e-6);
            for i = 1:3
                tc.verifyEqual(mean(fit.axis(i).biasFitted), biasTrue(i), 'AbsTol', 1e-6);
                tc.verifyEqual(fit.axis(i).R2, 1, 'AbsTol', 1e-8);
            end
        end

        function fullScaleRecoversOffDiagonalCoupling(tc)
            n = 800;
            tA = linspace(0,100,n)';
            Y2A = [sin(0.1*tA), cos(0.13*tA), sin(0.05*tA)];
            Strue = [1.00 0.05 0.00
                     0.02 0.95 0.01
                     0.00 0.00 1.10];
            Y1A = Y2A * Strue';

            spec = struct('ScaleModel','full', ...
                'BiasModel', struct('type','constant'));
            fit = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, ...
                'Robust', false, 'NoiseModel', false);
            tc.verifyEqual(fit.S, Strue, 'AbsTol', 1e-6);
        end

        function demeaningDoesNotChangeTheFittedScaleOrBias(tc)
            n = 600;
            tA = linspace(0,100,n)';
            Y2A = 100 + [sin(0.1*tA), cos(0.1*tA), sin(0.05*tA)];  % big offset
            Y1A = [0.1 -0.2 0.05] + [1.02 0.98 1.10] .* Y2A;

            spec = struct('ScaleModel','diagonal', ...
                'BiasModel', struct('type','constant'));
            fD = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, 'Demean', true,  ...
                'Robust', false, 'NoiseModel', false);
            fR = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, 'Demean', false, ...
                'Robust', false, 'NoiseModel', false);

            tc.verifyEqual(diag(fD.S), diag(fR.S), 'AbsTol', 1e-6);
            tc.verifyEqual(fD.axis(1).biasFitted, fR.axis(1).biasFitted, 'AbsTol', 1e-5);
        end

        function customMaskEstimatesOnlySelectedEntries(tc)
            n = 400;
            tA = linspace(0,50,n)';
            Y2A = [sin(0.2*tA), cos(0.2*tA)];
            Y1A = [Y2A(:,1) + 0.3*Y2A(:,2), Y2A(:,2)];

            spec = struct('ScaleModel', [true true; false true], ...
                'BiasModel', struct('type','constant'));
            fit = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, ...
                'Robust', false, 'NoiseModel', false);

            tc.verifyEqual(fit.axis(1).scaleAxes, [1 2]);
            tc.verifyEqual(fit.axis(2).scaleAxes, 2);
            tc.verifyTrue(isnan(fit.S(2,1)));
        end

        function psplineBiasTracksSmoothDrift(tc)
            n = 800;
            tA = linspace(0,100,n)';
            y2 = 1 + sin(0.3*tA);
            biasTrue = 0.2*sin(2*pi*tA/100);
            y1 = biasTrue + 1.5*y2;

            spec = struct('ScaleModel','diagonal', ...
                'BiasModel', struct('type','pspline','numInteriorKnots',25));
            fit = accelBiasScaleModelFit(tA, y1, y2, spec, ...
                'Robust', false, 'NoiseModel', false, 'LambdaSelect','gcv');

            tc.verifyEqual(fit.S(1,1), 1.5, 'AbsTol', 0.02);
            tc.verifyLessThan(std(fit.axis(1).biasFitted - biasTrue), 0.02);
        end

        function decompositionIsAttachedForThreeAxes(tc)
            n = 500;
            tA = linspace(0,100,n)';
            Y2A = [sin(0.1*tA), cos(0.13*tA), sin(0.07*tA)];
            Y1A = Y2A * diag([1.05 0.97 1.2])';

            spec = struct('ScaleModel','full', ...
                'BiasModel', struct('type','constant'));
            fit = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, ...
                'Robust', false, 'NoiseModel', false);

            tc.verifyNotEmpty(fit.decomp);
            tc.verifyEqual(fit.decomp.scales, [1.05;0.97;1.2], 'AbsTol', 1e-4);
        end

        function unknownScaleModelThrows(tc)
            tA = (1:10)';
            spec = struct('ScaleModel','bogus','BiasModel',struct('type','constant'));
            tc.verifyError(@() accelBiasScaleModelFit(tA, ones(10,1), ones(10,1), spec), ...
                'accelBiasScaleModelFit:unknownScaleModel');
        end

    end
end
