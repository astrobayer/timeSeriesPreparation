classdef test_blockedCrossVal < matlab.unittest.TestCase
%TEST_BLOCKEDCROSSVAL  Unit tests for blockedCrossVal.m
%   Python reference (AR(1) rho=0.95): blocked CV gave RSS 4.2e3 for a
%   smooth-bias model and 9.2e6 for an over-rich one -- a decisive
%   separation that AIC/BIC and random-fold CV both blur.

    methods (Test)

        function penalizesOverRichModelUnderColoredNoise(tc)
            rng(1);
            n = 1000;
            t = linspace(0,100,n)';
            nz = zeros(n,1); e = 0.1*randn(n,1);
            for k = 2:n, nz(k) = 0.95*nz(k-1) + e(k); end
            y = 0.5 + 2*sin(0.3*t) + nz;

            Xsmooth = [bsplineBasis(t, 2,  4), sin(0.3*t)];
            Xrich   = [bsplineBasis(t, 40, 4), sin(0.3*t)];

            cvS = blockedCrossVal(Xsmooth, y, 'NumFolds', 5);
            cvR = blockedCrossVal(Xrich,   y, 'NumFolds', 5);

            tc.verifyLessThan(cvS.rss, cvR.rss);
        end

        function inSampleRSSWouldHavePreferredTheOverRichModel(tc)
            % demonstrates WHY blocked CV is needed: in-sample fit always
            % improves with complexity, so it cannot be a selection criterion
            rng(1);
            n = 1000;
            t = linspace(0,100,n)';
            nz = zeros(n,1); e = 0.1*randn(n,1);
            for k = 2:n, nz(k) = 0.95*nz(k-1) + e(k); end
            y = 0.5 + 2*sin(0.3*t) + nz;

            Xsmooth = [bsplineBasis(t, 2,  4), sin(0.3*t)];
            Xrich   = [bsplineBasis(t, 40, 4), sin(0.3*t)];

            rssS = sum((y - Xsmooth*(Xsmooth\y)).^2);
            rssR = sum((y - Xrich  *(Xrich  \y)).^2);
            tc.verifyLessThan(rssR, rssS);   % over-rich wins IN sample ...

            cvS = blockedCrossVal(Xsmooth, y, 'NumFolds', 5);
            cvR = blockedCrossVal(Xrich,   y, 'NumFolds', 5);
            tc.verifyLessThan(cvS.rss, cvR.rss);   % ... and loses OUT of sample
        end

        function recoversTrueModelWithWhiteNoise(tc)
            rng(2);
            n = 500;
            t = linspace(0,10,n)';
            y = 1 + 2*t + 0.1*randn(n,1);

            Xtrue = [ones(n,1), t];
            Xover = [ones(n,1), t, t.^2, t.^3, t.^4, t.^5];

            cvT = blockedCrossVal(Xtrue, y, 'NumFolds', 5);
            cvO = blockedCrossVal(Xover, y, 'NumFolds', 5);
            tc.verifyLessThan(cvT.rss, cvO.rss);
        end

        function gapPurgesAdjacentTrainingSamples(tc)
            rng(3);
            n = 400;
            X = [ones(n,1), randn(n,1)];
            y = X*[1;2] + 0.1*randn(n,1);
            cv0 = blockedCrossVal(X, y, 'NumFolds', 4, 'Gap', 0);
            cvG = blockedCrossVal(X, y, 'NumFolds', 4, 'Gap', 20);
            tc.verifyEqual(cv0.nPredicted, cvG.nPredicted);   % same test sets
            tc.verifyEqual(cvG.gap, 20);
        end

        function foldsCoverEveryObservationExactlyOnce(tc)
            n = 100;
            X = [ones(n,1), (1:n)'];
            y = randn(n,1);
            cv = blockedCrossVal(X, y, 'NumFolds', 5);
            tc.verifyEqual(cv.nPredicted, n);
        end

    end
end
