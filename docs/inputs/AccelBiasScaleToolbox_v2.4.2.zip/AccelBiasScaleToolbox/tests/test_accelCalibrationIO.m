classdef test_accelCalibrationIO < matlab.unittest.TestCase
%TEST_ACCELCALIBRATIONIO  Unit tests for accelCalibrationIO.m

    methods (Test)

        function saveAndLoadStaticFitRoundTrips(tc)
            n = 400; tA = linspace(0,100,n)';
            Y2 = [sin(0.1*tA), cos(0.13*tA), sin(0.07*tA)];
            Strue = diag([1.02 0.98 1.10]);
            Y1 = Y2 * Strue';
            spec = struct('ScaleModel','full','BiasModel',struct('type','constant'));
            fit = accelBiasScaleModelFit(tA, Y1, Y2, spec, ...
                'Robust', false, 'NoiseModel', false);

            f = [tempname '.mat'];
            accelCalibrationIO('save', f, fit, 'Meta', struct('sat','GRACE-C'));
            cal = accelCalibrationIO('load', f);
            delete(f);

            tc.verifyEqual(cal.type, 'static');
            tc.verifyEqual(cal.S, fit.S, 'AbsTol', 1e-10);
            tc.verifyEqual(cal.provenance.meta.sat, 'GRACE-C');
            tc.verifyTrue(isfield(cal.provenance, 'toolboxVersion'));
        end

        function provenanceRecordsFilterInfo(tc)
            % the point of provenance: a scale is meaningless without knowing
            % how it was produced (esp. the filter normalization)
            n = 300; tA = linspace(0,50,n)';
            Y2 = [sin(0.2*tA), cos(0.2*tA), sin(0.1*tA)];
            Y1 = Y2;
            spec = struct('ScaleModel','diagonal','BiasModel',struct('type','constant'));
            fit = accelBiasScaleModelFit(tA, Y1, Y2, spec, ...
                'Robust', false, 'NoiseModel', false);
            f = [tempname '.mat'];
            accelCalibrationIO('save', f, fit, 'Meta', struct('filterDCGain', 1.0004533));
            cal = accelCalibrationIO('load', f);
            delete(f);
            tc.verifyEqual(cal.provenance.meta.filterDCGain, 1.0004533, 'AbsTol', 1e-9);
        end

        function jsonFormatRoundTrips(tc)
            n = 300; tA = linspace(0,50,n)';
            Y2 = [sin(0.2*tA), cos(0.2*tA), sin(0.1*tA)];
            Y1 = Y2 * diag([1.05 0.97 1.2])';
            spec = struct('ScaleModel','full','BiasModel',struct('type','constant'));
            fit = accelBiasScaleModelFit(tA, Y1, Y2, spec, ...
                'Robust', false, 'NoiseModel', false);
            f = [tempname '.json'];
            accelCalibrationIO('save', f, fit, 'Format', 'json');
            cal = accelCalibrationIO('load', f);
            delete(f);
            tc.verifyEqual(cal.S, fit.S, 'AbsTol', 1e-8);
        end

        function timeVaryingFitStored(tc)
            rng(1);
            n = 2000; t = linspace(0,6*3600,n)';
            y2 = 1 + 0.8*sin(2*pi*t/5400);
            y1 = 0.2 + 1.0*y2 + 0.01*randn(n,1);
            tv = accelTimeVaryingScaleFit(t, y1, y2, 'NoiseModel', false);
            f = [tempname '.mat'];
            accelCalibrationIO('save', f, tv);
            cal = accelCalibrationIO('load', f);
            delete(f);
            tc.verifyEqual(cal.type, 'time-varying');
            tc.verifyEqual(cal.timeVarying.scale, tv.scale, 'AbsTol', 1e-10);
        end

        function badModeThrows(tc)
            tc.verifyError(@() accelCalibrationIO('bogus'), ...
                'accelCalibrationIO:badMode');
        end

    end
end
