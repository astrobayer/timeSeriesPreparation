classdef test_lombScarglePSD < matlab.unittest.TestCase
%TEST_LOMBSCARGLEPSD  Unit tests for lombScarglePSD.m

    methods (Test)

        function recoversKnownFrequencyOnUniformGrid(tc)
            t = (0:0.01:100)';
            f0 = 0.37;
            y = sin(2*pi*f0*t);
            [P, f] = lombScarglePSD(t, y);
            [~, iMax] = max(P);
            tc.verifyEqual(f(iMax), f0, 'AbsTol', 0.01);
        end

        function recoversKnownFrequencyOnUNEVENGrid(tc)
            % the whole point: works without resampling or interpolation
            rng(1);
            t = sort(100*rand(2000,1));
            f0 = 0.37;
            y = sin(2*pi*f0*t);
            [P, f] = lombScarglePSD(t, y);
            [~, iMax] = max(P);
            tc.verifyEqual(f(iMax), f0, 'AbsTol', 0.02);
        end

        function survivesLargeGapsWithoutSpuriousPower(tc)
            % gap-interpolating and running pwelch would inject a smooth
            % ramp across the hole; Lomb-Scargle never sees fabricated data
            f0 = 0.2;
            t = [(0:0.05:30)'; (70:0.05:100)'];
            y = sin(2*pi*f0*t);
            [P, f] = lombScarglePSD(t, y);
            [~, iMax] = max(P);
            tc.verifyEqual(f(iMax), f0, 'AbsTol', 0.02);
        end

        function meanIsRemoved(tc)
            t = (0:0.1:100)';
            y = 1000 + sin(2*pi*0.3*t);     % huge offset
            [P, f] = lombScarglePSD(t, y);
            [~, iMax] = max(P);
            tc.verifyEqual(f(iMax), 0.3, 'AbsTol', 0.02);  % offset does not dominate
        end

        function acceptsExplicitFrequencyGrid(tc)
            t = (0:0.1:50)';
            y = sin(2*pi*0.25*t);
            fGrid = (0.01:0.01:1)';
            [P, f] = lombScarglePSD(t, y, 'Freq', fGrid);
            tc.verifyEqual(f, fGrid);
            tc.verifyEqual(numel(P), numel(fGrid));
        end

        function tooShortReturnsEmpty(tc)
            [P, f] = lombScarglePSD([1;2], [1;2]);
            tc.verifyEmpty(P);
            tc.verifyEmpty(f);
        end

        function nonFiniteSamplesAreDropped(tc)
            t = (0:0.1:50)';
            y = sin(2*pi*0.25*t);
            y([10 20 30]) = NaN;
            [P, f] = lombScarglePSD(t, y);
            [~, iMax] = max(P);
            tc.verifyEqual(f(iMax), 0.25, 'AbsTol', 0.02);
        end

    end
end
