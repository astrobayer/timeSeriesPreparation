classdef test_accelBiasScaleModelCompare < matlab.unittest.TestCase
%TEST_ACCELBIASSCALEMODELCOMPARE  Unit tests for accelBiasScaleModelCompare.m

    methods (Test)

        function rankedByBlockedCVNotInSampleFit(tc)
            rng(1);
            n = 800;
            t = linspace(0,200,n)';
            y2 = 1 + sin(0.05*t);
            nz = zeros(n,1); e = 0.01*randn(n,1);
            for k = 2:n, nz(k) = 0.9*nz(k-1) + e(k); end
            y1 = 0.2 + 1.3*y2 + nz;

            specs = {};
            specs{end+1} = struct('label','const','ScaleModel','diagonal', ...
                'BiasModel', struct('type','constant'));
            specs{end+1} = struct('label','spline100','ScaleModel','diagonal', ...
                'BiasModel', struct('type','spline','numInteriorKnots',100));

            cmp = accelBiasScaleModelCompare(t, y1, t, y2, specs, ...
                'PlotDiagnostics', false, 'NoiseModel', false);

            % the over-rich model has the better IN-SAMPLE R2 ...
            iRich = find(strcmp(cmp.labels,'spline100'));
            iSimp = find(strcmp(cmp.labels,'const'));
            tc.verifyGreaterThan(cmp.fits{iRich}.axis(1).R2, ...
                                 cmp.fits{iSimp}.axis(1).R2);
            % ... but must not win the blocked-CV ranking
            tc.verifyEqual(cmp.table.Model{1}, 'const');
        end

        function allModelsScoredOnIdenticalRows(tc)
            n = 300;
            t = linspace(0,50,n)';
            y1 = ones(n,1); y2 = 1 + sin(t);
            specs = {struct('label','a','ScaleModel','diagonal', ...
                        'BiasModel',struct('type','constant')), ...
                     struct('label','b','ScaleModel','diagonal', ...
                        'BiasModel',struct('type','polynomial','order',1))};
            cmp = accelBiasScaleModelCompare(t, y1, t, y2, specs, ...
                'PlotDiagnostics', false, 'NoiseModel', false);
            tc.verifyEqual(cmp.fits{1}.tA, cmp.fits{2}.tA);
        end

        function tableFlagsUnreliableInformationCriteria(tc)
            rng(2);
            n = 600;
            t = linspace(0,100,n)';
            y2 = 1 + sin(0.1*t);
            nz = zeros(n,1); e = 0.02*randn(n,1);
            for k = 2:n, nz(k) = 0.95*nz(k-1) + e(k); end
            y1 = 1.2*y2 + nz;

            specs = {struct('label','const','ScaleModel','diagonal', ...
                'BiasModel', struct('type','constant'))};
            cmp = accelBiasScaleModelCompare(t, y1, t, y2, specs, ...
                'PlotDiagnostics', false, 'NoiseModel', true);

            % residuals are strongly correlated => AIC/BIC must be flagged
            tc.verifyTrue(cmp.table.IC_unreliable(1));
            tc.verifyEqual(cmp.table.NoiseVerdict{1}, 'strongly-correlated');
        end

        function filterStrategyIsApplied(tc)
            n = 2000;
            t = (0:n-1)';
            y2 = sin(2*pi*0.004*t) + 0.5*sin(2*pi*0.15*t);
            y1 = y2;
            specs = {struct('label','const','ScaleModel','diagonal', ...
                'BiasModel', struct('type','constant'))};
            cmp = accelBiasScaleModelCompare(t, y1, t, y2, specs, ...
                'FilterStrategy', 'commonmode', 'FilterCutoff', 0.02, ...
                'PlotDiagnostics', false, 'NoiseModel', false);
            tc.verifyNotEmpty(cmp.filterInfo);
            tc.verifyEqual(cmp.filterInfo.strategy, 'commonmode');
        end

    end
end
