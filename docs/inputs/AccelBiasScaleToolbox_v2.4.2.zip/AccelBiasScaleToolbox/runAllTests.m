%RUNALLTESTS  Run the AccelBiasScaleToolbox test suite.
%   Adds src/ to the path, discovers every test in tests/, and reports.
%
%   The integration tests (test_integration_endToEnd) are the important
%   ones: they score the whole pipeline against injected ground truth with
%   every defect present simultaneously.

thisDir = fileparts(mfilename('fullpath'));
addpath(fullfile(thisDir, 'src'));
addpath(fullfile(thisDir, 'src', 'io'));   % vendored L1B readers

suite  = matlab.unittest.TestSuite.fromFolder(fullfile(thisDir, 'tests'));
runner = matlab.unittest.TestRunner.withTextOutput('Verbosity', 2);
results = runner.run(suite);

fprintf('\n%d passed, %d failed, %d incomplete (of %d)\n', ...
    nnz([results.Passed]), nnz([results.Failed]), ...
    nnz([results.Incomplete]), numel(results));

if any([results.Failed])
    disp(table(results([results.Failed])));
end
