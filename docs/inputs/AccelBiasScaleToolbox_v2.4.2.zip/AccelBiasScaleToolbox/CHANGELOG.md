# Changelog

## v2.4.2 - R2026a test fixes, second pass

Clears the 3 non-tolerance failures the first pass missed (37 -> 10 -> ~6).
See `TEST_FIXES_R2026a.md`.

### Fixed
- **`crnFilter` legacy cutoff calibration.** The v2.4.1 `legacyLowpass` shim
  sized its boxcar as `0.443*fs/fc*sqrt(nc)` but should divide by `sqrt(nc)`;
  the wrong sign put the -3 dB point near 0.004 Hz instead of the requested
  0.02 Hz, attenuating in-band signal to ~72% and re-introducing a scale bias.
  Corrected the formula; verified proper -3 dB at cutoff, flat passband, unit
  DC gain, symmetry. This clears `test_analyzeAccArc/runsEndToEndAndRecoversScales`
  and `test_integration_endToEnd/recoversMisalignmentAnglesAndScales`.
- **`test_filterConsistency` observation double-filtering.** The headline
  filter-mismatch test built its observation with a forward-backward (H^2) pass
  while `filterConsistency('explicit')` corrects with a single centred (H) pass;
  H^2 vs H is itself a scale bias. The test now filters once, centred, matching
  real ACC_1B production.
- **`reportsSigmaInflation` noise-free data.** The test asserted block-bootstrap
  sigma exceeds naive sigma on data that had no noise (hence no residual to
  inflate). `writePair` gained optional AR(1) noise parameters (default 0), and
  the test now injects coloured noise; inflation ~10 >> 1.5. (The v2.4.1 QR
  rewrite of the naive sigma remains as a genuine stability fix for the RCOND
  warnings.)

## v2.4.1 - R2026a test fixes

Fixes for failures surfaced by `runAllTests` on MATLAB R2026a. See
`TEST_FIXES_R2026a.md` for the full analysis. None of the v2.4 feature code was
at fault; these are pre-existing issues plus one inherited bootstrap bug.

### Fixed
- **`crnFilter` legacy signature (27 test failures).** Added a
  backward-compatibility shim: calls of the old form
  `crnFilter(fs, 'Cutoff', fc, 'NumConv', N)` (still used by
  `syntheticAccelPair` and `test_filterConsistency`) now route to a local
  `legacyLowpass` builder, while the ATBD path `crnFilter('ACC'|'KBR', ...)` is
  unchanged. This unblocked `test_filterConsistency`, `test_syntheticAccelPair`,
  `test_analyzeAccArc`, and `test_integration_endToEnd`.
- **`analyzeAccScaleArc` bootstrap naive-sigma.** Replaced `var(r)*inv(X'X)` on
  the badly-scaled raw design (condition ~1e16, source of the `RCOND` warnings)
  with a standardized-regressor QR solve. Fixes
  `test_analyzeAccScaleArc/reportsSigmaInflation` and removes the warnings.
- **`alignAccelSeries` NaN handling.** R2026a's `interp1` interpolates across
  NaNs in the source data, so a NaN epoch was no longer dropped. Now propagates
  source-NaN explicitly via a resampled finiteness mask. Fixes
  `test_alignAccelSeries/jointAcrossAxes`.
- **Two brittle test setups corrected**: `test_scaleObservability`
  (`sin(t)` over `[0,10]` is not zero-mean — now demeaned) and
  `test_slidingWindowFit` (large-offset regressor was gated unobservable — now
  runs with `GateObservable=false` since it targets the bias parameterization).

### Known remaining (see TEST_FIXES_R2026a.md)
~7 penalized-regression tolerance failures (`test_gcvSelectLambda`,
`test_glsLinearFit`, `test_robustLinearFit`, `test_accelTimeVaryingScaleFit`,
`test_crnFilterATBD/derivativeKernel`) left for offline triage — they depend on
penalized-spline / GCV numerics that drifted under R2026a and shouldn't be
"fixed" by loosening tolerances without verifying against the algorithms.

## v2.4 - multi-day cause attribution

### Added
- **`scaleFactorDiagnostics`** - the multi-day "next step" from the roadmap. Given a
  multi-day arc's per-revolution scale (from `analyzeAccScaleArc`) and per-rev
  space-weather / orbit-geometry indices, it standardizes the predictors, multiple-regresses
  the per-rev scale on them with block-bootstrap confidence intervals, and votes the dominant
  significant predictor's family into a **cause**: `density` (thermosphere-model error, tracks
  F10.7/Kp/Dst), `geometry` (Cd/attitude error, tracks β/arg-lat only), `sensor` (secular
  drift), `mixed`, or `unresolved`. This is the direct path from "the model and data disagree"
  to a specific, fixable term in the force model. An `MinR2` floor and degenerate-column
  dropping guard against spurious attribution on flat or collinear designs.
- **`loadSpaceWeatherIndices`** - the per-rev index loader that feeds it. Parses the GFZ
  combined daily file (`Kp_ap_Ap_SN_F107_since_1932.txt`, or the nowcast/yearly variants) per
  the published fixed-width format, computes the 81-day centred F10.7 average, and maps
  F10.7/F10.7a/Kp/Ap/SN onto each per-rev window via `startMJD` + `perRev.tMid`. Daily indices
  are held across the whole UT day by day-membership (not nearest-to-noon); 3-hourly Kp/ap are
  interpolated. Orbit geometry (β, arg-lat, Dst) merges in through `'Extra'`. Returns both the
  per-rev `indices` struct and the fully parsed `raw` daily table.
- **`analyzeAccScaleArc` new outputs**: `.accel` (observed and modeled accelerations on the
  common analysis grid actually used for the fit) and `.correction` (the estimated bias+scale
  calibration reconciling the two inputs, in both obs→model and model→obs directions, each with
  a ready-to-use `apply` handle, ppm scale error, bootstrap CIs, and a force-model-vs-sensor
  caveat). Also exposes `.startMJD`, the absolute-time anchor for `perRev.tMid`, and a run-time
  `.provenance` stamp (date/time, toolbox, Claude version).

### Tests
- `test_scaleFactorDiagnostics` (11 methods): density/geometry/sensor/flat attribution, the
  R²/rev-count guards, quiet-arc and missing-activity flags, NaN handling, provenance.
- `test_loadSpaceWeatherIndices` (12 methods): GFZ parse, per-rev mapping, daily-value hold,
  Kp interpolation, adjusted-F10.7 selection, F107a averaging, out-of-range flagging,
  result-struct form, `'Extra'` merge, and end-to-end into `scaleFactorDiagnostics`.
- New per-output tests in `test_analyzeAccScaleArc` for `.accel`, `.correction` (round-trip
  and reconstruction), and provenance.
- `examples/example_07_multiDayDiagnostics.m` demonstrates the full loader→diagnostics chain.

### Notes
- The multi-day pipeline is end-to-end in MATLAB, but every numeric was cross-validated in
  Python against byte-identical synthetic GFZ data (parser, interpolation semantics, and the
  density/geometry/sensor verdicts). Run `runAllTests` in MATLAB to confirm in-environment.

## v2.3 - single-call real-data analysis

### Added
- **`analyzeAccScaleArc`** - the streamlined single entry point. Give it the observed
  ACC1B/ACT1B file(s) and the GROOPS model file(s), for **one day or many**, and it:
  reads them (via the user's L1B readers + the new GROOPS reader), reconciles the time
  systems by 0-to-0 day alignment plus a cross-correlation lag refinement, makes the model
  CRN-filter-consistent, fits a whole-arc and per-revolution scale per axis with
  observability gating, block-bootstraps the uncertainty, correlates per-rev scale with
  modeled drag magnitude, and returns a plain-language per-axis interpretation
  (well-calibrated / sensor scale error / force-model deficiency / sensor drift) plus a
  consolidated caveat list. Single day vs multi-day is transparent - just pass one file or a list.
- **`readGroopsInstrument`** - reader for GROOPS instrument-format ASCII model files
  (the L1B readers do not cover this format). Returns `[intMJD, secOfDay]` time to match.
- **`plotScaleArc`** - the four-panel summary figure (obs vs scaled model; per-rev scale +
  drag; scale-vs-drag scatter; naive vs bootstrap error bars).
- User-provided `readGraceFoL1b`/`readGraceFoL1bMulti` vendored under `src/io/` so the
  toolbox runs standalone (attributed; override by putting your own copies earlier on path).

### Validated on real data (GRACE-C, 2020-01-01)
- Model explains 96-97% of observed variance per axis. Diagonal scales X 0.915, Y 1.035,
  Z 1.057. Naive error bars 5-14x too small (block-bootstrap). Per-rev scale is a **real
  drift** (SNR 6.8-18.3), and it **anti-correlates with modeled drag** on the drag axes
  (X r=-0.70, Y r=-0.74; Z n.s.) - the signature of a density/Cd force-model deficiency,
  not a sensor error. This reproduced and explained the opening "scale varies a lot" symptom.
- Time-system lesson baked into the wrapper: align on the UTC day boundary first; a botched
  MJD->GPS conversion was the sole cause of three failed alignment attempts.


## v2.2 — time-varying scale, edge handling, orchestration

### Added
- **`accelTimeVaryingScaleFit`** — fits scale AND bias as penalized splines, `y1 = b(t) + s(t)*y2`.
  A static scale fit of a drifting scale reports only the mean and dumps the drift into the
  residual, where it looks like colored noise (measured: static residual lag-1 acf **0.84**).
  **This is a likely part of the original "scale varies a lot" symptom** — a real slow drift a
  static model cannot represent. Scale is deliberately smoother than bias to break aliasing;
  returns a pointwise uncertainty band and an `isDriftSignificant` flag, because slow scale
  drift sits near the collinearity floor and should not be over-interpreted.
- **`flagEdgeEffects`** — the 140.7 s CRN kernel corrupts ~70 s at each segment end (reflection
  padding only approximates the missing neighbors). With 20 gaps that's ~3.5% of a day. Returns
  a zero/taper weight vector to exclude or down-weight those samples.
- **`analyzeAccArc`** — one-call pipeline (preflight → filter → edge-weight → model-select → fit
  → decompose → frame-check → report) with GRACE-FO defaults and a consolidated caveat list.
  Getting the sequence or options wrong by hand is a 450+ ppm mistake; this prevents it.
- **`accelCalibrationIO`** — save/load fitted parameters, covariance, decomposition, and a
  **provenance** block (toolbox version, filter product, filter DC gain, strategy). A scale is
  not interpretable without knowing which filter normalization produced it.
- `accelBiasScaleModelFit` gained `'BiasFilter'` (filter the bias basis; correct design `[H·B, H·a]`)
  and the knot-spacing identifiability floor (v2.1).


## v2.1 — GRACE L1B ATBD (JPL D-27672) incorporated

The ATBD closes the one genuine gap in v2.0: the CRN filter is now **exact**, not guessed.

### Fixed (both were real, both biased the scale factor)
- **`crnFilter` was an approximation and it was badly wrong.** Replaced with the exact
  Appendix-B specification. ACC: `fs=10 Hz, Nc=7, Tf=140.7 s → Nf=1407 taps, NB=5`,
  realised bandwidth `NB/Tf = 0.03554 Hz`. Measured: the old approximation passed **0.81**
  at 0.035 Hz where the true filter passes **0.011** — a factor of 70. Correcting the
  filter mismatch with the *approximate* kernel still left a **−11.5%** scale error
  (truth 1.000 → 0.885). With the exact kernel: **1.0000**.
- **`filterConsistency` was filtering forward–backward**, applying the kernel twice and
  squaring its response. The CRN kernel is symmetric and already linear-phase; it must be
  applied as a single centred pass.

### Added
- `applyCrnFilter` — reproduces the ACC_1B chain properly: lift the model to 10 Hz, convolve
  with the CRN kernel, **sample** (not average) at 1 Hz.
- `accFrameToSRF` — the ATBD §3 step 7 relabelling (`X_SRF=Z_ACC, Y_SRF=X_ACC, Z_SRF=Y_ACC`).
  It is a **proper rotation** (det = +1, 120° about (1,1,1)), so a forgotten permutation
  masquerades as a well-formed misalignment in a fitted `S` and the fit will not complain.
  `accFrameToSRF('check', S)` detects it.
- `estimateNoiseModel('ExcludeMask', ...)` — ACC_1B gaps are **cubic-interpolated** by the
  L1 processor (up to 100 s, ATBD App. A) and flagged. Those samples are deterministic, not
  measured; feeding them to an autocorrelation estimator deflates `n_eff` and inflates every
  error bar derived from it. Exclude them.
- `crnFilter` also returns the first/second-derivative kernels (ATBD App. B).

### Discovered
- **The CRN filter is normalised to unit gain at f0 = 0.37 mHz (the J2 line), not at DC.**
  Its true DC gain is **1.0004533**. ACC_1B therefore carries a deliberate ~450 ppm gain
  difference between a constant acceleration and the J2-band signal — comparable to the
  scale-factor precision being sought. Forcing `sum(h) = 1`, which v2.0 did and which is the
  natural thing to do, *introduces* this error rather than fixing it.

## v2.0

Rebuilt around four measured findings (see `doc/AccelBiasScaleToolbox_Reference.pdf`).

### Added
- `scaleObservability` — detects when scale is *not identifiable* (the usual cause of a
  "wild" scale factor). Measured: `corr(bias, scale) = -1.0000` exactly on a quiet arc.
- `filterConsistency`, `crnFilter` — ACC1B is low-pass filtered, a pointwise force model
  is not. Measured: uncorrected, this alone drove the fitted scale to **0.489** against a
  truth of 1.000.
- `estimateNoiseModel`, `prewhitenSeries`, `glsLinearFit` — AR noise model, feasible GLS,
  honest covariance. Measured: naive iid sigmas are **5.0x** too small at rho = 0.95.
- `blockBootstrap` — moving-block CIs, no parametric noise assumption.
- `blockedCrossVal` — contiguous-fold CV. Measured: AIC *and* BIC both select the
  **maximally overfit** bias model from 8 candidates; blocked CV recovers the truth.
- `decomposeScaleMatrix` — polar decomposition S = R·U into misalignment (µrad) and
  scale + non-orthogonality.
- `diffPenaltyMatrix`, `gcvSelectLambda`, `pspline` bias type — continuous smoothness
  control instead of guessing a knot count.
- `lombScarglePSD` — spectra on the true uneven epochs; no gap interpolation.
- `syntheticAccelPair` — ground-truth generator injecting *all* defects at once.
- `test_integration_endToEnd` — scores the whole pipeline against injected truth.
- HTML doc-browser pages (`doc/`, `info.xml`), LaTeX PDF reference, Python cross-validation
  (`refval/`).

### Changed
- **B-spline knots now default to quantile placement.** Uniform-in-time knots land inside
  data gaps. Measured: `cond(B'B)` drops from 6.19e3 to 6.69e2.
- **Interpolation now defaults to `pchip`, not `linear`.** Linear interpolation chords
  across each interval, attenuating amplitude — a shrinkage the scale parameter absorbs.
- `alignAccelSeries` nearest-neighbour screen is now O(N+K), was O(N·K).
- `slidingWindowFit` demeans the regressor within each window (decorrelating bias from
  scale) and returns NaN for unobservable windows rather than inventing a number.
- `robustLinearFit` gained optional penalty support.
- **AIC/BIC demoted to reference-only** and flagged `IC_unreliable`. Selection is by
  blocked CV.

### Removed
- AIC/BIC as selection criteria (they were actively harmful — see above).

## v1.0
Initial: preflight diagnostics, diagonal/full scale, constant/polynomial/spline bias,
AIC/BIC comparison.
