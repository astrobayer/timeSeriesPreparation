import numpy as np
from crn_atbd import crn_exact

F, meta = crn_exact()
fs, Nh = meta['fs'], meta['Nh']
n = np.arange(len(F)) - Nh

def H(f):
    return np.sum(F * np.exp(-2j*np.pi*np.atleast_1d(f)[:,None]*n[None,:]/fs), axis=1)

Torb = 5400.0
frev = 1/Torb

print("="*74)
print("1. GAIN ACROSS THE ORBITAL BAND (this is the whole story)")
print("="*74)
rows = [("DC (constant bias)", 0.0),
        ("1/rev", frev),
        ("2/rev = f0 (J2)", 2*frev),
        ("3/rev", 3*frev),
        ("5/rev", 5*frev),
        ("10/rev", 10*frev),
        ("1 mHz", 1e-3),
        ("5 mHz", 5e-3),
        ("10 mHz", 1e-2),
        ("20 mHz", 2e-2),
        ("35.5 mHz (cutoff)", 5/140.7)]
for lbl, f in rows:
    g = abs(H(f))[0]
    print(f"  {lbl:22s} f = {f*1e3:8.4f} mHz    |H| = {g:.7f}   ({(g-1)*1e6:+9.1f} ppm)")

print()
print("  f0 = 0.37 mHz is EXACTLY 2/rev -- the J2 (twice-per-rev) line.")
print("  The ATBD pins |H| = 1 there. DC is 453 ppm HIGHER. The response")
print("  simply droops monotonically; the normalisation only chooses WHERE it")
print("  crosses exactly 1.")

print()
print("="*74)
print("2. DOES THE f0 NORMALISATION BIAS THE SCALE? -- only via the gain constant")
print("="*74)
# truth: ACC1B = H{b + s*a}.  Regress on a filter-applied model.
rng = np.random.default_rng(1)
N = 120000
t = np.arange(N)/fs
a = (np.sin(2*np.pi*frev*t) + 0.5*np.sin(4*np.pi*frev*t)
     + 0.25*np.sin(2*np.pi*0.004*t))       # signal in the orbital band
b_true, s_true = 0.30, 0.97

def cf(x, h):
    L=len(h); npad=min(3*L,len(x)-1)
    xp=np.concatenate([2*x[0]-x[1:npad+1][::-1],x,2*x[-1]-x[-npad-1:-1][::-1]])
    y=np.convolve(xp,h,mode="same"); return y[npad:npad+len(x)]

acc1b = cf(b_true + s_true*a, F)          # the L1 product

def fit(model_regressor, obs):
    X = np.column_stack([np.ones(len(obs)), model_regressor - model_regressor.mean()])
    c = np.linalg.lstsq(X, obs, rcond=None)[0]
    return c[1], c[0] - c[1]*model_regressor.mean()   # scale, bias

# (a) model filtered with the CORRECT (f0-normalised) kernel
s_a, b_a = fit(cf(a, F), acc1b)
# (b) model filtered with the SAME kernel but wrongly renormalised to unit DC gain
F_dc = F / F.sum()
s_b, b_b = fit(cf(a, F_dc), acc1b)
# (c) model not filtered at all
s_c, b_c = fit(a, acc1b)

print(f"  truth                                  s = {s_true:.6f}   b = {b_true:.6f}")
print(f"  (a) model filtered, CORRECT norm       s = {s_a:.6f}   b = {b_a:.6f}"
      f"   -> scale err {(s_a/s_true-1)*1e6:+7.1f} ppm")
print(f"  (b) model filtered, sum(h)=1 norm      s = {s_b:.6f}   b = {b_b:.6f}"
      f"   -> scale err {(s_b/s_true-1)*1e6:+7.1f} ppm")
print(f"  (c) model NOT filtered                 s = {s_c:.6f}   b = {b_c:.6f}"
      f"   -> scale err {(s_c/s_true-1)*1e6:+7.1f} ppm")
print()
print("  => Filtering with the CORRECT kernel recovers the scale EXACTLY.")
print("     The f0 normalisation does NOT corrupt the scale, PROVIDED you use")
print("     the same normalisation the L1 processor used. Get the normalisation")
print("     wrong (sum(h)=1) and the scale is off by ~453 ppm -- because the")
print("     fitted scale is inversely proportional to the regressor's gain.")
print()
print(f"  Note the BIAS: fitted {b_a:.6f} vs true {b_true:.6f}"
      f"  -> {(b_a/b_true-1)*1e6:+.1f} ppm  (= the DC gain)")
print("  The observed bias is the TRUE bias times |H(0)| = 1.0004533. Harmless if")
print("  the bias is a nuisance parameter; matters only if you compare it to an")
print("  independently known physical bias.")

print()
print("="*74)
print("3. THE REAL ENTANGLEMENT: the BIAS BASIS must be filtered too")
print("="*74)
print("  ACC1B = H{ b(t) + s*a(t) } = H{B*beta} + s*H{a}   =>  regress on [H*B , H*a]")
print("  Filtering only the MODEL (what the toolbox did) leaves the bias basis")
print("  unfiltered, while the bias actually present in the data has been filtered.")
print()

# B-spline basis at various knot spacings; how much survives the filter?
import sys
sys.path.insert(0, '.')
from ref_core import bspline_basis

arc = 12*3600.0                       # a 12 h arc
tt = np.arange(0, arc, 1/fs)
print(f"  {'knot spacing':>14s} {'~period':>10s} {'||H B_j|| / ||B_j||':>22s}   identifiable?")
for spacing in [30, 60, 141, 300, 600, 1350, 2700, 5400, 10800]:
    nk = max(0, int(arc/spacing) - 1)
    if nk > 400:      # keep it tractable
        continue
    B, _ = bspline_basis(tt, nk, 4)
    # filter each column, measure surviving energy (interior only, avoid edges)
    lo, hi = 2*Nh, len(tt)-2*Nh
    keep = []
    for j in range(1, B.shape[1]-1):     # skip the two edge basis functions
        col = B[:, j]
        colf = cf(col - col.mean(), F)
        num = np.linalg.norm(colf[lo:hi]); den = np.linalg.norm((col-col.mean())[lo:hi])
        if den > 0:
            keep.append(num/den)
    if not keep:
        continue
    r = np.median(keep)
    flag = "YES" if r > 0.5 else ("marginal" if r > 0.1 else "NO -- annihilated")
    print(f"  {spacing:11d} s {2*spacing:9.0f} s {r:22.4f}   {flag}")

print()
print("  The kernel is 140.7 s long and cuts at 35.5 mHz. Bias structure faster")
print("  than roughly the kernel span CANNOT be present in ACC1B: those basis")
print("  columns are annihilated. Fitting them is fitting the null space.")
print("="*74)
