"""Reference validation for the v2.4 multi-day cause-attribution additions:
   loadSpaceWeatherIndices (GFZ parse + per-rev mapping) and
   scaleFactorDiagnostics (index regression -> density/geometry/sensor).

Mirrors the MATLAB numerics so the two implementations can be compared. Run:
    python3 diagnostics_validation.py
"""
import numpy as np
import datetime as dt

np.set_printoptions(precision=6, suppress=True)
print("=" * 70)


# ------------------------------------------------------------------ helpers
def ymd2mjd(y, m, d):
    return (dt.date(y, m, d) - dt.date(1858, 11, 17)).days


def zc(x, std=True):
    x = np.asarray(x, float)
    mu = np.nanmean(x)
    sd = np.nanstd(x) if std else 1.0
    sd = sd if sd > 0 else 1.0
    return (x - mu) / sd


def centred_running_mean(x, win):
    x = np.asarray(x, float).copy()
    x[x == -1] = np.nan
    n = len(x)
    y = np.full(n, np.nan)
    h = win // 2
    for i in range(n):
        seg = x[max(0, i - h):min(n, i + h + 1)]
        seg = seg[np.isfinite(seg)]
        if seg.size:
            y[i] = seg.mean()
    return y


def sample_by_day(day_start, v, ti):
    ti = np.atleast_1d(ti).astype(float)
    out = np.full(ti.shape, np.nan)
    for k, tt in enumerate(ti):
        idx = np.where(day_start == np.floor(tt))[0]
        if idx.size:
            out[k] = v[idx[0]]
    return out


# ------------------------------------------------------------------ 1. GFZ parse + mapping
# Build a 5-day synthetic GFZ daily file in memory (28 fields/line).
start_mjd = 58849  # 2020-01-01
days = []
for d in range(5):
    date = dt.date(2020, 1, 1) + dt.timedelta(days=d)
    kp8 = 1.0 + 0.25 * np.arange(8)
    f107 = 70 + 5 * d
    days.append((date, kp8, f107))

day_start = np.array([ymd2mjd(dd.year, dd.month, dd.day) for dd, _, _ in days], float)
f107_daily = np.array([f for _, _, f in days])
kp8_daily = np.array([k for _, k, _ in days])

# 3-hourly Kp timeline at interval mid-times (01:30 .. 22:30)
hmid = (np.arange(8) * 3 + 1.5) / 24
kpT = (hmid[:, None] + day_start[None, :]).reshape(-1, order="F")
kpV = kp8_daily.T.reshape(-1, order="F")

# a) daily F10.7 held across the whole UT day (day-membership, not noon-nearest)
tmid = (23 / 24) * 86400            # 23:00 on day 0
mjd_rev = start_mjd + tmid / 86400
f = sample_by_day(day_start, f107_daily, mjd_rev)
print("1a F10.7 at 23:00 day0 = %.1f  (expect 70, held across day)" % f[0])

# b) 15 revs within day 0 all read 70
tmid = (np.arange(1, 16) - 0.5) * 5400
f = sample_by_day(day_start, f107_daily, start_mjd + tmid / 86400)
print("1b 15 revs within day0 all==70:", np.allclose(f, 70))

# c) Kp interpolation reaches the last interval value 2.75 at 22:30
k = np.interp(start_mjd + 22.5 / 24, kpT, kpV)
print("1c Kp at 22:30 day0 = %.3f  (expect 2.75)" % k)

# d) 81-day centred F107a on a central day = mean of the 5 present days
F107a = centred_running_mean(f107_daily, 81)
print("1d F107a[day2] = %.1f  (expect %.1f)" % (F107a[2], f107_daily.mean()))


# ------------------------------------------------------------------ 2. cause attribution
def block_len(y):
    y = y - y.mean()
    n = len(y)
    if n < 4:
        return 1
    r1 = min(abs((y[:-1] @ y[1:]) / max(y @ y, 1e-300)), 0.999)
    return 1 if r1 < 1e-3 else max(1, min(int(np.ceil(-5 / np.log(r1))), n // 2))


def attribute(coef, sig, family, names, R2, min_r2=0.10):
    if R2 < min_r2:
        return "unresolved"
    ac = np.abs(coef).copy()
    ac[~sig] = 0
    if not ac.any():
        return "unresolved"
    o = np.argsort(-ac)
    cause = family[o[0]]
    if len(o) >= 2 and ac[o[1]] > 0 and family[o[1]] != family[o[0]] and ac[o[1]] / ac[o[0]] > 0.8:
        cause = "mixed"
    return "unresolved" if cause == "other" else cause


rng = np.random.default_rng(7)
nrev = 350
kk = np.arange(nrev)
tmid = kk * 5400.0
F107 = 120 + 45 * np.sin(2 * np.pi * kk / 180) + 5 * rng.standard_normal(nrev)
Kp = 2 + 1.2 * np.abs(np.sin(2 * np.pi * kk / 40)) + 0.3 * rng.standard_normal(nrev)
beta = 35 * np.sin(2 * np.pi * kk / 260)
argl = (kk * 23) % 360
names = ["F107", "Kp", "beta", "argLat_sin", "argLat_cos", "secular"]
family = ["density", "density", "geometry", "geometry", "geometry", "sensor"]
P = np.column_stack([zc(F107), zc(Kp), zc(beta),
                     np.sin(np.deg2rad(argl)), np.cos(np.deg2rad(argl)), zc(tmid)])

scenarios = {
    "DENSITY (F10.7)": 0.90 + 0.0010 * (F107 - 120) + 0.003 * rng.standard_normal(nrev),
    "GEOMETRY (beta)": 1.00 + 0.0020 * beta + 0.003 * rng.standard_normal(nrev),
    "SENSOR (secular)": 1.00 + 25e-6 * tmid / 5400 + 0.002 * rng.standard_normal(nrev),
    "FLAT (noise)": 1.03 + 0.003 * rng.standard_normal(nrev),
}
print("\n2 cause attribution (block-bootstrap CIs, MinR2=0.10):")
for label, y in scenarios.items():
    X = np.column_stack([np.ones(nrev), P])
    cf = np.linalg.lstsq(X, y, rcond=None)[0]
    R2 = 1 - np.sum((y - X @ cf) ** 2) / np.sum((y - y.mean()) ** 2)
    blk = block_len(y)
    # moving-block bootstrap
    boot = []
    n = nrev
    mx = max(1, n - blk + 1)
    nb = int(np.ceil(n / blk))
    for _ in range(2000):
        idx = np.clip(np.concatenate([np.arange(s, s + blk)
                                      for s in rng.integers(0, mx, nb)])[:n], 0, n - 1)
        boot.append(np.linalg.lstsq(X[idx], y[idx], rcond=None)[0])
    boot = np.array(boot)[:, 1:]
    lo, hi = np.quantile(boot, 0.025, 0), np.quantile(boot, 0.975, 0)
    sig = (lo * hi) > 0
    cause = attribute(cf[1:], sig, family, names, R2)
    print("   %-18s -> %-11s R2=%.2f" % (label, cause, R2))

print("\nExpected: DENSITY->density, GEOMETRY->geometry, SENSOR->sensor, FLAT->unresolved")
print("=" * 70)
