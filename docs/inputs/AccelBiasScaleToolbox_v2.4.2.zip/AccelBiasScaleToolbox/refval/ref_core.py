"""Independent Python reference implementations of the AccelBiasScaleToolbox
core numerics. Used to (a) verify the algorithms are correct before writing
MATLAB, and (b) emit reference values to embed in the MATLAB unit tests.
"""
import numpy as np
from scipy.linalg import solve_toeplitz, polar as sp_polar

# ----------------------------------------------------------------------
# 1. B-spline basis (Cox-de Boor), with uniform or quantile knot placement
# ----------------------------------------------------------------------
def knot_vector(t, n_interior, order, placement="uniform"):
    tmin, tmax = float(np.min(t)), float(np.max(t))
    if tmax == tmin:
        tmax = tmin + 1.0
    if n_interior <= 0:
        interior = np.array([])
    elif placement == "uniform":
        interior = np.linspace(tmin, tmax, n_interior + 2)[1:-1]
    elif placement == "quantile":
        # knots at quantiles of the OBSERVED epochs -> no knots inside gaps
        q = np.linspace(0, 1, n_interior + 2)[1:-1]
        interior = np.quantile(np.asarray(t, float), q)
        # guard against duplicate knots (heavy ties)
        interior = np.unique(interior)
    else:
        raise ValueError(placement)
    return np.concatenate([np.full(order, tmin), interior, np.full(order, tmax)]), len(interior)


def cox_de_boor(t, knots, j, order):
    """N_{j,order}(t), j is 0-indexed."""
    if order == 1:
        return ((t >= knots[j]) & (t < knots[j + 1])).astype(float)
    out = np.zeros_like(t, dtype=float)
    d1 = knots[j + order - 1] - knots[j]
    d2 = knots[j + order] - knots[j + 1]
    if d1 > 0:
        out += (t - knots[j]) / d1 * cox_de_boor(t, knots, j, order - 1)
    if d2 > 0:
        out += (knots[j + order] - t) / d2 * cox_de_boor(t, knots, j + 1, order - 1)
    return out


def bspline_basis(t, n_interior, order=4, placement="uniform"):
    t = np.asarray(t, float)
    knots, n_int_actual = knot_vector(t, n_interior, order, placement)
    n_basis = len(knots) - order
    B = np.zeros((len(t), n_basis))
    for j in range(n_basis):
        B[:, j] = cox_de_boor(t, knots, j, order)
    # clamp right endpoint (half-open interval convention zeroes it)
    tmax = knots[-1]
    at_end = np.isclose(t, tmax)
    if at_end.any():
        B[at_end, :] = 0.0
        B[at_end, -1] = 1.0
    return B, knots


# ----------------------------------------------------------------------
# 2. Second-difference penalty + GCV lambda selection (P-spline)
# ----------------------------------------------------------------------
def diff_penalty(n_basis, d=2):
    D = np.diff(np.eye(n_basis), n=d, axis=0)
    return D.T @ D


def pspline_gcv(B, y, P, lambdas):
    """Return (lambda_opt, gcv_curve, coef_opt, edf_opt)."""
    n = len(y)
    BtB = B.T @ B
    Bty = B.T @ y
    gcv = np.empty(len(lambdas))
    best = None
    for i, lam in enumerate(lambdas):
        A = BtB + lam * P
        coef = np.linalg.solve(A, Bty)
        # effective degrees of freedom = trace(hat)
        H = np.linalg.solve(A, BtB)
        edf = np.trace(H)
        resid = y - B @ coef
        rss = float(resid @ resid)
        gcv[i] = n * rss / (n - edf) ** 2
        if best is None or gcv[i] < gcv[best[0]]:
            best = (i, coef, edf)
    return lambdas[best[0]], gcv, best[1], best[2]


# ----------------------------------------------------------------------
# 3. AR(p) noise model via Yule-Walker + effective sample size
# ----------------------------------------------------------------------
def acf(x, nlags):
    x = np.asarray(x, float) - np.mean(x)
    n = len(x)
    full = np.correlate(x, x, mode="full")[n - 1:]
    full /= full[0]
    return full[: nlags + 1]


def yule_walker(x, p):
    r = acf(x, p)
    R = r[:p]              # Toeplitz first column r0..r_{p-1}
    rhs = r[1: p + 1]
    phi = solve_toeplitz((R, R), rhs)
    # innovation variance
    sig2 = np.var(x, ddof=0) * (1.0 - float(phi @ rhs))
    return phi, sig2


def ar_select_order(x, pmax=10):
    """AIC over AR orders 0..pmax."""
    n = len(x)
    best_p, best_aic = 0, np.inf
    aics = []
    for p in range(0, pmax + 1):
        if p == 0:
            sig2 = np.var(x, ddof=0)
        else:
            _, sig2 = yule_walker(x, p)
        sig2 = max(sig2, 1e-300)
        aic = n * np.log(sig2) + 2 * p
        aics.append(aic)
        if aic < best_aic:
            best_aic, best_p = aic, p
    return best_p, np.array(aics)


def prewhiten_ar(x, phi):
    """Apply AR whitening filter: e_t = x_t - sum phi_k x_{t-k}. Drops first p."""
    p = len(phi)
    if p == 0:
        return np.asarray(x, float).copy()
    x = np.asarray(x, float)
    n = len(x)
    e = np.empty(n - p)
    for t in range(p, n):
        lags = np.array([x[t - k] for k in range(1, p + 1)])
        e[t - p] = x[t] - float(phi @ lags)
    return e


def effective_sample_size(x, nlags=None):
    """n_eff = n / (1 + 2*sum_k rho_k), truncated at first non-positive rho."""
    n = len(x)
    if nlags is None:
        nlags = min(n // 4, 200)
    r = acf(x, nlags)[1:]
    s = 0.0
    for rk in r:
        if rk <= 0:
            break
        s += rk
    return n / (1.0 + 2.0 * s)


# ----------------------------------------------------------------------
# 4. Polar decomposition of the scale matrix S = R * U
# ----------------------------------------------------------------------
def polar_decompose(S):
    R, U = sp_polar(np.asarray(S, float), side="right")   # S = R @ U
    return R, U


def rotation_to_small_angles(R):
    """Extract small misalignment angles (rad) from a near-identity rotation.
    Uses the skew part: R ~ I + [w]_x  =>  w = vee(skew(R))."""
    W = 0.5 * (R - R.T)
    return np.array([W[2, 1], W[0, 2], W[1, 0]])


# ----------------------------------------------------------------------
# 5. Moving-block bootstrap for regression coefficients
# ----------------------------------------------------------------------
def block_bootstrap_coef(X, y, block_len, n_boot, seed=0):
    rng = np.random.default_rng(seed)
    n = len(y)
    coef0 = np.linalg.lstsq(X, y, rcond=None)[0]
    resid = y - X @ coef0
    fitted = X @ coef0
    n_blocks = int(np.ceil(n / block_len))
    boots = np.empty((n_boot, X.shape[1]))
    max_start = n - block_len
    for b in range(n_boot):
        idx = []
        for _ in range(n_blocks):
            s = rng.integers(0, max_start + 1)
            idx.extend(range(s, s + block_len))
        idx = np.array(idx[:n])
        yb = fitted + resid[idx]
        boots[b] = np.linalg.lstsq(X, yb, rcond=None)[0]
    return coef0, boots


# ----------------------------------------------------------------------
# 6. Blocked (contiguous-fold) cross-validation
# ----------------------------------------------------------------------
def blocked_cv_rss(X, y, k_folds):
    n = len(y)
    edges = np.linspace(0, n, k_folds + 1).astype(int)
    total = 0.0
    for i in range(k_folds):
        te = np.zeros(n, bool)
        te[edges[i]:edges[i + 1]] = True
        tr = ~te
        if tr.sum() < X.shape[1] + 1:
            continue
        coef = np.linalg.lstsq(X[tr], y[tr], rcond=None)[0]
        r = y[te] - X[te] @ coef
        total += float(r @ r)
    return total
