"""Exact CRN-class digital filter per the GRACE L1B ATBD (JPL D-27672),
Appendix B -- and a quantitative comparison against the approximate filter
the toolbox previously guessed at.

ACC parameters (ATBD Appendix B / section 3):
    fs = 10 Hz          raw ACC_1A linear-acceleration rate
    Nc = 7              self-convolution number (odd)
    Tf = 140.7 s        fit interval (ACC; KBR uses 70.7 s)
    B  ~ 0.035 Hz       target low-pass bandwidth (ACC; KBR uses ~0.1 Hz)
    f0 = 0.37e-3 Hz     dominant (J2) signal frequency
    Nf = fs*Tf = 1407   raw points in the fit interval (odd)
    Nh = (Nf-1)/2 = 703
    NB = B*Tf           frequency bins in the passband -> integer
"""
import numpy as np


def crn_exact(fs=10.0, Nc=7, Tf=140.7, NB=None, B=0.035, f0=0.37e-3,
              return_derivs=False):
    Nf = int(round(fs * Tf))
    if Nf % 2 == 0:
        Nf += 1
    Nh = (Nf - 1) // 2
    if NB is None:
        NB = int(round(B * Tf))

    k = np.arange(-Nh, Nh + 1)                      # frequency bin index
    m = np.arange(-NB, NB + 1)                      # passband bins

    # H_k = [ sum_m  sin(pi*(k-m)/Nc) / sin(pi*(k-m)/Nf) ]^Nc
    # The ratio is the DFT of a rectangular time window of length Nf/Nc;
    # raising to Nc is the Nc-fold self-convolution (-> total length Nf).
    d = k[:, None] - m[None, :]                     # (2Nh+1, 2NB+1)
    num = np.sin(np.pi * d / Nc)
    den = np.sin(np.pi * d / Nf)
    ratio = np.empty_like(num)
    zero = (d == 0)
    with np.errstate(invalid="ignore", divide="ignore"):
        ratio = np.where(zero, Nf / Nc, num / den)  # removable singularity
    H = ratio.sum(axis=1) ** Nc                     # (2Nh+1,)

    n = np.arange(-Nh, Nh + 1)
    C = np.cos(2 * np.pi * np.outer(k, n) / Nf)     # (2Nh+1, 2Nh+1)

    F_un = H @ C                                    # unnormalised weights, index n

    # Normalisation: unit gain at the DOMINANT SIGNAL FREQUENCY f0 -- not at DC.
    F_norm = np.sum(np.cos(2 * np.pi * f0 * n / fs) * F_un)
    F = F_un / F_norm

    if not return_derivs:
        return F, dict(Nf=Nf, Nh=Nh, NB=NB, Nc=Nc, Tf=Tf, fs=fs, f0=f0,
                       B_actual=NB / Tf)

    S = np.sin(2 * np.pi * np.outer(k, n) / Nf)
    w = 2 * np.pi * k / Tf
    Fd = (-(w) * H) @ S / F_norm
    Fdd = (-(w ** 2) * H) @ C / F_norm
    return F, Fd, Fdd, dict(Nf=Nf, Nh=Nh, NB=NB, Nc=Nc, Tf=Tf, fs=fs, f0=f0,
                            B_actual=NB / Tf)


def response(h, f, fs):
    n = np.arange(len(h)) - (len(h) - 1) / 2
    return np.array([np.abs(np.sum(h * np.exp(-2j * np.pi * fi * n / fs))) for f_ in [0] for fi in np.atleast_1d(f)])


# --- my previous APPROXIMATION (what the toolbox guessed) ---
def crn_approx(fs, fc, nconv=7, sigma=0.3, L=None):
    if L is None:
        L = 2 * int(np.ceil(fs / fc)) + 1
    L = 2 * (L // 2) + 1
    w = max(3, int(round(fs / (fc * nconv))))
    h = np.ones(1)
    for _ in range(nconv):
        h = np.convolve(h, np.ones(w))
    if len(h) > L:
        c = (len(h) + 1) // 2
        lo = max(0, c - L // 2)
        h = h[lo:lo + L]
    if len(h) < L:
        pad = L - len(h)
        h = np.concatenate([np.zeros(pad // 2), h, np.zeros(pad - pad // 2)])
    m = (len(h) - 1) / 2
    idx = np.arange(len(h)) - m
    h = h * np.exp(-0.5 * (idx / (sigma * m)) ** 2)
    return h / h.sum()


if __name__ == "__main__":
    print("=" * 72)
    F, meta = crn_exact()
    print("EXACT CRN (ACC):", meta)
    print(f"  kernel length   : {len(F)} samples = {len(F)/meta['fs']:.1f} s")
    print(f"  actual bandwidth: NB/Tf = {meta['B_actual']:.5f} Hz  (target 0.035)")
    print(f"  sum(F)  [DC gain]         = {F.sum():.10f}")
    g_f0 = np.abs(np.sum(F * np.exp(-2j*np.pi*meta['f0']*(np.arange(len(F))-meta['Nh'])/meta['fs'])))
    print(f"  |H(f0)| [gain at 0.37 mHz] = {g_f0:.10f}   <-- normalised HERE, not at DC")
    print(f"  symmetric? max|F - flip(F)| = {np.abs(F - F[::-1]).max():.3e}")

    # frequency response
    fs = meta['fs']; Nh = meta['Nh']
    n = np.arange(len(F)) - Nh
    for ftest in [0.0, 0.001, 0.01, 0.02, 0.0355, 0.05, 0.1, 0.2, 0.5]:
        g = np.abs(np.sum(F * np.exp(-2j*np.pi*ftest*n/fs)))
        print(f"    |H({ftest:6.4f} Hz)| = {g:.6f}")

    print("\n" + "=" * 72)
    print("COMPARISON: exact ATBD filter vs the approximation the toolbox used")
    A = crn_approx(10.0, 0.035, 7)
    print(f"  exact  : length {len(F):5d} ({len(F)/10:.1f} s)")
    print(f"  approx : length {len(A):5d} ({len(A)/10:.1f} s)")

    for ftest in [0.01, 0.02, 0.035, 0.05, 0.1, 0.2]:
        ne = np.arange(len(F)) - (len(F)-1)/2
        na = np.arange(len(A)) - (len(A)-1)/2
        ge = np.abs(np.sum(F * np.exp(-2j*np.pi*ftest*ne/10)))
        ga = np.abs(np.sum(A * np.exp(-2j*np.pi*ftest*na/10)))
        print(f"    f={ftest:6.3f} Hz   exact {ge:8.5f}   approx {ga:8.5f}   ratio {ga/max(ge,1e-12):7.3f}")

    # --- the money question: how much scale bias does using the WRONG filter leave? ---
    print("\n" + "=" * 72)
    print("INDUCED SCALE BIAS (true scale = 1.0), 3 h of 10 Hz data")
    rng = np.random.default_rng(0)
    N = 108000
    t = np.arange(N) / 10.0
    # a model with realistic once/twice-per-rev structure PLUS broadband content
    ymod = (np.sin(2*np.pi*t/5400) + 0.4*np.sin(4*np.pi*t/5400)
            + 0.3*np.sin(2*np.pi*0.05*t) + 0.2*rng.standard_normal(N))

    def zp(x, h):
        L = len(h); npad = min(3*L, len(x)-1)
        xp = np.concatenate([2*x[0]-x[1:npad+1][::-1], x, 2*x[-1]-x[-npad-1:-1][::-1]])
        y = np.convolve(xp, h, mode="same")
        y = np.convolve(y[::-1], h, mode="same")[::-1]
        return y[npad:npad+len(x)]

    yobs = zp(1.0 * ymod, F)          # ACC1B: filtered with the TRUE filter

    def fit_scale(mod, obs):
        X = np.column_stack([np.ones(len(mod)), mod - mod.mean()])
        return np.linalg.lstsq(X, obs, rcond=None)[0][1]

    s_none   = fit_scale(ymod, yobs)                 # no correction at all
    s_approx = fit_scale(zp(ymod, A), yobs)          # corrected with my APPROXIMATE filter
    s_exact  = fit_scale(zp(ymod, F), yobs)          # corrected with the EXACT filter

    print(f"  no filter correction        : scale = {s_none:.5f}   error {100*(s_none-1):+6.2f} %")
    print(f"  corrected w/ APPROX filter  : scale = {s_approx:.5f}   error {100*(s_approx-1):+6.2f} %")
    print(f"  corrected w/ EXACT filter   : scale = {s_exact:.5f}   error {100*(s_exact-1):+6.2f} %")
    print("=" * 72)

    np.save("crn_acc_exact.npy", F)
    print("\nexact ACC CRN kernel saved -> crn_acc_exact.npy")
