import numpy as np
from ref_core import *

np.set_printoptions(precision=10, suppress=False)
print("=" * 70)

# --- 1. B-spline partition of unity, uniform and quantile ---
t = np.linspace(0, 10, 200)
B, kn = bspline_basis(t, 5, 4, "uniform")
print("1a uniform  B shape", B.shape, "max|rowsum-1| =", np.abs(B.sum(1) - 1).max())

# gappy epochs -> quantile knots must avoid the hole
tg = np.concatenate([np.linspace(0, 3, 100), np.linspace(8, 10, 100)])
Bu, knu = bspline_basis(tg, 5, 4, "uniform")
Bq, knq = bspline_basis(tg, 5, 4, "quantile")
print("1b gappy uniform knots :", np.round(knu[4:-4], 4))
print("1b gappy quantile knots:", np.round(knq[4:-4], 4))
print("   uniform  cond(B'B) =", np.linalg.cond(Bu.T @ Bu))
print("   quantile cond(B'B) =", np.linalg.cond(Bq.T @ Bq))
print("   quantile rowsum err =", np.abs(Bq.sum(1) - 1).max())

# --- 2. P-spline GCV recovers a smooth truth without knot tuning ---
rng = np.random.default_rng(42)
tt = np.linspace(0, 100, 400)
truth = 0.5 * np.sin(2 * np.pi * tt / 80) + 0.01 * tt
y = truth + rng.normal(0, 0.05, tt.size)
Bp, _ = bspline_basis(tt, 30, 4, "uniform")     # deliberately over-rich basis
P = diff_penalty(Bp.shape[1], 2)
lams = np.logspace(-6, 6, 61)
lam_opt, gcv, coef, edf = pspline_gcv(Bp, y, P, lams)
fit = Bp @ coef
print("\n2 P-spline GCV: lambda_opt = %.4g, edf = %.3f, RMSE vs truth = %.5f"
      % (lam_opt, edf, np.sqrt(np.mean((fit - truth) ** 2))))
# compare to unpenalized over-rich basis (should overfit noise)
coef_un = np.linalg.lstsq(Bp, y, rcond=None)[0]
print("  unpenalized 34-param RMSE vs truth = %.5f  (P-spline should be lower)"
      % np.sqrt(np.mean((Bp @ coef_un - truth) ** 2)))

# --- 3. AR noise model + effective sample size ---
n = 4000
phi_true = np.array([0.75, -0.2])
e = rng.normal(0, 1, n + 100)
x = np.zeros(n + 100)
for k in range(2, n + 100):
    x[k] = phi_true[0] * x[k - 1] + phi_true[1] * x[k - 2] + e[k]
x = x[100:]
p_sel, aics = ar_select_order(x, 8)
phi_hat, sig2 = yule_walker(x, 2)
w = prewhiten_ar(x, phi_hat)
print("\n3 AR: selected order =", p_sel, " phi_hat =", np.round(phi_hat, 4),
      " (true", phi_true, ")")
print("  resid acf(1) before whitening = %.4f, after = %.4f"
      % (acf(x, 1)[1], acf(w, 1)[1]))
print("  n = %d, n_eff = %.1f  (ratio %.3f)" % (n, effective_sample_size(x), effective_sample_size(x) / n))

# --- 4. Polar decomposition ---
ang = np.array([0.002, -0.001, 0.0015])          # rad misalignment
Wx = np.array([[0, -ang[2], ang[1]],
               [ang[2], 0, -ang[0]],
               [-ang[1], ang[0], 0]])
Rtrue = np.linalg.qr(np.eye(3) + Wx)[0]
Rtrue = Rtrue @ np.diag(np.sign(np.diag(Rtrue)))
Utrue = np.array([[0.96, 0.01, 0.0],
                  [0.01, 1.03, 0.005],
                  [0.0, 0.005, 1.10]])
S = Rtrue @ Utrue
R, U = polar_decompose(S)
print("\n4 polar: ||R-Rtrue|| = %.3e, ||U-Utrue|| = %.3e"
      % (np.linalg.norm(R - Rtrue), np.linalg.norm(U - Utrue)))
print("  recovered small angles (urad):", np.round(rotation_to_small_angles(R) * 1e6, 2))
print("  U diag (scales):", np.round(np.diag(U), 5),
      " U offdiag (non-orthog):", np.round([U[0,1], U[0,2], U[1,2]], 5))
print("  det(R) =", np.linalg.det(R), " U symmetric err =", np.abs(U - U.T).max())

# --- 5. Block bootstrap widens CI under autocorrelation (the whole point) ---
n = 1000
tt = np.linspace(0, 100, n)
Xr = np.column_stack([np.ones(n), np.sin(0.3 * tt)])
beta = np.array([0.5, 2.0])
# colored (AR(1), rho=0.95) noise
rho = 0.95
ee = rng.normal(0, 0.1, n)
nz = np.zeros(n)
for k in range(1, n):
    nz[k] = rho * nz[k - 1] + ee[k]
yy = Xr @ beta + nz
coef0, boots = block_bootstrap_coef(Xr, yy, block_len=100, n_boot=400, seed=1)
sd_block = boots.std(0)
# naive iid OLS sigma
resid = yy - Xr @ coef0
s2 = resid @ resid / (n - 2)
sd_naive = np.sqrt(np.diag(s2 * np.linalg.inv(Xr.T @ Xr)))
print("\n5 bootstrap: coef =", np.round(coef0, 4))
print("  naive iid  sigma =", np.round(sd_naive, 5))
print("  block boot sigma =", np.round(sd_block, 5))
print("  inflation factor =", np.round(sd_block / sd_naive, 2), " (>1 expected)")

# --- 6. Blocked CV penalizes overfit model; random-fold CV would not ---
Bsm, _ = bspline_basis(tt, 2, 4)
Bri, _ = bspline_basis(tt, 40, 4)
Xsm = np.column_stack([Bsm, np.sin(0.3 * tt)])
Xri = np.column_stack([Bri, np.sin(0.3 * tt)])
print("\n6 blocked CV RSS: smooth-bias model = %.4f, over-rich model = %.4f"
      % (blocked_cv_rss(Xsm, yy, 5), blocked_cv_rss(Xri, yy, 5)))
print("=" * 70)
