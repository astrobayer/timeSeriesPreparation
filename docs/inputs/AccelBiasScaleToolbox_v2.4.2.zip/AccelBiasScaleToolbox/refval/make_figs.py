"""Produce the figures for the LaTeX reference, from the SAME reference
implementations used to validate the MATLAB. Every number quoted in the
documentation therefore traces to a computation, not an assertion."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from ref_core import *

plt.rcParams.update({
    "font.size": 8, "axes.grid": True, "grid.alpha": 0.3,
    "figure.dpi": 150, "savefig.bbox": "tight", "axes.titlesize": 8,
})
OUT = "figs"
import os
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(42)

# =====================================================================
# FIG 1 -- Scale observability: the collinearity valley
# =====================================================================
fig, axs = plt.subplots(1, 3, figsize=(9, 2.6))

t = np.linspace(0, 100, 400)
# (a) quiet arc: y_mod nearly constant
y_quiet = 1 + 0.01 * np.sin(2 * np.pi * t / 50)
# (b) lively arc
y_lively = 1 + 0.8 * np.sin(2 * np.pi * t / 50)

axs[0].plot(t, y_quiet, label="quiet (low dyn. range)")
axs[0].plot(t, y_lively, label="lively")
axs[0].set_title("(a) modelled signal")
axs[0].set_xlabel("time"); axs[0].set_ylabel(r"$y_{\rm mod}$")
axs[0].legend(fontsize=6)

# RSS surface over (bias, scale) for the quiet arc -> a flat valley
bias0, scale0 = 0.2, 1.0
y_obs = bias0 + scale0 * y_quiet + rng.normal(0, 0.002, t.size)
bg = np.linspace(-0.6, 1.0, 160)
sg = np.linspace(0.2, 1.8, 160)
BB, SS = np.meshgrid(bg, sg)
RSS = np.zeros_like(BB)
for i in range(BB.shape[0]):
    for j in range(BB.shape[1]):
        r = y_obs - (BB[i, j] + SS[i, j] * y_quiet)
        RSS[i, j] = r @ r
im = axs[1].contourf(BB, SS, np.log10(RSS), levels=30, cmap="viridis")
axs[1].plot(bias0, scale0, "r*", ms=10)
axs[1].set_title("(b) quiet arc: $\\log_{10}$RSS\nflat valley $\\Rightarrow$ unidentifiable")
axs[1].set_xlabel("bias"); axs[1].set_ylabel("scale")

y_obs2 = bias0 + scale0 * y_lively + rng.normal(0, 0.002, t.size)
RSS2 = np.zeros_like(BB)
for i in range(BB.shape[0]):
    for j in range(BB.shape[1]):
        r = y_obs2 - (BB[i, j] + SS[i, j] * y_lively)
        RSS2[i, j] = r @ r
axs[2].contourf(BB, SS, np.log10(RSS2), levels=30, cmap="viridis")
axs[2].plot(bias0, scale0, "r*", ms=10)
axs[2].set_title("(c) lively arc: sharp minimum\n$\\Rightarrow$ identifiable")
axs[2].set_xlabel("bias"); axs[2].set_ylabel("scale")
plt.savefig(f"{OUT}/fig_observability.pdf")
plt.close()

# quantify
def bias_scale_corr(ym, demean):
    s = ym - ym.mean() if demean else ym
    X = np.column_stack([np.ones_like(s), s])
    Ci = np.linalg.inv(X.T @ X)
    return Ci[0, 1] / np.sqrt(Ci[0, 0] * Ci[1, 1]), np.linalg.cond(X)

c_q, k_q = bias_scale_corr(y_quiet, False)
c_qd, k_qd = bias_scale_corr(y_quiet, True)
c_l, k_l = bias_scale_corr(y_lively, False)
print(f"F1 quiet  : corr(bias,scale) = {c_q:+.4f}, cond = {k_q:.1f}")
print(f"F1 quiet+demean: corr = {c_qd:+.2e}, cond = {k_qd:.1f}")
print(f"F1 lively : corr = {c_l:+.4f}, cond = {k_l:.1f}")

# =====================================================================
# FIG 2 -- Knot placement with gaps
# =====================================================================
fig, axs = plt.subplots(1, 2, figsize=(8, 2.4))
tg = np.concatenate([np.linspace(0, 3, 100), np.linspace(8, 10, 100)])
for ax, place in zip(axs, ["uniform", "quantile"]):
    B, kn = bspline_basis(tg, 5, 4, place)
    for j in range(B.shape[1]):
        ax.plot(tg, B[:, j], lw=0.9)
    interior = kn[4:-4]
    for k in interior:
        ax.axvline(k, color="r", ls="--", lw=0.8)
    ax.axvspan(3, 8, color="grey", alpha=0.25)
    c = np.linalg.cond(B.T @ B)
    ax.set_title(f"{place} knots  —  cond$(B^TB)$ = {c:.3g}")
    ax.set_xlabel("time"); ax.set_ylabel("basis")
    ax.set_ylim(-0.05, 1.05)
axs[0].text(5.5, 0.55, "DATA GAP", ha="center", fontsize=7, color="k")
plt.savefig(f"{OUT}/fig_knots.pdf")
plt.close()
Bu, _ = bspline_basis(tg, 5, 4, "uniform")
Bq, _ = bspline_basis(tg, 5, 4, "quantile")
print(f"F2 cond uniform={np.linalg.cond(Bu.T@Bu):.4g}  quantile={np.linalg.cond(Bq.T@Bq):.4g}")

# =====================================================================
# FIG 3 -- Sigma inflation under autocorrelated residuals
# =====================================================================
rhos = [0.0, 0.5, 0.8, 0.9, 0.95, 0.98]
n = 1000
tt = np.linspace(0, 100, n)
X = np.column_stack([np.ones(n), np.sin(0.3 * tt)])
beta = np.array([0.5, 2.0])

infl, neffr = [], []
for rho in rhos:
    e = rng.normal(0, 0.1, n)
    nz = np.zeros(n)
    for k in range(1, n):
        nz[k] = rho * nz[k - 1] + e[k]
    y = X @ beta + nz
    c0, boots = block_bootstrap_coef(X, y, block_len=max(10, int(5 * (1 if rho <= 0 else -1/np.log(max(rho,1e-3))))), n_boot=300, seed=7)
    sd_b = boots.std(0)
    r = y - X @ c0
    s2 = r @ r / (n - 2)
    sd_n = np.sqrt(np.diag(s2 * np.linalg.inv(X.T @ X)))
    infl.append((sd_b / sd_n).mean())
    neffr.append(effective_sample_size(r) / n)

fig, axs = plt.subplots(1, 2, figsize=(8, 2.6))
axs[0].plot(rhos, infl, "o-")
axs[0].axhline(1, color="k", ls="--", lw=0.8)
axs[0].set_xlabel(r"AR(1) $\rho$ of residuals")
axs[0].set_ylabel(r"$\sigma_{\rm block boot} / \sigma_{\rm naive}$")
axs[0].set_title("(a) naive error bars are too small")
axs[1].plot(rhos, neffr, "s-", color="C1")
axs[1].axhline(1, color="k", ls="--", lw=0.8)
axs[1].set_xlabel(r"AR(1) $\rho$ of residuals")
axs[1].set_ylabel(r"$n_{\rm eff}/n$")
axs[1].set_title("(b) effective sample size collapses")
plt.savefig(f"{OUT}/fig_sigma_inflation.pdf")
plt.close()
for r_, i_, e_ in zip(rhos, infl, neffr):
    print(f"F3 rho={r_:.2f}  inflation={i_:.2f}x  n_eff/n={e_:.3f}")

# =====================================================================
# FIG 4 -- Model selection: in-sample vs blocked CV
# =====================================================================
n = 1000
tt = np.linspace(0, 100, n)
rho = 0.95
e = rng.normal(0, 0.1, n)
nz = np.zeros(n)
for k in range(1, n):
    nz[k] = rho * nz[k - 1] + e[k]
truth_bias = 0.5 + 0.3 * np.sin(2 * np.pi * tt / 120)
y = truth_bias + 2 * np.sin(0.3 * tt) + nz

knot_counts = [0, 2, 4, 8, 16, 32, 64, 120]
rss_in, rss_cv, aics, bics = [], [], [], []
for nk in knot_counts:
    B, _ = bspline_basis(tt, nk, 4)
    Xd = np.column_stack([B, np.sin(0.3 * tt)])
    coef = np.linalg.lstsq(Xd, y, rcond=None)[0]
    r = y - Xd @ coef
    rss = float(r @ r)
    rss_in.append(rss)
    rss_cv.append(blocked_cv_rss(Xd, y, 5))
    k = Xd.shape[1]
    aics.append(n * np.log(rss / n) + 2 * k)
    bics.append(n * np.log(rss / n) + k * np.log(n))

fig, axs = plt.subplots(1, 3, figsize=(9.5, 2.6))
axs[0].semilogy(knot_counts, rss_in, "o-")
axs[0].set_title("(a) in-sample RSS\nalways improves")
axs[0].set_xlabel("# interior knots")
axs[1].semilogy(knot_counts, rss_cv, "o-", color="C3")
best = knot_counts[int(np.argmin(rss_cv))]
axs[1].axvline(best, color="k", ls="--", lw=0.8)
axs[1].set_title(f"(b) blocked-CV RSS\nminimum at {best} knots")
axs[1].set_xlabel("# interior knots")
axs[2].plot(knot_counts, np.array(aics) - min(aics), "o-", label="AIC")
axs[2].plot(knot_counts, np.array(bics) - min(bics), "s-", label="BIC")
axs[2].set_title("(c) AIC/BIC (invalid here:\nresiduals autocorrelated)")
axs[2].set_xlabel("# interior knots")
axs[2].legend(fontsize=6)
plt.savefig(f"{OUT}/fig_model_selection.pdf")
plt.close()
print("F4 in-sample argmin knots :", knot_counts[int(np.argmin(rss_in))])
print("F4 blockedCV argmin knots :", best)
print("F4 AIC argmin knots       :", knot_counts[int(np.argmin(aics))])
print("F4 BIC argmin knots       :", knot_counts[int(np.argmin(bics))])

# =====================================================================
# FIG 5 -- Filter mismatch biases scale
# =====================================================================
def crn(fs, fc, nconv=5, sigma=0.3):
    L = 2 * int(np.ceil(fs / fc)) + 1
    w = max(3, int(round(fs / (fc * nconv))))
    h = np.ones(1)
    for _ in range(nconv):
        h = np.convolve(h, np.ones(w))
    if len(h) > L:
        c = (len(h) + 1) // 2
        lo = max(0, c - L // 2); h = h[lo:lo + L]
    if len(h) < L:
        pad = L - len(h); h = np.concatenate([np.zeros(pad // 2), h, np.zeros(pad - pad // 2)])
    m = (len(h) - 1) / 2
    idx = np.arange(len(h)) - m
    h = h * np.exp(-0.5 * (idx / (sigma * m)) ** 2)
    return h / h.sum()

def zerophase(x, h):
    L = len(h); npad = min(3 * L, len(x) - 1)
    xp = np.concatenate([2*x[0]-x[1:npad+1][::-1], x, 2*x[-1]-x[-npad-1:-1][::-1]])
    y = np.convolve(xp, h, mode="same")
    y = np.convolve(y[::-1], h, mode="same")[::-1]
    return y[npad:npad+len(x)]

n = 4000
tt = np.arange(n)
h = crn(1.0, 0.02, 5)
cutoffs = np.linspace(0.01, 0.08, 12)
scale_naive, scale_corr = [], []
for hf_amp in [0.5]:
    pass
hf_amps = np.linspace(0, 1.0, 11)
for a in hf_amps:
    ymod = np.sin(2*np.pi*0.004*tt) + a*np.sin(2*np.pi*0.15*tt)
    yobs = zerophase(1.0 * ymod, h)                  # true scale = 1
    Xn = np.column_stack([np.ones(n), ymod - ymod.mean()])
    scale_naive.append(np.linalg.lstsq(Xn, yobs, rcond=None)[0][1])
    mf = zerophase(ymod, h)
    Xc = np.column_stack([np.ones(n), mf - mf.mean()])
    scale_corr.append(np.linalg.lstsq(Xc, yobs, rcond=None)[0][1])

fig, axs = plt.subplots(1, 2, figsize=(8, 2.6))
f = np.fft.rfftfreq(len(h) * 8, d=1.0)
H = np.abs(np.fft.rfft(h, len(h) * 8))
axs[0].semilogx(f[1:], 20*np.log10(np.maximum(H[1:], 1e-8)))
axs[0].axvline(0.02, color="r", ls="--", lw=0.8)
axs[0].set_xlabel("frequency [Hz]"); axs[0].set_ylabel("|H| [dB]")
axs[0].set_title("(a) CRN-style low-pass (ACC1B-like)")
axs[0].set_ylim(-80, 5)
axs[1].plot(hf_amps, scale_naive, "o-", label="uncorrected")
axs[1].plot(hf_amps, scale_corr, "s-", label="filter-consistent")
axs[1].axhline(1.0, color="k", ls="--", lw=0.8, label="truth")
axs[1].set_xlabel("high-freq. content in model")
axs[1].set_ylabel("fitted scale")
axs[1].set_title("(b) filter mismatch biases scale")
axs[1].legend(fontsize=6)
plt.savefig(f"{OUT}/fig_filter.pdf")
plt.close()
print(f"F5 scale (uncorrected, max HF) = {scale_naive[-1]:.4f}")
print(f"F5 scale (corrected,   max HF) = {scale_corr[-1]:.4f}")

# =====================================================================
# FIG 6 -- Polar decomposition
# =====================================================================
ang = np.array([2000., -1000., 1500.]) * 1e-6
W = np.array([[0, -ang[2], ang[1]], [ang[2], 0, -ang[0]], [-ang[1], ang[0], 0]])
th = np.linalg.norm(ang)
Rt = np.eye(3) + (np.sin(th)/th)*W + ((1-np.cos(th))/th**2)*(W@W)
Ut = np.array([[0.96,0.01,0.0],[0.01,1.03,0.005],[0.0,0.005,1.10]])
S = Rt @ Ut
R, U = polar_decompose(S)
fig, axs = plt.subplots(1, 3, figsize=(9, 2.3))
for ax, M, ttl in zip(axs, [S, R, U],
                      [r"$S$ (fitted, uninterpretable)", r"$R$ = misalignment", r"$U$ = scale + non-orthog."]):
    im = ax.imshow(M, cmap="RdBu_r", vmin=-1.15, vmax=1.15)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, f"{M[i,j]:.3f}", ha="center", va="center", fontsize=6)
    ax.set_title(ttl); ax.set_xticks([0,1,2]); ax.set_yticks([0,1,2])
plt.savefig(f"{OUT}/fig_polar.pdf")
plt.close()
print("F6 angles urad :", np.round(rotation_to_small_angles(R)*1e6, 2))
print("F6 scales      :", np.round(np.diag(U), 4))
print("F6 |R-Rt|      :", np.linalg.norm(R - Rt))
print("\nfigures written to", OUT)

# =====================================================================
# FIG 7 -- Exact ATBD CRN filter vs the approximation (and the cost)
# =====================================================================
from crn_atbd import crn_exact, crn_approx
F, meta = crn_exact()
A = crn_approx(10.0, 0.035, 7)

fig, axs = plt.subplots(1, 3, figsize=(10, 2.7))

# (a) kernels
nF = (np.arange(len(F)) - (len(F)-1)/2)/10
nA = (np.arange(len(A)) - (len(A)-1)/2)/10
axs[0].plot(nF, F/F.max(), label=f"ATBD exact ({len(F)/10:.1f} s)")
axs[0].plot(nA, A/A.max(), label=f"approximation ({len(A)/10:.1f} s)")
axs[0].set_xlabel("lag [s]"); axs[0].set_ylabel("normalised weight")
axs[0].set_title("(a) CRN kernel"); axs[0].legend(fontsize=6)

# (b) responses
f = np.logspace(-3.3, -0.5, 400)
def resp(h, f):
    n = np.arange(len(h)) - (len(h)-1)/2
    return np.array([abs(np.sum(h*np.exp(-2j*np.pi*fi*n/10))) for fi in f])
axs[1].loglog(f, resp(F, f), label="ATBD exact")
axs[1].loglog(f, resp(A, f), label="approximation")
axs[1].axvline(5/140.7, color="r", ls="--", lw=0.8, label="B = NB/Tf")
axs[1].axvline(0.37e-3, color="g", ls=":", lw=0.8, label="$f_0$ (J2)")
axs[1].set_ylim(1e-6, 3)
axs[1].set_xlabel("frequency [Hz]"); axs[1].set_ylabel("|H|")
axs[1].set_title("(b) response: approx. leaks badly")
axs[1].legend(fontsize=6)

# (c) induced scale bias
rng = np.random.default_rng(0)
N = 108000
t = np.arange(N)/10
def zp(x, h):
    L=len(h); npad=min(3*L,len(x)-1)
    xp=np.concatenate([2*x[0]-x[1:npad+1][::-1],x,2*x[-1]-x[-npad-1:-1][::-1]])
    y=np.convolve(xp,h,mode="same"); return y[npad:npad+len(x)]
def fs_(m,o):
    X=np.column_stack([np.ones(len(m)),m-m.mean()])
    return np.linalg.lstsq(X,o,rcond=None)[0][1]
hf = np.linspace(0, 0.6, 9)
sn, sa, se = [], [], []
for a in hf:
    ym = np.sin(2*np.pi*t/5400)+0.4*np.sin(4*np.pi*t/5400)+a*np.sin(2*np.pi*0.05*t)
    yo = zp(1.0*ym, F)
    sn.append(fs_(ym, yo)); sa.append(fs_(zp(ym,A), yo)); se.append(fs_(zp(ym,F), yo))
axs[2].plot(hf, sn, "o-", label="no correction")
axs[2].plot(hf, sa, "s-", label="approx. filter")
axs[2].plot(hf, se, "^-", label="ATBD exact")
axs[2].axhline(1.0, color="k", ls="--", lw=0.8)
axs[2].set_xlabel("high-freq. content in model")
axs[2].set_ylabel("fitted scale (truth = 1)")
axs[2].set_title("(c) residual scale bias")
axs[2].legend(fontsize=6)
plt.savefig(f"{OUT}/fig_crn_exact.pdf")
plt.close()
print(f"\nF7 DC gain (exact) = {F.sum():.7f}  (NOT 1 -- normalised at f0)")
print(f"F7 scale bias: none {sn[-1]:.4f}  approx {sa[-1]:.4f}  exact {se[-1]:.4f}")

# =====================================================================
# FIG 8 -- Time-varying scale: a static fit turns drift into "noise"
# =====================================================================
import sys as _sys
_sys.path.insert(0, '.')
from ref_core import bspline_basis, diff_penalty
rng = np.random.default_rng(0)
n = 6000; t = np.linspace(0, 12*3600, n)
y2 = 1 + 0.8*np.sin(2*np.pi*t/5400) + 0.3*np.sin(2*np.pi*t/1200)
s_true = 1.0 + 0.05*np.sin(2*np.pi*t/(12*3600))
b_true = 0.2 + 0.1*np.cos(2*np.pi*t/(3*3600))
y1 = b_true + s_true*y2 + 0.01*rng.standard_normal(n)

Bb,_ = bspline_basis(t, 30, 4); Bs,_ = bspline_basis(t, 3, 4)
X = np.hstack([Bb, Bs*y2[:,None]]); nb, ns = Bb.shape[1], Bs.shape[1]
Pb = diff_penalty(nb,2); Ps = diff_penalty(ns,2)
A = X.T@X; A[:nb,:nb] += 1e2*Pb; A[nb:,nb:] += 1e5*Ps
c = np.linalg.solve(A, X.T@y1)
s_fit = Bs@c[nb:]

Xst = np.hstack([Bb, y2[:,None]])
Ast = Xst.T@Xst; Ast[:nb,:nb] += 1e2*Pb
cst = np.linalg.solve(Ast, Xst.T@y1)
s_static = cst[-1]
r_static = y1 - Xst@cst
r_vary = y1 - X@c

fig, axs = plt.subplots(1, 3, figsize=(10, 2.7))
axs[0].plot(t/3600, s_true, 'k-', lw=2, label='true s(t)')
axs[0].plot(t/3600, s_fit, 'C0-', label='time-varying fit')
axs[0].axhline(s_static, color='C3', ls='--', label=f'static fit = {s_static:.4f}')
axs[0].set_xlabel('time [h]'); axs[0].set_ylabel('scale')
axs[0].set_title('(a) static fit reports the MEAN'); axs[0].legend(fontsize=6)

def acfc(x, K=200):
    x = x-x.mean(); return np.array([np.sum(x[:-k]*x[k:])/np.sum(x**2) for k in range(1,K)])
axs[1].plot(acfc(r_static), 'C3-', label=f'static (acf1={acfc(r_static,2)[0]:.2f})')
axs[1].plot(acfc(r_vary), 'C0-', label=f'time-varying (acf1={acfc(r_vary,2)[0]:.2f})')
axs[1].axhline(0, color='k', lw=0.5)
axs[1].set_xlabel('lag'); axs[1].set_ylabel('residual acf')
axs[1].set_title('(b) static drift LOOKS like colored noise'); axs[1].legend(fontsize=6)

# edge contamination vs gap count
half = 70.3
gaps = np.arange(0, 51, 5)
frac = 2*half*(gaps+1)/86400*100
axs[2].plot(gaps, frac, 'o-')
axs[2].set_xlabel('# data gaps in the arc'); axs[2].set_ylabel('% of day contaminated')
axs[2].set_title('(c) CRN edge loss (140.7 s kernel)')
plt.savefig(f"{OUT}/fig_timevarying.pdf")
plt.close()
print(f"\nF8 static scale = {s_static:.5f} (true range {s_true.min():.3f}-{s_true.max():.3f})")
print(f"F8 static residual acf1 = {acfc(r_static,2)[0]:.3f}  vary acf1 = {acfc(r_vary,2)[0]:.3f}")
