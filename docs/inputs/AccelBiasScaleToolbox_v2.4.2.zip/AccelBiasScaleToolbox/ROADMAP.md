# ROADMAP — AccelBiasScaleToolbox

**A handoff/orientation document.** Read this first. It explains what the toolbox is
for, what it found, how it is built, and what to do next — enough to resume work (or brief
a new collaborator, human or AI) without reading the development history.

---

## 1. The problem in one paragraph

You compare an observed non-gravitational acceleration (GRACE-FO `ACC1B`/`ACT1B`
accelerometer) against a modeled one (a GROOPS non-conservative force model), to estimate a
per-axis **bias** and **scale factor** via `y_obs(t) = b(t) + S · y_mod(t)`. The original
symptom: the fitted bias is stable but the **scale factor "varies a lot."** This toolbox
was built to determine whether that is an estimation artifact or a real physical signal —
and it turned out to be **both**, in a way that is now diagnosable.

---

## 2. The single most important result

On real GRACE-C data (2020-01-01), the per-revolution scale is a **genuine time drift**
(SNR 6.8–18.3, not noise), and it **anti-correlates with the modeled drag magnitude** on
the two drag-sensitive axes:

| axis | scale | 95% CI | corr(scale, drag) |
|------|-------|--------|-------------------|
| X (along-track) | 0.915 | [0.899, 0.933] | **−0.70** |
| Y (cross-track) | 1.035 | [1.026, 1.044] | **−0.74** |
| Z (radial)      | 1.057 | [1.042, 1.073] | −0.09 (n.s.) |

**Interpretation:** a scale that anti-correlates with drag is the signature of a
**density / drag-coefficient (Cd) force-model deficiency**, NOT a sensor scale error (which
would be flat versus drag). The model over-predicts the amplitude of the drag variation at
high-drag orbital phases. Z (radial, least drag-driven) is flat, as that explanation
predicts. So the "wild scale" is real, structured, drag-dependent, and points at the force
model — not the instrument. The model is otherwise good: it explains 96–97% of the observed
variance per axis.

**The one thing a single day cannot do:** separate a density-model error from a Cd error
from a genuine slow sensor drift. The drag varies only ~10% over one day, and only with
orbital phase. See §6 for the resolution.

---

## 3. Start here (the entry points)

```matlab
addpath(genpath('src'));

% ---- one call, from files, single day OR many ----
r = analyzeAccScaleArc( ...
      'ACT1B_2020-01-01_C_04.txt', ...                    % observed L1B
      'GRACEFO-1_nonConservativeForces_2020-01-01.txt');  % GROOPS model
disp(r.interpretation');     % per-axis plain-language verdict
```

For a multi-day arc, pass string lists in chronological order:

```matlab
obs   = compose("ACT1B_2020-01-%02d_C_04.txt", 1:31);
model = compose("GRACEFO-1_nonConservativeForces_2020-01-%02d.txt", 1:31);
r = analyzeAccScaleArc(obs, model, 'Save', 'jan2020.mat');
```

`analyzeAccScaleArc` does the whole pipeline: read (your L1B readers + `readGroopsInstrument`)
→ reconcile time systems → CRN-consistency → per-revolution scale with observability gating
→ block-bootstrap uncertainty → drag correlation → decomposition → frame check →
interpretation → consolidated caveats.

If your series are already in memory (arrays, not files), use `analyzeAccArc` instead.

**Verify first:** run `runAllTests` (32 test classes, ~209 methods). Everything was
validated in Python during development; the MATLAB suite is what confirms it runs correctly
in your environment.

---

## 4. The four findings the toolbox is built around

Each was measured against synthetic data with known truth, then embedded as a test
tolerance. These are the reasons a naive fit gives the wrong answer.

1. **Scale observability.** Where the model signal is nearly constant (quiet arc), bias and
   scale are collinear — `corr(bias, scale) = −1.0000` exactly. The estimator returns an
   arbitrary point in a flat valley. *Fix:* gate on observability, demean the regressor
   (→ correlation −2.8e−16). `scaleObservability`, `slidingWindowFit`.

2. **Filter consistency.** `ACC1B` is CRN-low-pass-filtered; a pointwise model is not.
   Uncorrected, this alone biased the fitted scale to **0.489** (truth 1.000). *Fix:*
   filter the model with the exact ATBD kernel. `crnFilter`, `applyCrnFilter`,
   `filterConsistency`.

3. **Colored residuals.** Both series are smooth, so residuals are autocorrelated and naive
   iid error bars are **5–14× too small** (confirmed on real data). *Fix:* AR whitening +
   moving-block bootstrap. `estimateNoiseModel`, `glsLinearFit`, `blockBootstrap`.

4. **Model selection.** Under colored noise, AIC *and* BIC both select the **maximally
   overfit** bias model. *Fix:* blocked cross-validation. `blockedCrossVal`,
   `accelBiasScaleModelCompare`. (AIC/BIC are kept only as reference, flagged
   `IC_unreliable`.)

---

## 5. The CRN filter, exactly (and its two traps)

`crnFilter` implements the filter exactly per the GRACE L1B ATBD (JPL D-27672, Appendix B).
ACC preset: `fs=10 Hz, Nc=7, Tf=140.7 s → Nf=1407 taps, NB=5`, realized bandwidth
`NB/Tf = 0.03554 Hz`.

- **Normalization is at f0 = 0.37 mHz (the J2 line, = 2/rev), NOT at DC.** True DC gain is
  **1.0004533**. This does not entangle bias/scale *if you use the same kernel the L1
  processor used* — the scale then comes back exactly. But renormalizing to `sum(h)=1` (the
  natural mistake) multiplies your scale by 1.0004533 = **+453 ppm**. An *approximate* CRN
  filter is worse: it left an **−11.5%** scale error, which looks exactly like physics.

- **The ACC→SRF axis relabelling is a proper rotation** (det=+1, 120° about (1,1,1)), so a
  forgotten or doubled permutation hides in a fitted `S` as a well-formed "misalignment" —
  the fit won't complain. `accFrameToSRF('check', S)` catches it. Real misalignment is
  milliradians; if you see *degrees*, it's bookkeeping.

- **Bias basis must be filtered too** (`[H·B, H·a]`, via `'BiasFilter'`), and never place
  bias knots closer than the 140.7 s kernel span (faster bias structure cannot exist in
  ACC1B — it's the filter's null space).

**⚠ The ATBD documents GRACE, not GRACE-FO.** The parameters are believed unchanged, but
confirm `Tf`, `Nc`, `NB` against the GRACE-FO Level-1 handbook before trusting ppm-level
numbers. All three are name-value overrides in `crnFilter`.

---

## 6. THE NEXT STEP (this is the roadmap)

The single most valuable thing to do next, and the reason a static one-day answer is not
the end:

**Run a multi-day arc spanning varied space weather, then regress per-revolution scale
against geophysical indices.** This is already a one-line call over a file list
(`analyzeAccScaleArc(obsList, modelList)`), which returns per-rev scale and drag per axis.
The missing piece is the index regression, which separates the causes:

- scale tracks **F10.7 / Kp** → **density-model** error (e.g. the thermosphere model)
- scale tracks **β-angle / argument-of-latitude only** → **geometry / Cd** error
- scale **drifts secularly**, independent of drag → **sensor drift / aging**

Concretely:
1. Pick a month that includes a geomagnetic storm (so drag varies for reasons other than
   orbital phase). GRACE-FO + F10.7/Kp from GFZ or NOAA.
2. Run `analyzeAccScaleArc` over the whole list. Collect `r.perRev.scale`, `r.perRev.dragMag`,
   and each window's mid-time.
3. Attach F10.7, F10.7a, Kp/Dst, β-angle, arg-of-latitude to each per-rev window.
4. Multiple-regress per-rev scale on those. The dominant predictor names the cause.

A `scaleFactorDiagnostics`-style function to do step 3–4 **now exists** in the
toolbox (`src/scaleFactorDiagnostics.m`): given the multi-day per-rev output and
per-rev index vectors (F10.7/Kp/Dst/β/arg-lat), it standardizes the predictors,
multiple-regresses the per-rev scale on them with block-bootstrap CIs, and votes
the dominant significant predictor's family into a cause (`density` / `geometry`
/ `sensor` / `mixed` / `unresolved`). Step 3 — attaching the indices to each
per-rev window — is the remaining user-supplied glue (a small index loader). This
is the direct path from "the model and data disagree" to a specific, fixable line
in the force model.

**Secondary next steps, if useful:**
- Time-varying scale on a single arc: `accelTimeVaryingScaleFit` fits `s(t)` as a penalized
  spline (smoother than the bias, to break aliasing) and returns an `isDriftSignificant`
  flag. Use it to confirm intra-day drift structure.
- Edge handling: `flagEdgeEffects` down-weights the ~70 s of CRN-contaminated data at each
  segment boundary; already wired into the wrapper.

---

## 7. What is NOT yet done / known limitations

- **Never executed in MATLAB.** All numerics were cross-validated in an independent Python
  implementation (`refval/`). `runAllTests` is the confirmation step you must run.
- **GRACE-FO vs GRACE CRN parameters** unconfirmed (see §5).
- **Off-diagonal `S` terms are untrustworthy over one day** — the model axes are correlated
  up to 0.61 (VIF 1.2–1.8), so cross-axis coupling and the polar-decomposition angles leak
  collinearity. Trust the diagonal scales; treat the "86 mrad misalignment" on the real day
  as an artifact, not a real frame error.
- **`scaleFactorDiagnostics` (index regression) now exists** (`src/scaleFactorDiagnostics.m`,
  tested in `tests/test_scaleFactorDiagnostics.m`). The per-rev index loader it depends on
  **also now exists** — `src/loadSpaceWeatherIndices.m` reads the GFZ combined
  `Kp_ap_Ap_SN_F107_since_1932.txt` file (or the nowcast/yearly variants) and maps
  F10.7/F10.7a/Kp/Ap/SN onto each per-rev window via `result.startMJD` + `perRev.tMid`,
  with orbit geometry (β, arg-lat, Dst) merged in through its `'Extra'` option. Tested in
  `tests/test_loadSpaceWeatherIndices.m`. The multi-day pipeline is therefore end-to-end.
- AR noise is an approximation to true flicker (1/f) noise; `blockBootstrap` is the
  assumption-light fallback.

---

## 8. Hard-won operational lessons

- **Get the time system right FIRST.** Three real-data alignment attempts failed purely on a
  botched MJD→GPS conversion. The fix: align on the UTC day boundary (both products' days
  start at 00:00 UTC), then refine with a cross-correlation lag. The leap-second offset
  (GPS−UTC=18 in 2020) is negligible within a day but a gross epoch error is fatal. The
  wrapper now does this and warns if the lag exceeds a few seconds.
- **Remove the mean before comparing.** The observed Y-axis is dominated by the large
  constant accelerometer bias (~−1.1e−5 m/s², ~500× the AC signal). Raw magnitude comparison
  is meaningless; the AC-coupled comparison is where the scale lives.
- **An approximate filter is worse than none for interpretation** — it produces a residual
  bias that looks like real physics.

---

## 9. Map of the toolbox

```
analyzeAccScaleArc   ← START HERE (files in, full diagnosis out; 1 or many days)
  analyzeAccArc      ← same pipeline for in-memory arrays
  plotScaleArc       ← its 4-panel summary figure

Reading:  readGroopsInstrument (model) · io/readGraceFoL1b[Multi] (user-provided, vendored)
Preflight: accelSeriesPreflight · qualityCheck · alignAccelSeries · crossCorrLag
           scaleObservability · slidingWindowFit · heteroscedasticityCheck · lombScarglePSD
Filter:    crnFilter · applyCrnFilter · filterConsistency · accFrameToSRF
Bias:      buildBiasDesign · bsplineBasis · diffPenaltyMatrix · gcvSelectLambda
Estimation: glsLinearFit · robustLinearFit · estimateNoiseModel · prewhitenSeries
            blockBootstrap · blockedCrossVal
Fitting:   accelBiasScaleModelFit · accelBiasScaleModelCompare · accelTimeVaryingScaleFit
           decomposeScaleMatrix · flagEdgeEffects
I/O:       accelCalibrationIO (save/load fitted calibration + provenance)
Validation: syntheticAccelPair (ground-truth generator) · test_integration_endToEnd

Docs:  doc/AccelBiasScaleToolbox_Reference.pdf (derivations, figures, all measured numbers)
       doc/index.html (function reference, registers with the MATLAB doc browser)
       refval/ (Python cross-validation; make_figs.py reproduces every figure and number)
       examples/ (6 runnable scripts; example_06 is the real-data single call)
```

---

## 10. One-line brief for a new chat

> I have a MATLAB toolbox (`AccelBiasScaleToolbox`) that estimates GRACE-FO accelerometer
> bias/scale against a GROOPS force model. On real GRACE-C data it found the per-axis scale
> anti-correlates with modeled drag (X −0.70, Y −0.74), which points at a density/Cd
> force-model deficiency rather than a sensor error. The single-call entry point is
> `analyzeAccScaleArc(obsFiles, modelFiles)`. Read `ROADMAP.md` §6 — I want to run a
> multi-day arc and regress per-rev scale against F10.7/Kp/β to separate density vs Cd vs
> drift. Everything is validated in Python; MATLAB tests exist but haven't been run in my
> environment yet.
