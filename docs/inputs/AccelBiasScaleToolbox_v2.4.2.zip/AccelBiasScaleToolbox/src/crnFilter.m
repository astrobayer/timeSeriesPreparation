function [h, info, hDot, hDDot] = crnFilter(product, varargin)
%CRNFILTER  CRN-class digital filter exactly as specified in the GRACE
%   Level-1B Algorithm Theoretical Basis Document (JPL D-27672 /
%   GRACE 327-741, Wu, Kruizinga & Bertiger, 2006), Appendix B.
%
%   [h, info] = crnFilter('ACC')
%   [h, info] = crnFilter('KBR')
%   [h, info] = crnFilter(..., 'Name', Value, ...)
%   [h, info, hDot, hDDot] = crnFilter(...)   % also the derivative kernels
%
%   This is the filter the Level-1 processor actually applies to ACC_1A to
%   produce ACC_1B. A force model evaluated pointwise has NOT been through
%   it, so comparing the two directly compares different spectral bands.
%
%   AN APPROXIMATE CRN FILTER IS NOT GOOD ENOUGH. In a controlled test with
%   a true scale of 1.000: leaving the mismatch uncorrected biased the
%   fitted scale to 0.873; correcting it with a plausible-looking
%   APPROXIMATE CRN filter still left 0.987 -- a 1.3% residual error,
%   exactly the size of effect one would otherwise attribute to a
%   density/Cd deficiency. With this exact kernel, the recovered scale is
%   1.00000.
%
%   PRODUCT presets (ATBD Appendix B)
%     'ACC'  fs = 10 Hz, Nc = 7, Tf = 140.7 s, B ~ 0.035 Hz   (-> ACC_1B)
%     'KBR'  fs = 10 Hz, Nc = 7, Tf =  70.7 s, B ~ 0.1   Hz   (-> KBR_1B)
%
%   NAME-VALUE (override any preset)
%     'fs'  raw data rate the filter acts on [Hz]
%     'Nc'  self-convolution number (odd)
%     'Tf'  fit interval [s]
%     'NB'  number of frequency bins in the passband. Default round(B*Tf).
%           The REALISED bandwidth is NB/Tf, reported in info.bandwidth:
%           0.03554 Hz for ACC and 0.09901 Hz for KBR. The ATBD's 0.035
%           and 0.1 Hz are nominal targets, not the exact values.
%     'B'   target bandwidth [Hz], used only to derive NB
%     'f0'  dominant (J2) signal frequency, 0.37e-3 Hz. See NORMALISATION.
%
%   CONSTRUCTION
%     With Nf = fs*Tf (odd), Nh = (Nf-1)/2, k the frequency-bin index, m
%     running over the passband bins, and n the time-lag index:
%
%       H_k   = [ sum_m  sin(pi*(k-m)/Nc) / sin(pi*(k-m)/Nf) ]^Nc
%       F_n   = (1/Fnorm) * sum_k H_k * cos(2*pi*k*n/Nf),      |n| <= Nh
%       Fnorm = sum_i cos(2*pi*f0*i/fs) * [ sum_k H_k cos(2*pi*k*i/Nf) ]
%
%     The ratio inside H_k is the DFT of a rectangular time window of
%     length Nf/Nc; raising it to the power Nc performs the Nc-fold
%     self-convolution, producing a window of total length Nf -- hence
%     "CRN" (self-Convolved Rectangular, N-th order). At k = m the ratio
%     has a removable singularity with value Nf/Nc.
%
%   NORMALISATION -- IMPORTANT, AND EASY TO GET WRONG
%     Fnorm forces unit gain at the DOMINANT SIGNAL FREQUENCY
%     f0 = 0.37 mHz (the J2 line), NOT at DC. The realised DC gain is
%     therefore NOT 1: it is 1.0004533 for the ACC filter. ACC_1B thus
%     carries a deliberate ~450 ppm gain difference between a constant
%     acceleration and the J2-band signal.
%
%     Note f0 = 0.37 mHz is exactly 2/rev for a ~5400 s orbit: the ATBD pins
%     unit gain on the J2 line, the signal it most wants to preserve. The
%     response then simply droops either side of it (DC +453 ppm, 1/rev
%     +340 ppm, 2/rev 0, 3/rev -568 ppm, 10 mHz -2.8e5 ppm).
%
%     WHAT THIS DOES AND DOES NOT DO:
%
%     It does NOT entangle bias with scale. Filter the model with the SAME
%     kernel the L1 processor used and the scale is recovered exactly
%     (measured: -0.0 ppm), because the filter's shape cancels between the
%     two sides of the regression.
%
%     It DOES mean the overall GAIN CONSTANT matters. The fitted scale is
%     inversely proportional to the regressor's gain, so renormalising this
%     kernel to unit DC gain -- i.e. h = h/sum(h), the natural thing to do
%     -- multiplies the fitted scale by 1.0004533: a +453 ppm error, right
%     at the precision accelerometer scale factors are quoted to. Earlier
%     versions of this toolbox did exactly that. Do not.
%
%     The one irreducible residue: the fitted BIAS is |H(0)| = 1.0004533
%     times the true physical bias. That is not recoverable from the data,
%     and does not need to be -- the bias is a nuisance parameter. It only
%     matters if you compare it against an independently known bias, in
%     which case divide by info.dcGain.
%
%     Finally: the BIAS DESIGN MATRIX must be filtered with this kernel too
%     (the bias in ACC_1B has been through the filter as well). See
%     ACCELBIASSCALEMODELFIT's 'BiasFilter' option.
%
%   OUTPUT
%     h     : Nf x 1 coefficients, symmetric (exactly linear phase).
%             sum(h) = 1.0004533 for ACC, by design.
%     info  : .fs .Nc .Tf .Nf .Nh .NB .f0 .product
%             .bandwidth    realised passband, NB/Tf [Hz]
%             .spanSeconds  Nf/fs
%             .dcGain       sum(h)      -- NOT 1, see above
%             .gainAtF0     |H(f0)|     -- 1 by construction
%     hDot  : first-derivative kernel, weights
%             -(2*pi*k/Tf)   * H_k * sin(2*pi*k*n/Nf)
%     hDDot : second-derivative kernel, weights
%             -(2*pi*k/Tf)^2 * H_k * cos(2*pi*k*n/Nf)
%             (the ATBD uses these to form KBR range-rate/acceleration)
%
%   COST
%     1407 taps for ACC; construction is O(Nf^2) ~ 2e6 flops. The kernel
%     depends only on the parameters -- build it ONCE and reuse it.
%
%   Example
%     [h, info] = crnFilter('ACC');
%     fprintf('DC gain = %.7f  (not 1!)\n', info.dcGain);
%     yModFilt = applyCrnFilter(yMod10Hz, h);
%
%   Reference
%     S.-C. Wu, G. Kruizinga, W. Bertiger, "Algorithm Theoretical Basis
%     Document for GRACE Level-1B Data Processing V1.2", JPL D-27672 /
%     GRACE 327-741, 2006: Appendix B (CRN-class digital filter) and
%     section 3 (ACC_compress).
%
%   See also APPLYCRNFILTER, FILTERCONSISTENCY, ACCFRAMETOSRF.

% ---- backward-compatibility shim -------------------------------------
% Earlier callers (syntheticAccelPair, test_filterConsistency) use a legacy
% signature crnFilter(fs, 'Cutoff', fc, 'NumConv', N) that builds a generic
% self-convolved-boxcar low-pass with a tunable cutoff, rather than the
% ATBD product kernel. Detect that convention and route to the legacy
% builder so the ATBD path (crnFilter('ACC'|'KBR', ...)) is unchanged.
isLegacy = (nargin >= 1 && isnumeric(product)) || ...
           any(strcmpi(varargin(1:2:end), 'Cutoff')) || ...
           any(strcmpi(varargin(1:2:end), 'NumConv'));
if isLegacy
    if nargin < 1 || ~isnumeric(product) || isempty(product)
        fsLegacy = 10;                 % default raw rate
    else
        fsLegacy = product;            % first positional arg is fs
    end
    [h, info] = legacyLowpass(fsLegacy, varargin{:});
    hDot = []; hDDot = [];
    return;
end
% ----------------------------------------------------------------------

if nargin < 1 || isempty(product)
    product = 'ACC';
end

switch upper(product)
    case 'ACC'
        d = struct('fs', 10, 'Nc', 7, 'Tf', 140.7, 'B', 0.035, 'f0', 0.37e-3);
    case 'KBR'
        d = struct('fs', 10, 'Nc', 7, 'Tf',  70.7, 'B', 0.100, 'f0', 0.37e-3);
    otherwise
        error('crnFilter:badProduct', ...
            'product must be ''ACC'' or ''KBR'' (got "%s").', product);
end

ip = inputParser;
ip.addParameter('fs', d.fs, @isnumeric);
ip.addParameter('Nc', d.Nc, @isnumeric);
ip.addParameter('Tf', d.Tf, @isnumeric);
ip.addParameter('B',  d.B,  @isnumeric);
ip.addParameter('NB', [],   @(x) isempty(x) || isnumeric(x));
ip.addParameter('f0', d.f0, @isnumeric);
ip.parse(varargin{:});
o = ip.Results;

if mod(o.Nc, 2) == 0
    error('crnFilter:evenNc', 'Nc must be an odd integer (ATBD App. B).');
end

%% --- derived sizes ---
Nf = round(o.fs * o.Tf);
if mod(Nf, 2) == 0
    Nf = Nf + 1;                 % ATBD requires Nf odd
end
Nh = (Nf - 1)/2;

NB = o.NB;
if isempty(NB)
    NB = round(o.B * o.Tf);
end
if NB < 1
    error('crnFilter:badNB', 'NB = round(B*Tf) must be at least 1.');
end

k = (-Nh:Nh).';      % frequency-bin index   (Nf x 1)
m = (-NB:NB);        % passband bins         (1 x 2NB+1)
n = (-Nh:Nh);        % time-lag index        (1 x Nf)

%% --- H_k ---
dkm   = k - m;
ratio = sin(pi*dkm / o.Nc) ./ sin(pi*dkm / Nf);
ratio(dkm == 0) = Nf / o.Nc;                    % removable singularity
H = sum(ratio, 2) .^ o.Nc;                      % Nf x 1

%% --- weights ---
C   = cos(2*pi * (k * n) / Nf);                 % Nf x Nf
Fun = (H.' * C).';                              % unnormalised weights

% unit gain at f0 -- NOT at DC (see NORMALISATION above)
Fnorm = sum(cos(2*pi*o.f0*n(:)/o.fs) .* Fun);
if abs(Fnorm) < eps
    error('crnFilter:degenerate', 'Normalisation factor is ~0; check parameters.');
end
h = Fun / Fnorm;

%% --- derivative kernels ---
if nargout > 2
    S = sin(2*pi * (k * n) / Nf);
    w = 2*pi*k / o.Tf;
    hDot  = ((-(w)    .* H).' * S).' / Fnorm;
    hDDot = ((-(w.^2) .* H).' * C).' / Fnorm;
end

%% --- info ---
nn = n(:);
info.product     = upper(product);
info.fs          = o.fs;
info.Nc          = o.Nc;
info.Tf          = o.Tf;
info.Nf          = Nf;
info.Nh          = Nh;
info.NB          = NB;
info.f0          = o.f0;
info.bandwidth   = NB / o.Tf;
info.spanSeconds = Nf / o.fs;
info.dcGain      = sum(h);
info.gainAtF0    = abs(sum(h .* exp(-2i*pi*o.f0*nn/o.fs)));
info.groupDelay  = 0;            % symmetric kernel; applied zero-phase

end

% ======================================================================
function [h, info] = legacyLowpass(fs, varargin)
%LEGACYLOWPASS  Generic self-convolved-boxcar low-pass (legacy crnFilter).
%   h = legacyLowpass(fs, 'Cutoff', fc, 'NumConv', N) returns a symmetric,
%   unit-DC-gain FIR low-pass built by self-convolving a boxcar NumConv
%   times (a "CRN-class" window in the loose sense) and truncating to the
%   -3 dB point set by Cutoff. This reproduces the pre-ATBD crnFilter API
%   used by syntheticAccelPair and test_filterConsistency.
%
%   INPUT
%     fs        scalar  sample rate [Hz]
%   NAME-VALUE
%     'Cutoff'  scalar  -3 dB cutoff frequency [Hz], 0 < fc < fs/2
%     'NumConv' scalar  number of boxcar self-convolutions (>=1, default 5)
%   OUTPUT
%     h    Lx1 double  symmetric FIR kernel, sum(h) == 1
%     info struct      .fs .cutoff .numConv .span .dcGain

ip = inputParser;
ip.addParameter('Cutoff', 0.02*fs, @(x) isnumeric(x) && isscalar(x));
ip.addParameter('NumConv', 5, @(x) isnumeric(x) && isscalar(x) && x >= 1);
ip.parse(varargin{:});
fc = ip.Results.Cutoff;
nc = round(ip.Results.NumConv);

if ~(fc > 0 && fc < fs/2)
    error('crnFilter:badCutoff', ...
        'Cutoff must satisfy 0 < Cutoff < fs/2 (got %g with fs=%g).', fc, fs);
end

% A single boxcar of length L has its -3 dB point near 0.443*fs/L. Self-
% convolving nc times narrows the response, so the -3 dB of the nc-fold
% cascade is reached with a SHORTER base boxcar: L ~ 0.443*fs/fc / sqrt(nc).
% (An earlier version multiplied by sqrt(nc), which over-attenuated the
% passband and left a scale bias the single-pass correction could not undo.)
L = max(2, round(0.443 * fs / fc / sqrt(nc)));

box = ones(L, 1) / L;         % unit-DC-gain boxcar
h = box;
for k = 2:nc
    h = conv(h, box);         % each conv preserves sum(h) = 1
end

% force exact symmetry and unit DC gain (guard against round-off)
h = (h + flipud(h)) / 2;
h = h / sum(h);

info = struct('fs', fs, 'cutoff', fc, 'numConv', nc, ...
    'span', numel(h), 'dcGain', sum(h));
end
