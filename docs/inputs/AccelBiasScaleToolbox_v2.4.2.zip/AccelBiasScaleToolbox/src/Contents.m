% ACCELBIASSCALETOOLBOX
% Diagnostics and estimation for observed vs. modeled non-gravitational
% accelerations (e.g. GRACE-FO ACC1B against a force model).
%
% Preflight (run this FIRST, on the raw pair)
%   accelSeriesPreflight      - Full preflight pipeline; returns a flag list
%   qualityCheck              - Gaps, duplicate/non-monotonic epochs, outliers
%   alignAccelSeries          - Gap-aware alignment, amplitude-preserving interp
%   crossCorrLag              - Timing/clock offset via cross-correlation
%   scaleObservability        - IS the scale identifiable? (start here if
%                               scale "varies wildly" -- usually it is not)
%   slidingWindowFit          - Windowed bias/scale preview, observability-gated
%   heteroscedasticityCheck   - Multiplicative vs additive error
%   lombScarglePSD            - Spectra on UNEVEN epochs (no gap interpolation)
%   plotAccelPreflight        - Figures + console summary
%
% Filter consistency (ACC1B is filtered; a pointwise model is not)
%   crnFilter                 - EXACT CRN filter from the GRACE L1B ATBD
%                               (JPL D-27672 App. B). Note its DC gain is
%                               1.0004533, NOT 1 -- see its help.
%   applyCrnFilter            - Put a model through the ACC_1B chain:
%                               10 Hz -> CRN -> sample at 1 Hz
%   filterConsistency         - 'explicit' | 'commonmode' | 'empirical' | 'none'
%   accFrameToSRF             - ACC<->SRF axis permutation, and a check for
%                               having forgotten it (it is a proper 120 deg
%                               rotation, so it hides in a fitted S)
%
% Bias models
%   buildBiasDesign           - constant | polynomial | spline | pspline
%   bsplineBasis              - Cox-de Boor basis; uniform or QUANTILE knots
%   diffPenaltyMatrix         - Roughness penalty for P-splines
%   gcvSelectLambda           - GCV smoothing-parameter selection
%
% Estimation and uncertainty
%   glsLinearFit              - Feasible GLS with AR noise; HONEST sigmas
%   robustLinearFit           - IRLS bisquare, optional penalty
%   estimateNoiseModel        - AR order/coefficients + effective sample size
%   prewhitenSeries           - Apply an AR whitening filter
%   blockBootstrap            - Moving-block CIs (assumption-light)
%   blockedCrossVal           - Contiguous-fold CV (use INSTEAD of AIC/BIC)
%
% Model fitting and comparison
%   accelBiasScaleModelFit    - Fit one bias/scale model; covariance; decomp
%   accelBiasScaleModelCompare- Rank candidate models by blocked CV
%   accelTimeVaryingScaleFit  - Scale AND bias as penalized splines s(t),b(t)
%                               -- use when a static scale drifts
%   decomposeScaleMatrix      - Polar decomposition: misalignment vs scale
%   plotBiasScaleModelCompare - Figures + console summary
%
% Orchestration and persistence
%   analyzeAccScaleArc        - SINGLE-CALL real-data entry point: reads
%                               ACC1B/ACT1B + GROOPS model (1 or many days),
%                               aligns, CRN-consistency, per-rev scale,
%                               drag diagnosis, interpretation
%   analyzeAccArc             - Lower-level pipeline on in-memory arrays
%   scaleFactorDiagnostics    - Multi-day cause attribution: regress per-rev
%                               scale on F10.7/Kp/beta to separate a
%                               density-model error from Cd vs sensor drift
%   loadSpaceWeatherIndices   - Read a GFZ Kp/ap/Ap/SN/F10.7 file and map
%                               its indices onto per-rev windows (feeds
%                               scaleFactorDiagnostics)
%   plotScaleArc              - Summary figures for analyzeAccScaleArc
%   flagEdgeEffects           - Down-weight CRN-contaminated segment ends
%   accelCalibrationIO        - Save/load fitted calibration + provenance
%
% I/O
%   readGroopsInstrument      - Read GROOPS instrument-format model files
%   io/readGraceFoL1b(Multi)  - USER-PROVIDED L1B readers (vendored)
%
% Validation
%   syntheticAccelPair        - Ground-truth generator with ALL defects
%                               injected (filter mismatch, colored noise,
%                               gaps, glitches, mismatched grids)
%
% See runAllTests.m (toolbox root) and examples/.
