function cv = blockedCrossVal(X, y, varargin)
%BLOCKEDCROSSVAL  Cross-validation with CONTIGUOUS folds -- the honest
%   model-selection criterion when residuals are autocorrelated.
%
%   cv = blockedCrossVal(X, y)
%   cv = blockedCrossVal(X, y, 'Name', Value, ...)
%
%   Why not AIC/BIC or random-fold CV:
%     * AIC/BIC assume independent residuals. Accelerometer-minus-model
%       residuals are smooth and strongly autocorrelated, so the
%       likelihood is overstated by roughly n/nEff, and BIC's parameter
%       penalty is calibrated against a sample size the data does not
%       actually have. The result is systematic OVER-selection of complex
%       bias models.
%     * Random K-fold CV is even worse here: a held-out point sits
%       between two training points microseconds away, so an overfit
%       model interpolates it almost perfectly and CV error barely rises.
%   Contiguous folds hold out a whole time block, so a model that has
%   merely memorized correlated noise cannot extrapolate into it. In a
%   reference AR(1) rho=0.95 experiment, blocked CV assigned RSS 4.2e3 to
%   a smooth-bias model and 9.2e6 to an over-rich one -- a decisive
%   separation that AIC/BIC and random-fold CV both blur.
%
%   NAME-VALUE
%     'NumFolds' (5)     number of contiguous folds
%     'Penalty'  ([])    penalty matrix passed to the inner fit
%     'Lambda'   (0)     penalty weight
%     'Robust'   (false) robust inner fit
%     'Gap'      (0)     samples excluded on EACH side of the test block
%                        ("purged"/embargoed CV). Set to about the
%                        residual correlation length to stop training
%                        points immediately adjacent to the test block
%                        from leaking information across the boundary.
%
%   OUTPUT (struct)
%     .rss        total out-of-fold residual sum of squares (the score to
%                 MINIMIZE when comparing models)
%     .rmse       sqrt(rss / nPredicted)
%     .foldRSS    per-fold RSS
%     .nPredicted total number of out-of-fold predictions made
%     .numFolds, .gap
%
%   Compare models by fitting each candidate design matrix and choosing
%   the lowest .rss. All candidates must be scored on the SAME rows.
%
%   See also GLSLINEARFIT, ESTIMATENOISEMODEL, ACCELBIASSCALEMODELCOMPARE.

ip = inputParser;
ip.addParameter('NumFolds', 5, @isnumeric);
ip.addParameter('Penalty', [], @(x) isempty(x) || ismatrix(x));
ip.addParameter('Lambda', 0, @isnumeric);
ip.addParameter('Robust', false, @islogical);
ip.addParameter('Gap', 0, @isnumeric);
ip.parse(varargin{:});
opt = ip.Results;

y = y(:);
n = numel(y);
p = size(X,2);

P = opt.Penalty;
if isempty(P), P = zeros(p); end

edges = round(linspace(0, n, opt.NumFolds+1));

foldRSS = zeros(opt.NumFolds,1);
nPred = 0;

for k = 1:opt.NumFolds
    testIdx = false(n,1);
    testIdx(edges(k)+1 : edges(k+1)) = true;

    % purge a gap on either side of the test block
    trainIdx = ~testIdx;
    if opt.Gap > 0
        lo = max(1, edges(k)+1 - opt.Gap);
        hi = min(n, edges(k+1) + opt.Gap);
        trainIdx(lo:hi) = false;
    end

    if nnz(trainIdx) < p + 1
        continue;   % not enough training data to identify the model
    end

    Xtr = X(trainIdx,:); ytr = y(trainIdx);
    if opt.Robust
        coef = robustLinearFit(Xtr, ytr, 'Penalty', P, 'Lambda', opt.Lambda);
    elseif opt.Lambda == 0
        coef = Xtr \ ytr;
    else
        coef = (Xtr'*Xtr + opt.Lambda*P) \ (Xtr'*ytr);
    end

    r = y(testIdx) - X(testIdx,:)*coef;
    foldRSS(k) = r'*r;
    nPred = nPred + nnz(testIdx);
end

cv.rss = sum(foldRSS);
cv.foldRSS = foldRSS;
cv.nPredicted = nPred;
if nPred > 0
    cv.rmse = sqrt(cv.rss / nPred);
else
    cv.rmse = NaN;
end
cv.numFolds = opt.NumFolds;
cv.gap = opt.Gap;

end
