function plotScaleArc(result, t, Y1, Y2)
%PLOTSCALEARC  Summary figures for ANALYZEACCSCALEARC.
%
%   plotScaleArc(result, t, Y1, Y2)
%
%   Draws a 2x2 figure:
%     (a) observed vs. scaled model on the along-track axis (first revs)
%     (b) per-revolution scale factor over the arc, per axis, with drag
%         magnitude overlaid -- the "stable bias, varying scale" view
%     (c) per-revolution scale vs. modeled drag magnitude (the scatter
%         whose slope separates a force-model issue from a sensor error)
%     (d) whole-arc scale with naive vs. block-bootstrap error bars
%
%   INPUT
%     result - the struct returned by ANALYZEACCSCALEARC
%     t      - Nx1 aligned epochs [s from arc start]
%     Y1,Y2  - Nx3 aligned observed / modeled accelerations
%
%   This is a helper; call ANALYZEACCSCALEARC with 'Plot', true instead of
%   invoking it directly.
%
%   See also ANALYZEACCSCALEARC.

per = result.perRev;
axNames = {'X','Y','Z'};
axCol = lines(3);

figure('Name','analyzeAccScaleArc','Color','w','Position',[100 100 1000 720]);

%% (a) obs vs scaled model, along-track, first ~3 revs
subplot(2,2,1);
Torb = 5400;
nShow = min(numel(t), 3*Torb);
sel = 1:nShow;
plot(t(sel)/3600, Y1(sel,1)*1e9, 'LineWidth', 0.6); hold on;
% remove the bias for overlay, apply the fitted scale
mu = mean(Y2(:,1));
scaled = result.scaleGlobal(1)*(Y2(sel,1)-mu);
plot(t(sel)/3600, (scaled + (mean(Y1(sel,1))))*1e9, 'LineWidth', 0.6);
xlabel('time [h]'); ylabel('accel X [nm/s^2]');
title('(a) observed vs. scaled model (X)');
legend({'observed','scaled model'}, 'Location','best','FontSize',7);
grid on;

%% (b) per-rev scale + drag over the arc
subplot(2,2,2);
yyaxis left;
for i = 1:3
    plot(per.tMid/3600, per.scale(:,i), '.-', 'Color', axCol(i,:), ...
        'MarkerSize', 10, 'LineWidth', 0.8); hold on;
end
yline(1, ':', 'Color', [.5 .5 .5]);
ylabel('per-rev scale');
yyaxis right;
plot(per.tMid/3600, per.dragMag*1e8, 'k--', 'LineWidth', 1);
ylabel('model |drag| [10^{-8} m/s^2]');
xlabel('time [h]');
title('(b) per-rev scale (stable bias, varying scale)');
legend([axNames, {'|drag|'}], 'Location','best','FontSize',7);
grid on;

%% (c) scale vs drag scatter
subplot(2,2,3);
for i = 1:3
    m = isfinite(per.scale(:,i));
    if nnz(m) < 2, continue; end
    scatter(per.dragMag(m)*1e8, per.scale(m,i), 30, axCol(i,:), 'filled', ...
        'DisplayName', sprintf('%s: r=%+.2f', axNames{i}, result.dragCorr(i))); hold on;
    p = polyfit(per.dragMag(m)*1e8, per.scale(m,i), 1);
    xx = linspace(min(per.dragMag*1e8), max(per.dragMag*1e8), 10);
    plot(xx, polyval(p,xx), '-', 'Color', axCol(i,:), 'HandleVisibility','off');
end
xlabel('model |drag| [10^{-8} m/s^2]'); ylabel('per-rev scale');
title('(c) scale vs drag: slope => force-model issue');
legend('Location','best','FontSize',7);
grid on;

%% (d) naive vs bootstrap error bars
subplot(2,2,4);
xp = 1:3;
% recompute naive sigma for display
naive = result.scaleGlobalSigma ./ max(result.sigmaInflation, realmin);
errorbar(xp-0.1, result.scaleGlobal, 1.96*naive, 'o', 'CapSize', 8, ...
    'LineWidth', 1, 'DisplayName', 'naive iid 95%'); hold on;
errorbar(xp+0.1, result.scaleGlobal, 1.96*result.scaleGlobalSigma, 's', 'CapSize', 8, ...
    'LineWidth', 1, 'DisplayName', 'block-boot 95%');
yline(1, ':', 'Color', [.5 .5 .5]);
set(gca, 'XTick', xp, 'XTickLabel', axNames);
ylabel('scale'); xlim([0.5 3.5]);
title(sprintf('(d) error bars (naive up to %.0fx too small)', max(result.sigmaInflation)));
legend('Location','best','FontSize',7);
grid on;

end
