function fit = accelBiasScaleModelFit(tA, Y1A, Y2A, modelSpec, varargin)
%ACCELBIASSCALEMODELFIT  Fit  y1_i(t) = bias_i(t) + sum_j S(i,j)*y2_j(t)
%   for each observed axis i, with an AR noise model, honest uncertainties,
%   and a physical decomposition of the fitted scale matrix.
%
%   fit = accelBiasScaleModelFit(tA, Y1A, Y2A, modelSpec)
%   fit = accelBiasScaleModelFit(..., 'Name', Value, ...)
%
%   Operates on ALREADY-ALIGNED data (see ALIGNACCELSERIES), so it can be
%   called repeatedly for model comparison without re-aligning.
%
%   MODELSPEC
%     .ScaleModel : 'diagonal'   axis i explained by model axis i only
%                   'full'       axis i regressed on ALL model axes,
%                                giving a full MxM coupling matrix. The
%                                result is polar-decomposed into a
%                                misalignment rotation and a scale/
%                                non-orthogonality stretch -- see
%                                DECOMPOSESCALEMATRIX, and read
%                                fit.decomp.condS before trusting the
%                                off-diagonal terms.
%                   MxM logical  custom sparsity mask; mask(i,j) = true
%                                means model axis j is a regressor for
%                                observed axis i.
%     .BiasModel  : struct for BUILDBIASDESIGN --
%                   struct('type','constant')
%                   struct('type','polynomial','order',3)
%                   struct('type','spline','numInteriorKnots',8)
%                   struct('type','pspline','numInteriorKnots',35)
%                   'pspline' is recommended: give it a generous knot
%                   count and let the roughness penalty (lambda, chosen
%                   automatically) decide the flexibility.
%
%   NAME-VALUE
%     'Robust'      (true)   IRLS bisquare inner fit
%     'NoiseModel'  (true)   estimate an AR model of the residuals and
%                            run feasible GLS. Turning this OFF gives
%                            OLS-style sigmas that are typically several
%                            times too small.
%     'Demean'      (true)   center the model regressors before fitting,
%                            decorrelating bias from scale. The fitted S
%                            is unaffected; the bias is mapped back to the
%                            original parameterization.
%     'Lambda'      ([])     penalty weight for a 'pspline' bias. If empty
%                            and the bias is penalized, it is selected
%                            automatically by 'LambdaSelect'.
%     'LambdaSelect'('cv')   'cv'  -- BLOCKEDCROSSVAL (robust to
%                                     autocorrelated residuals; preferred)
%                            'gcv' -- GCVSELECTLAMBDA (faster, but
%                                     under-smooths when residuals are
%                                     correlated)
%     'Bootstrap'   (false)  run BLOCKBOOTSTRAP for assumption-light
%                            confidence intervals (slower)
%     'NumBoot'     (300)
%     'NumFolds'    (5)      folds for 'cv' lambda selection
%     'BiasFilter'  ([])     CRN kernel (from CRNFILTER). If given, the BIAS
%                            DESIGN MATRIX is filtered with it as well as the
%                            model, giving the correct design [H*B, H*a].
%
%       The bias present in ACC_1B has been through the L1 filter, so the
%       basis representing it must be too. Measured cost of omitting this:
%       under 10 ppm of scale when the bias knots are spaced at or above the
%       filter span (140.7 s), but -1377 ppm at 70 s spacing.
%
%       Supplying this also enables an IDENTIFIABILITY CHECK: bias structure
%       faster than the kernel span cannot be present in the observation at
%       all, so knots closer than that are estimating the filter's null
%       space. A warning is raised and recorded in fit.biasInfo.
%
%   OUTPUT (struct)
%     .axis(i) : .biasCoef, .scaleCoef, .scaleAxes
%                .biasFitted   bias_i(t) evaluated at tA
%                .yFitted, .residuals
%                .R2, .RSS, .edf
%                .sigma        formal standard errors (GLS, whitened)
%                .sigmaNaive   the iid-OLS sigmas, for comparison
%                .sigmaInflation  sigma ./ sigmaNaive. If this is ~5, any
%                              error bar you previously quoted from an OLS
%                              fit was about 5x too small.
%                .noiseModel   ESTIMATENOISEMODEL of the residuals; check
%                              .verdict and .nEffRatio
%                .cov          parameter covariance
%                .boot         BLOCKBOOTSTRAP output (if requested)
%                .lambda       penalty actually used
%     .S       : MxM fitted scale matrix (NaN where not estimated)
%     .covS    : covariance of vec(S), assembled from the per-axis
%                covariances (rows of S are fitted independently, so this
%                is block-diagonal by construction)
%     .decomp  : DECOMPOSESCALEMATRIX output -- misalignment angles,
%                per-axis scales, non-orthogonality. THIS is what to read,
%                not the raw entries of S.
%     .modelLabel, .modelSpec, .tA
%
%   NOTE ON AIC/BIC: deliberately NOT reported. With autocorrelated
%   residuals the likelihood behind them is invalid, and under a robust
%   (IRLS) or penalized fit the parameter count is not even well defined.
%   Use ACCELBIASSCALEMODELCOMPARE, which scores models by blocked CV.
%
%   See also GLSLINEARFIT, BUILDBIASDESIGN, DECOMPOSESCALEMATRIX,
%            BLOCKBOOTSTRAP, ACCELBIASSCALEMODELCOMPARE.

ip = inputParser;
ip.addParameter('Robust', true, @islogical);
ip.addParameter('NoiseModel', true, @islogical);
ip.addParameter('Demean', true, @islogical);
ip.addParameter('Lambda', [], @(x) isempty(x) || isnumeric(x));
ip.addParameter('LambdaSelect', 'cv', @ischar);
ip.addParameter('Bootstrap', false, @islogical);
ip.addParameter('NumBoot', 300, @isnumeric);
ip.addParameter('NumFolds', 5, @isnumeric);
ip.addParameter('BiasFilter', [], @(x) isempty(x) || isvector(x));
ip.parse(varargin{:});
opt = ip.Results;

tA = tA(:);
if isvector(Y1A), Y1A = Y1A(:); end
if isvector(Y2A), Y2A = Y2A(:); end

M = size(Y1A,2);
n = size(Y1A,1);
if size(Y2A,2) ~= M
    error('accelBiasScaleModelFit:axisMismatch', ...
        'Y1A has %d columns, Y2A has %d.', M, size(Y2A,2));
end

%% --- scale sparsity mask ---
if ischar(modelSpec.ScaleModel)
    switch lower(modelSpec.ScaleModel)
        case 'diagonal', mask = eye(M) > 0;
        case 'full',     mask = true(M,M);
        otherwise
            error('accelBiasScaleModelFit:unknownScaleModel', ...
                'Unknown ScaleModel "%s".', modelSpec.ScaleModel);
    end
else
    mask = logical(modelSpec.ScaleModel);
end

%% --- bias design (shared across axes) ---
[B, biasInfo] = buildBiasDesign(tA, modelSpec.BiasModel);
nB = biasInfo.nParams;

%% --- filter the BIAS BASIS with the same kernel as the model ---
% The correct design is [H*B, H*a], not [B, H*a]: the bias present in ACC1B
% has been through the L1 filter, so the basis used to represent it must be
% too. Leaving it unfiltered costs <10 ppm of scale when the bias knots are
% spaced at or above the kernel span, but -1377 ppm at 70 s spacing.
biasInfo.knotSpacingWarning = '';
if ~isempty(opt.BiasFilter)
    h = opt.BiasFilter(:);
    Bf = zeros(size(B));
    for j = 1:size(B,2)
        Bf(:,j) = centredFIRLocal(B(:,j), h);
    end
    B = Bf;
    biasInfo.filtered = true;

    % identifiability floor: bias structure faster than the kernel span
    % cannot be present in the observation at all.
    kernelSpan = numel(h) * median(diff(tA));
    if ~isempty(biasInfo.knots)
        ks = median(diff(unique(biasInfo.knots)));
        if isfinite(ks) && ks > 0 && ks < kernelSpan
            biasInfo.knotSpacingWarning = sprintf(['Bias knot spacing (%.1f s) is ' ...
                'below the L1 filter span (%.1f s). Bias structure that fast ' ...
                'CANNOT exist in the filtered observation -- those coefficients ' ...
                'are estimating the filter''s null space. Widen the knots.'], ...
                ks, kernelSpan);
            warning('accelBiasScaleModelFit:knotsBelowFilterSpan', '%s', ...
                biasInfo.knotSpacingWarning);
        end
    end
else
    biasInfo.filtered = false;
end

%% --- regressor centering (decorrelates bias from scale) ---
mu = zeros(1, M);
if opt.Demean
    mu = mean(Y2A, 1);
end
Y2c = Y2A - mu;

S = nan(M,M);
covS = zeros(M*M, M*M);
axisOut = struct([]);

for i = 1:M
    scaleAxes = find(mask(i,:));
    X = [B, Y2c(:, scaleAxes)];
    y = Y1A(:,i);
    p = size(X,2);

    %% --- penalty: only the bias block is penalized ---
    P = zeros(p);
    if biasInfo.isPenalized
        P(1:nB, 1:nB) = biasInfo.penalty;
    end

    %% --- choose lambda ---
    lam = 0;
    if biasInfo.isPenalized
        if ~isempty(opt.Lambda)
            lam = opt.Lambda;
        elseif ~isempty(biasInfo.lambda)
            lam = biasInfo.lambda;
        else
            lam = selectLambda(X, y, P, opt);
        end
    end

    %% --- the fit ---
    g = glsLinearFit(X, y, ...
        'Robust', opt.Robust, ...
        'NoiseModel', opt.NoiseModel, ...
        'Penalty', P, 'Lambda', lam);

    coef = g.coef;
    biasCoefC = coef(1:nB);
    scaleCoef = coef(nB+1:end);

    %% --- undo the centering: bias absorbs -S*mu ---
    % y = Bc*bias_c + sum_j s_j*(y2_j - mu_j)
    %   = B*(bias_c - (sum_j s_j*mu_j) * e1_equivalent) + sum_j s_j*y2_j
    % The constant shift -sum_j s_j*mu_j must be added to the bias CURVE.
    % Every supported bias basis contains the constant function in its
    % span (constant: trivially; polynomial: degree 0; B-spline: partition
    % of unity), so the shift is representable exactly.
    shift = -sum(scaleCoef(:)' .* mu(scaleAxes));
    biasFittedC = B * biasCoefC;
    biasFitted = biasFittedC + shift;

    % express the shifted bias back in basis coefficients (least squares
    % against the basis; exact, since the constant lies in span(B))
    biasCoef = B \ biasFitted;

    yFitted = biasFitted + Y2A(:, scaleAxes) * scaleCoef(:);
    resid = y - yFitted;

    RSS = resid'*resid;
    SST = sum((y - mean(y)).^2);

    %% --- optional block bootstrap ---
    bootOut = [];
    if opt.Bootstrap
        bootOut = blockBootstrap(X, y, 'NumBoot', opt.NumBoot, ...
            'Robust', false);
    end

    ax = struct();
    ax.biasCoef = biasCoef;
    ax.scaleCoef = scaleCoef(:);
    ax.scaleAxes = scaleAxes;
    ax.biasFitted = biasFitted;
    ax.yFitted = yFitted;
    ax.residuals = resid;
    ax.RSS = RSS;
    ax.R2 = 1 - RSS/max(SST, eps);
    ax.edf = g.edf;
    ax.sigma = g.sigma;
    ax.sigmaNaive = g.sigmaNaive;
    ax.sigmaInflation = g.sigmaInflation;
    ax.noiseModel = g.noiseModel;
    ax.cov = g.cov;
    ax.lambda = lam;
    ax.boot = bootOut;
    ax.mu = mu(scaleAxes);

    axisOut = [axisOut, ax]; %#ok<AGROW>

    S(i, scaleAxes) = scaleCoef(:)';

    % scatter the scale-block covariance into cov(vec(S)) (column-major)
    covBlock = g.cov(nB+1:end, nB+1:end);
    for a = 1:numel(scaleAxes)
        for b = 1:numel(scaleAxes)
            ia = (scaleAxes(a)-1)*M + i;
            ib = (scaleAxes(b)-1)*M + i;
            covS(ia, ib) = covBlock(a, b);
        end
    end
end

fit.axis = axisOut;
fit.S = S;
fit.covS = covS;
fit.tA = tA;
fit.modelSpec = modelSpec;
fit.biasInfo = biasInfo;
fit.modelLabel = sprintf('scale=%s, bias=%s', ...
    describeScale(modelSpec.ScaleModel), describeBias(modelSpec.BiasModel));

%% --- physical decomposition of S ---
if M == 3
    fit.decomp = decomposeScaleMatrix(S, covS);
else
    fit.decomp = [];
end

end

% ===================================================================
function lam = selectLambda(X, y, P, opt)
grid = logspace(-6, 6, 25);
switch lower(opt.LambdaSelect)
    case 'gcv'
        lam = gcvSelectLambda(X, y, P, grid);
    case 'cv'
        score = inf(numel(grid),1);
        for k = 1:numel(grid)
            cv = blockedCrossVal(X, y, 'NumFolds', opt.NumFolds, ...
                'Penalty', P, 'Lambda', grid(k), 'Robust', false);
            score(k) = cv.rss;
        end
        [~, iBest] = min(score);
        lam = grid(iBest);
    otherwise
        error('accelBiasScaleModelFit:badLambdaSelect', ...
            'LambdaSelect must be ''cv'' or ''gcv''.');
end
end

function y = centredFIRLocal(x, h)
%CENTREDFIRLOCAL  Single centred pass with a symmetric kernel (no filtfilt:
%   that would apply the filter twice and square its response).
h = h(:);
Nh = (numel(h)-1)/2;
n = numel(x);
np = min(round(Nh), n-1);
if np < 1, y = x; return; end
xp = [2*x(1) - flipud(x(2:np+1)); x; 2*x(end) - flipud(x(end-np:end-1))];
yf = conv(xp, h, 'same');
y = yf(np+1 : np+n);
end

function s = describeScale(sm)
if ischar(sm), s = sm; else, s = 'custom-mask'; end
end

function s = describeBias(bm)
switch lower(bm.type)
    case 'constant',   s = 'constant';
    case 'polynomial', s = sprintf('poly(%d)', bm.order);
    case 'spline',     s = sprintf('spline(%d)', bm.numInteriorKnots);
    case 'pspline',    s = sprintf('pspline(%d)', bm.numInteriorKnots);
    otherwise,         s = bm.type;
end
end
