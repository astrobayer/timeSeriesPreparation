function [P, f] = lombScarglePSD(t, y, varargin)
%LOMBSCARGLEPSD  Lomb-Scargle periodogram for UNEVENLY sampled data.
%
%   [P, f] = lombScarglePSD(t, y)
%   [P, f] = lombScarglePSD(t, y, 'Freq', f, 'OverSample', 4)
%
%   Use this instead of PWELCH whenever the series has gaps. Running
%   PWELCH on gap-interpolated data feeds the spectrum estimator values
%   that were manufactured by the interpolator, not measured: linear
%   interpolation across a hole is a smooth ramp, which injects spurious
%   low-frequency power and suppresses power at and above the gap scale.
%   The Lomb-Scargle periodogram fits sinusoids directly to the samples
%   that actually exist, at their true epochs, so no fabricated data
%   enters the estimate.
%
%   INPUT
%     t : Nx1 epochs (need not be uniform; need not be sorted)
%     y : Nx1 values (non-finite samples are dropped)
%
%   NAME-VALUE
%     'Freq'       ([])  explicit frequency grid [1/time-unit]. If empty,
%                        built from 1/T up to the mean-Nyquist frequency.
%     'OverSample' (4)   frequency oversampling factor when Freq is auto
%     'Normalize'  (true) normalize by the data variance (standard
%                        Scargle normalization, so a pure noise series has
%                        P ~ exponentially distributed with unit mean)
%
%   OUTPUT
%     P : power at each frequency
%     f : the frequency grid used
%
%   Note the mean is removed before evaluation, as the classical
%   Lomb-Scargle formulation assumes a zero-mean signal; a nonzero mean
%   would otherwise leak into the lowest frequencies.
%
%   See also ACCELSERIESPREFLIGHT, ESTIMATENOISEMODEL.

ip = inputParser;
ip.addParameter('Freq', [], @(x) isempty(x) || isvector(x));
ip.addParameter('OverSample', 4, @isnumeric);
ip.addParameter('Normalize', true, @islogical);
ip.parse(varargin{:});
opt = ip.Results;

t = t(:); y = y(:);
ok = isfinite(t) & isfinite(y);
t = t(ok); y = y(ok);
[t, iSort] = sort(t);
y = y(iSort);

n = numel(t);
if n < 4
    P = []; f = [];
    return;
end

y = y - mean(y);
vy = var(y, 1);

f = opt.Freq;
if isempty(f)
    T = t(end) - t(1);
    dtMean = T / (n-1);
    fMin = 1/T;
    fMax = 1/(2*dtMean);            % mean-Nyquist
    df = fMin / max(opt.OverSample, 1);
    f = (fMin : df : fMax)';
end
f = f(:);

P = zeros(numel(f), 1);
for k = 1:numel(f)
    w = 2*pi*f(k);
    wt = w * t;

    s2 = sum(sin(2*wt));
    c2 = sum(cos(2*wt));
    tau = atan2(s2, c2) / (2*w);    % time offset making the basis orthogonal

    wtt = w * (t - tau);
    cw = cos(wtt);
    sw = sin(wtt);

    cc = sum(cw.^2);
    ss = sum(sw.^2);

    num1 = sum(y .* cw)^2;
    num2 = sum(y .* sw)^2;

    term1 = 0; term2 = 0;
    if cc > eps, term1 = num1 / cc; end
    if ss > eps, term2 = num2 / ss; end

    P(k) = 0.5 * (term1 + term2);
end

if opt.Normalize && vy > eps
    P = P / vy;
end

end
