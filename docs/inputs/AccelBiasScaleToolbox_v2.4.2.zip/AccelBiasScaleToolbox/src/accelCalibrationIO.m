function varargout = accelCalibrationIO(mode, varargin)
%ACCELCALIBRATIONIO  Persist and reload fitted bias/scale calibration
%   results, with provenance, so a full gravity-field adjustment can ingest
%   them without re-running the estimation.
%
%   accelCalibrationIO('save', filename, fit)
%   accelCalibrationIO('save', filename, fit, 'Meta', metaStruct)
%   cal = accelCalibrationIO('load', filename)
%
%   The saved record is a plain struct written with MAT -v7.3 (so it is
%   readable outside MATLAB via HDF5 if needed) OR, if 'Format' is 'json',
%   as JSON for language-neutral ingestion. It deliberately stores the
%   fitted PARAMETERS and their covariance -- not the raw series -- so it
%   is small and portable.
%
%   WHAT IS STORED
%     .S              fitted scale matrix (or NaN if a single-axis fit)
%     .covS           covariance of vec(S)
%     .decomp         polar decomposition (misalignment / scale / non-orth)
%     .biasModel      the bias model spec used
%     .perAxis        per-axis: scale coeffs, bias coeffs+knots, sigmas,
%                     noise-model verdict, sigma inflation
%     .timeVarying    if a time-varying-scale fit: the scale/bias curves,
%                     their sigma bands, drift significance
%     .provenance     toolbox version, timestamp, filter used (product,
%                     Nf, dcGain), interp method, filter strategy, git-like
%                     hash of the option set, and any user Meta
%
%   The point of the provenance block is that a scale factor is meaningless
%   without knowing HOW it was produced -- in particular which filter
%   normalization was used, since that alone moves the scale by ~450 ppm.
%   A downstream user must be able to check compatibility.
%
%   NAME-VALUE (save)
%     'Meta'   ([])      struct of arbitrary user metadata (arc ID,
%                        satellite, date range, data version, ...)
%     'Format' ('mat')   'mat' or 'json'
%
%   OUTPUT
%     load mode returns the reconstructed calibration struct.
%
%   Example
%     fit = accelBiasScaleModelFit(...);
%     accelCalibrationIO('save', 'graceA_2024001.mat', fit, ...
%         'Meta', struct('sat','GRACE-C','arc','2024-001'));
%     cal = accelCalibrationIO('load', 'graceA_2024001.mat');
%     use  = cal.S;   % ingest into the adjustment
%
%   See also ACCELBIASSCALEMODELFIT, ACCELTIMEVARYINGSCALEFIT, ANALYZEACCARC.

switch lower(mode)
    case 'save'
        saveCalibration(varargin{:});
    case 'load'
        varargout{1} = loadCalibration(varargin{:});
    otherwise
        error('accelCalibrationIO:badMode', 'mode must be ''save'' or ''load''.');
end

end

% ===================================================================
function saveCalibration(filename, fit, varargin)

ip = inputParser;
ip.addParameter('Meta', [], @(x) isempty(x) || isstruct(x));
ip.addParameter('Format', 'mat', @ischar);
ip.parse(varargin{:});
opt = ip.Results;

cal = struct();

%% --- provenance ---
cal.provenance.toolboxVersion = toolboxVersion();
cal.provenance.savedAt = datestr(now, 'yyyy-mm-ddTHH:MM:SS');
cal.provenance.matlabVersion = version();
if ~isempty(opt.Meta)
    cal.provenance.meta = opt.Meta;
end

%% --- fitted parameters (branch on which fit type) ---
if isfield(fit, 'S')                       % accelBiasScaleModelFit output
    cal.type = 'static';
    cal.S = fit.S;
    if isfield(fit,'covS'), cal.covS = fit.covS; end
    if isfield(fit,'decomp'), cal.decomp = fit.decomp; end
    if isfield(fit,'modelSpec'), cal.modelSpec = fit.modelSpec; end
    if isfield(fit,'biasInfo')
        cal.provenance.biasFiltered = getfielddef(fit.biasInfo,'filtered',false);
        cal.provenance.knotSpacingWarning = getfielddef(fit.biasInfo,'knotSpacingWarning','');
    end
    if isfield(fit,'axis')
        for i = 1:numel(fit.axis)
            a = fit.axis(i);
            cal.perAxis(i).scaleCoef = getfielddef(a,'scaleCoef',[]);
            cal.perAxis(i).biasCoef = getfielddef(a,'biasCoef',[]);
            cal.perAxis(i).sigma = getfielddef(a,'sigma',[]);
            cal.perAxis(i).sigmaInflation = getfielddef(a,'sigmaInflation',[]);
            if isfield(a,'noiseModel') && ~isempty(a.noiseModel)
                cal.perAxis(i).noiseVerdict = a.noiseModel.verdict;
                cal.perAxis(i).nEffRatio = a.noiseModel.nEffRatio;
            end
            cal.perAxis(i).lambda = getfielddef(a,'lambda',[]);
        end
    end

elseif isfield(fit, 'scale') && isfield(fit, 'scaleSigma')   % time-varying
    cal.type = 'time-varying';
    cal.timeVarying.t = fit.t;
    cal.timeVarying.scale = fit.scale;
    cal.timeVarying.bias = fit.bias;
    cal.timeVarying.scaleSigma = fit.scaleSigma;
    cal.timeVarying.biasSigma = fit.biasSigma;
    cal.timeVarying.scaleMean = fit.scaleMean;
    cal.timeVarying.scaleDrift = fit.scaleDrift;
    cal.timeVarying.isDriftSignificant = fit.isDriftSignificant;
    cal.timeVarying.scaleDriftSNR = fit.scaleDriftSNR;
    if isfield(fit,'noiseModel') && ~isempty(fit.noiseModel)
        cal.timeVarying.noiseVerdict = fit.noiseModel.verdict;
    end

else
    warning('accelCalibrationIO:unknownFit', ...
        'Unrecognized fit struct; storing it verbatim under cal.raw.');
    cal.type = 'raw';
    cal.raw = fit;
end

%% --- write ---
switch lower(opt.Format)
    case 'mat'
        save(filename, 'cal', '-v7.3');
    case 'json'
        txt = jsonencode(cal);
        fid = fopen(filename, 'w');
        if fid < 0, error('accelCalibrationIO:openFail', 'Cannot open %s.', filename); end
        fwrite(fid, txt, 'char');
        fclose(fid);
    otherwise
        error('accelCalibrationIO:badFormat', 'Format must be ''mat'' or ''json''.');
end

end

% ===================================================================
function cal = loadCalibration(filename)
[~,~,ext] = fileparts(filename);
if strcmpi(ext, '.json')
    fid = fopen(filename, 'r');
    if fid < 0, error('accelCalibrationIO:openFail', 'Cannot open %s.', filename); end
    txt = fread(fid, inf, '*char')'; fclose(fid);
    cal = jsondecode(txt);
else
    S = load(filename, 'cal');
    cal = S.cal;
end
end

% -------------------------------------------------------------------
function v = toolboxVersion()
v = '2.2';
end

function v = getfielddef(s, f, dflt)
if isstruct(s) && isfield(s, f), v = s.(f); else, v = dflt; end
end
