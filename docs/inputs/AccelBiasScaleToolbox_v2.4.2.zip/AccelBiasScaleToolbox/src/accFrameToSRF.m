function varargout = accFrameToSRF(varargin)
%ACCFRAMETOSRF  The ACC -> SRF axis permutation used in GRACE Level-1B, and
%   a check for having forgotten it.
%
%   P = accFrameToSRF()                      % the 3x3 permutation matrix
%   vSRF = accFrameToSRF(vACC)               % rotate an Nx3 series
%   diag = accFrameToSRF('check', S)         % diagnose a fitted scale matrix
%
%   The ATBD (JPL D-27672, section 3, step 7) states that the accelerometer
%   frame is identical to the Science Reference Frame EXCEPT FOR THE AXIS
%   LABELS, and ACC_compress applies the relabelling
%
%       X_SRF = Z_ACC,     Y_SRF = X_ACC,     Z_SRF = Y_ACC
%
%   i.e. v_SRF = P * v_ACC with
%
%       P = [ 0 0 1
%             1 0 0
%             0 1 0 ]
%
%   P is a cyclic permutation: it is orthogonal with det(P) = +1, so it is
%   a PROPER ROTATION -- specifically a 120-degree rotation about the
%   (1,1,1) axis. That is the trap. A forgotten or doubly-applied
%   permutation does not look like garbage; it looks like a perfectly
%   well-formed rotation, and DECOMPOSESCALEMATRIX will faithfully report
%   it as a 120-degree "misalignment" while the scale factors come out
%   near unity. The fit will not complain. The residuals may even look
%   tolerable if the axes happen to be correlated.
%
%   ACC_1B is already in SRF -- the relabelling has been applied by the
%   Level-1 processor. This function exists so you can (a) apply it if you
%   are working from ACC_1A, and (b) CHECK that you have not applied it
%   twice, or omitted it, when a fitted scale matrix looks strange.
%
%   --- 'check' mode ---
%   d = accFrameToSRF('check', S) takes a fitted 3x3 scale matrix and
%   reports:
%     .angleDeg       the misalignment angle implied by S's rotation part
%     .isPermutation  true if S is close to a permutation of the identity
%     .nearestPerm    the closest permutation matrix, if so
%     .verdict        one of
%         'plausible'          rotation is a few mrad or less -- a real
%                              misalignment
%         'FRAME ERROR'        rotation is close to 120 degrees or another
%                              permutation -- an axis-labelling mistake,
%                              not a physical misalignment
%         'large-rotation'     rotation is large but not a permutation --
%                              investigate; the fit may be degenerate
%     .message        a human-readable explanation
%
%   A genuine accelerometer misalignment is of order milliradians. If
%   DECOMPOSESCALEMATRIX reports degrees, the problem is bookkeeping, not
%   physics -- and no amount of force-model work will fix it.
%
%   Example
%     fit = accelBiasScaleModelFit(...);
%     d = accFrameToSRF('check', fit.S);
%     if ~strcmp(d.verdict, 'plausible'), warning(d.message); end
%
%   Reference
%     S.-C. Wu, G. Kruizinga, W. Bertiger, "Algorithm Theoretical Basis
%     Document for GRACE Level-1B Data Processing V1.2", JPL D-27672, 2006,
%     section 3 (ACC_compress), step 7.
%
%   See also DECOMPOSESCALEMATRIX, CRNFILTER.

P = [0 0 1
     1 0 0
     0 1 0];

%% --- P = accFrameToSRF() ---
if nargin == 0
    varargout{1} = P;
    return;
end

%% --- check mode ---
if ischar(varargin{1}) || isstring(varargin{1})
    if ~strcmpi(varargin{1}, 'check')
        error('accFrameToSRF:badMode', 'Unknown mode "%s"; expected ''check''.', ...
            char(varargin{1}));
    end
    if nargin < 2
        error('accFrameToSRF:noMatrix', 'check mode requires a 3x3 scale matrix.');
    end
    varargout{1} = checkScaleMatrix(varargin{2}, P);
    return;
end

%% --- vSRF = accFrameToSRF(vACC) ---
v = varargin{1};
if size(v,2) ~= 3
    error('accFrameToSRF:badSize', 'Input must be Nx3 (got %dx%d).', size(v,1), size(v,2));
end
varargout{1} = v * P.';

end

% ===================================================================
function d = checkScaleMatrix(S, P)

d.S = S;

Sf = S;
Sf(~isfinite(Sf)) = 0;

dec = decomposeScaleMatrix(Sf);
R = dec.R;

% rotation angle from the trace: tr(R) = 1 + 2*cos(theta)
c = (trace(R) - 1)/2;
c = max(min(c, 1), -1);
theta = acos(c);
d.angleDeg = theta * 180/pi;
d.angleRad = theta;
d.R = R;
d.scales = dec.scales;

%% --- is S close to a permutation of the identity (up to scaling)? ---
perms3 = allPermutationMatrices();
best = inf; bestP = eye(3);
for k = 1:numel(perms3)
    Pk = perms3{k};
    % compare the rotation part only, so genuine scale factors do not matter
    e = norm(R - Pk, 'fro');
    if e < best
        best = e; bestP = Pk;
    end
end
d.nearestPerm = bestP;
d.permResidual = best;
d.isPermutation = (best < 0.25) && ~isequal(bestP, eye(3));

%% --- verdict ---
if d.isPermutation
    d.verdict = 'FRAME ERROR';
    if isequal(bestP, P) || isequal(bestP, P.')
        which = 'the ACC<->SRF axis relabelling (X_SRF=Z_ACC, Y_SRF=X_ACC, Z_SRF=Y_ACC)';
    else
        which = 'an axis permutation';
    end
    d.message = sprintf(['Fitted scale matrix has a rotation part of %.1f deg, ' ...
        'which matches %s to within %.3f. This is an axis-labelling error, ' ...
        'not a physical misalignment: a real ACC misalignment is of order ' ...
        'milliradians. Check whether the ACC->SRF permutation has been ' ...
        'omitted or applied twice. ACC_1B is ALREADY in SRF.'], ...
        d.angleDeg, which, best);

elseif d.angleDeg < 1.0
    d.verdict = 'plausible';
    d.message = sprintf(['Rotation part is %.4f deg (%.0f urad) -- consistent ' ...
        'with a genuine instrument/frame misalignment.'], ...
        d.angleDeg, d.angleRad*1e6);

else
    d.verdict = 'large-rotation';
    d.message = sprintf(['Rotation part is %.1f deg, far larger than any ' ...
        'plausible instrument misalignment (which is milliradians), but it ' ...
        'does not match a clean axis permutation (residual %.3f). The fit ' ...
        'may be degenerate -- check cond(S) = %.3g and whether the modelled ' ...
        'axes have enough independent variation over this arc.'], ...
        d.angleDeg, best, cond(Sf));
end

end

% -------------------------------------------------------------------
function L = allPermutationMatrices()
%ALLPERMUTATIONMATRICES  The 6 signed-free 3x3 permutation matrices.
idx = perms(1:3);
L = cell(size(idx,1), 1);
I = eye(3);
for k = 1:size(idx,1)
    L{k} = I(idx(k,:), :);
end
end
