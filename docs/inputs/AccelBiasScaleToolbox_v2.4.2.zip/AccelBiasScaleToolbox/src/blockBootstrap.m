function bs = blockBootstrap(X, y, varargin)
%BLOCKBOOTSTRAP  Moving-block bootstrap confidence intervals for linear
%   regression coefficients under autocorrelated residuals.
%
%   bs = blockBootstrap(X, y)
%   bs = blockBootstrap(X, y, 'Name', Value, ...)
%
%   The naive (iid) bootstrap resamples residuals one at a time, which
%   destroys their serial correlation and reproduces the same optimistic
%   error bars as naive OLS. The moving-block bootstrap resamples
%   CONTIGUOUS BLOCKS of residuals, preserving correlation up to the
%   block length, and so yields honest intervals.
%
%   The block length must exceed the residual correlation length. By
%   default it is derived from the fitted AR model as
%       blockLen = ceil(K * tau),   tau = -1/log(|rho1|),  K = 5,
%   i.e. several correlation times, clamped to [10, N/5].
%
%   NAME-VALUE
%     'NumBoot'   (500)   bootstrap replicates
%     'BlockLen'  ([])    force a block length (samples). Default: derived
%                         from the residual ACF as described above.
%     'Alpha'     (0.05)  => 95% percentile intervals
%     'Robust'    (false) robust inner fit (slow; usually unnecessary once
%                         gross outliers are screened)
%     'Seed'      ([])    rng seed for reproducibility
%
%   OUTPUT (struct)
%     .coef        px1 point estimate (fit on the original data)
%     .boot        NumBoot x p replicate coefficients
%     .sigma       px1 bootstrap standard deviation of each coefficient
%     .ci          p x 2 percentile confidence interval [lo, hi]
%     .blockLen    block length used
%     .sigmaNaive  px1 naive iid OLS sigmas, for comparison
%     .inflation   .sigma ./ .sigmaNaive. Values >> 1 mean the naive
%                  error bars were badly optimistic. In a reference
%                  AR(1) rho=0.95 experiment this was 5.5-6.5x.
%
%   Residuals are resampled around the ORIGINAL fitted values (a
%   fixed-design / model-based bootstrap), which is the right choice when
%   the regressors are deterministic model outputs rather than a random
%   sample.
%
%   See also GLSLINEARFIT, ESTIMATENOISEMODEL, BLOCKEDCROSSVAL.

ip = inputParser;
ip.addParameter('NumBoot', 500, @isnumeric);
ip.addParameter('BlockLen', [], @(x) isempty(x) || isnumeric(x));
ip.addParameter('Alpha', 0.05, @isnumeric);
ip.addParameter('Robust', false, @islogical);
ip.addParameter('Seed', [], @(x) isempty(x) || isnumeric(x));
ip.parse(varargin{:});
opt = ip.Results;

if ~isempty(opt.Seed)
    rng(opt.Seed);
end

y = y(:);
n = numel(y);
p = size(X,2);

%% --- point estimate on the original data ---
if opt.Robust
    coef0 = robustLinearFit(X, y);
else
    coef0 = X \ y;
end
fitted = X*coef0;
resid = y - fitted;

%% --- naive iid sigmas for the inflation diagnostic ---
s2 = (resid'*resid) / max(n - p, 1);
covNaive = s2 * pinv(X'*X);
sigmaNaive = sqrt(max(diag(covNaive), 0));

%% --- block length from the residual correlation time ---
blockLen = opt.BlockLen;
if isempty(blockLen)
    nm = estimateNoiseModel(resid);
    rho1 = abs(nm.acf1);
    if ~isfinite(rho1) || rho1 <= 0 || rho1 >= 1
        tau = 1;
    else
        tau = -1/log(rho1);
    end
    blockLen = ceil(5 * tau);
end
blockLen = max(10, min(blockLen, max(10, floor(n/5))));
blockLen = min(blockLen, n);

%% --- moving-block resampling ---
nBlocks = ceil(n / blockLen);
maxStart = n - blockLen + 1;
boot = nan(opt.NumBoot, p);

for b = 1:opt.NumBoot
    starts = randi(maxStart, nBlocks, 1);
    idx = zeros(nBlocks*blockLen, 1);
    for k = 1:nBlocks
        idx((k-1)*blockLen + (1:blockLen)) = starts(k) + (0:blockLen-1);
    end
    idx = idx(1:n);

    yb = fitted + resid(idx);
    if opt.Robust
        boot(b,:) = robustLinearFit(X, yb)';
    else
        boot(b,:) = (X \ yb)';
    end
end

%% --- summaries ---
sigma = std(boot, 0, 1)';
lo = quantile(boot, opt.Alpha/2, 1)';
hi = quantile(boot, 1 - opt.Alpha/2, 1)';

bs.coef = coef0;
bs.boot = boot;
bs.sigma = sigma;
bs.ci = [lo, hi];
bs.blockLen = blockLen;
bs.numBoot = opt.NumBoot;
bs.sigmaNaive = sigmaNaive;
bs.inflation = sigma ./ max(sigmaNaive, realmin);

end
