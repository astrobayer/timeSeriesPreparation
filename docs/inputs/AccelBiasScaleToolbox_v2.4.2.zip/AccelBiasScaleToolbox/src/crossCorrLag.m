function [lagEst, corrMax, tu, u1, u2] = crossCorrLag(tA, y1A, y2A, maxLagFrac)
%CROSSCORRLAG  Estimate a constant timing offset between two aligned
%   series via cross-correlation on a uniformly resampled common grid.
%
%   [lagEst, corrMax] = crossCorrLag(tA, y1A, y2A, maxLagFrac)
%
%   INPUT
%     tA, y1A, y2A : Nx1 already-aligned time/value vectors (e.g. from
%                    ALIGNACCELSERIES)
%     maxLagFrac   : max lag searched, as a fraction of the number of
%                    uniform-grid samples (e.g. 0.02 => search up to 2%
%                    of the span in either direction)
%
%   OUTPUT
%     lagEst   : estimated lag (same time unit as tA) at peak correlation.
%                Positive lagEst means y2A lags y1A.
%     corrMax  : normalized cross-correlation value at that lag (0..1
%                scale is not guaranteed since 'coeff' normalizes by the
%                zero-lag autocorrelations; interpret as relative
%                confidence, not a strict correlation coefficient)
%     tu, u1, u2 : the uniform-grid resampled (mean-removed) series used
%                internally, returned for inspection/plotting
%
%   Requires at least 10 aligned samples; returns NaN outputs otherwise.
%
%   See also XCORR, ALIGNACCELSERIES.

tA = tA(:); y1A = y1A(:); y2A = y2A(:);

if numel(tA) <= 10
    lagEst = NaN; corrMax = NaN; tu = []; u1 = []; u2 = [];
    return;
end

dtUniform = median(diff(tA));
tu = (tA(1):dtUniform:tA(end))';
u1 = interp1(tA, y1A, tu, 'linear', 'extrap');
u2 = interp1(tA, y2A, tu, 'linear', 'extrap');
u1 = u1 - mean(u1);
u2 = u2 - mean(u2);

maxLagSamples = max(1, round(maxLagFrac * numel(tu)));
[c, lags] = xcorr(u1, u2, maxLagSamples, 'coeff');
[corrMax, iMax] = max(c);
lagEst = lags(iMax) * dtUniform;

end
