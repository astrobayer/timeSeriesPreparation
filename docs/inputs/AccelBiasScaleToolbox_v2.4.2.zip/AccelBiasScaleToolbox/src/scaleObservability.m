function obs = scaleObservability(yMod, varargin)
%SCALEOBSERVABILITY  Decide whether a scale factor is DETERMINABLE from a
%   given window of data, before believing any number fitted from it.
%
%   obs = scaleObservability(yMod)
%   obs = scaleObservability(yMod, 'Demean', true, 'BiasDesign', B)
%
%   *** THIS IS USUALLY THE EXPLANATION FOR "WILD" SCALE ESTIMATES. ***
%
%   In the model  y_obs = bias + scale * y_mod, the scale factor is only
%   observable to the extent that y_mod actually VARIES. In a quiet
%   window -- low drag, no eclipse crossing, small dynamic range -- y_mod
%   is nearly constant, and then
%       bias + scale * const
%   is a single number two ways: bias and scale become collinear and
%   individually unidentifiable. The least-squares solution still returns
%   values, but they are an arbitrary point along a nearly flat valley:
%   scale swings wildly while bias absorbs the compensating change, and
%   the two are near-perfectly anticorrelated.
%
%   That is exactly the signature of "bias is stable, scale varies a lot",
%   and it is an ESTIMATION artifact, not physics. Constraining scale to
%   sit near 1 (a common workaround) hides the symptom without fixing the
%   cause and biases the windows where scale IS observable.
%
%   Two fixes, both supported here:
%     1. DEMEAN the regressor within each window. With a nonzero-mean
%        drag signal, the bias and scale columns of the design matrix are
%        strongly correlated by construction. Centering y_mod makes them
%        orthogonal, which decorrelates the estimates without changing
%        the fitted curve. Always do this.
%     2. REPORT rather than estimate. Where the diagnostics below say the
%        scale is not determinable, return NaN instead of a number.
%
%   INPUT
%     yMod : Nx1 modeled series for the window
%
%   NAME-VALUE
%     'Demean'     (true)  assess the design matrix with y_mod centered
%     'BiasDesign' ([])    the bias block of the design matrix. Default
%                          ones(N,1) (constant bias). Pass the actual
%                          spline/polynomial block to assess the real
%                          design.
%     'MinRelRange'(0.05)  dynamic-range threshold: std(yMod)/|mean(yMod)|
%     'MaxCond'    (100)   condition-number threshold
%     'MaxCorr'    (0.95)  |bias-scale correlation| threshold
%
%   OUTPUT (struct)
%     .std, .meanAbs, .relRange   dynamic range of the regressor
%     .cond          condition number of [BiasDesign, yMod]. Large =>
%                    the scale column is nearly in the span of the bias
%                    block, i.e. not independently identifiable.
%     .biasScaleCorr correlation between the bias and scale estimates,
%                    from the normal-matrix inverse. |corr| -> 1 means
%                    the two parameters trade off against each other
%                    almost exactly.
%     .scaleVarFactor  the (X'X)^-1 diagonal entry for the scale column,
%                    i.e. how much the scale variance is amplified
%                    relative to a perfectly conditioned design.
%     .observable    logical -- all thresholds passed
%     .reason        why not, if not observable
%
%   Example
%     obs = scaleObservability(y2win);
%     if ~obs.observable
%         scaleEstimate(w) = NaN;   % refuse to report an unidentifiable number
%     end
%
%   See also SLIDINGWINDOWFIT, ACCELSERIESPREFLIGHT.

ip = inputParser;
ip.addParameter('Demean', true, @islogical);
ip.addParameter('BiasDesign', [], @(x) isempty(x) || ismatrix(x));
ip.addParameter('MinRelRange', 0.05, @isnumeric);
ip.addParameter('MaxCond', 100, @isnumeric);
ip.addParameter('MaxCorr', 0.95, @isnumeric);
ip.parse(varargin{:});
opt = ip.Results;

yMod = yMod(:);
n = numel(yMod);

obs.std = std(yMod);
obs.meanAbs = abs(mean(yMod));
if obs.meanAbs > eps
    obs.relRange = obs.std / obs.meanAbs;
else
    obs.relRange = Inf;   % zero-mean regressor: scale is well posed
end

B = opt.BiasDesign;
if isempty(B)
    B = ones(n,1);
end

s = yMod;
if opt.Demean
    s = s - mean(s);
end

X = [B, s];
obs.cond = cond(X);

XtX = X'*X;
if rcond(XtX) < eps
    Ci = pinv(XtX);
else
    Ci = inv(XtX);
end

iScale = size(X,2);
obs.scaleVarFactor = Ci(iScale, iScale);

% correlation between the scale estimate and the LAST bias parameter
% (for a constant bias this is the bias itself)
if size(B,2) >= 1
    iBias = size(B,2);
    denom = sqrt(Ci(iBias,iBias) * Ci(iScale,iScale));
    if denom > eps
        obs.biasScaleCorr = Ci(iBias, iScale) / denom;
    else
        obs.biasScaleCorr = NaN;
    end
else
    obs.biasScaleCorr = NaN;
end

%% --- verdict ---
obs.observable = true;
obs.reason = '';

if obs.std <= eps
    obs.observable = false;
    obs.reason = 'Modeled signal is constant: scale is entirely unidentifiable.';
elseif obs.relRange < opt.MinRelRange
    obs.observable = false;
    obs.reason = sprintf(['Low dynamic range (std/|mean| = %.3g < %.3g): ' ...
        'scale is weakly identifiable and will swing wildly.'], ...
        obs.relRange, opt.MinRelRange);
elseif obs.cond > opt.MaxCond
    obs.observable = false;
    obs.reason = sprintf(['Design matrix ill-conditioned (cond = %.3g > %.3g): ' ...
        'the scale column is nearly spanned by the bias block.'], ...
        obs.cond, opt.MaxCond);
elseif isfinite(obs.biasScaleCorr) && abs(obs.biasScaleCorr) > opt.MaxCorr
    obs.observable = false;
    obs.reason = sprintf(['Bias and scale are near-collinear (corr = %.3f): ' ...
        'they trade off and cannot be separated in this window.'], ...
        obs.biasScaleCorr);
end

end
