function plotBiasScaleModelCompare(comparison)
%PLOTBIASSCALEMODELCOMPARE  Figures for ACCELBIASSCALEMODELCOMPARE.
%
%   Shows the blocked-CV ranking (the criterion that should decide the
%   model), the sigma-inflation factor per model (how optimistic naive
%   error bars would have been), the fitted bias curves, and -- for the
%   best model -- the physical decomposition of the scale matrix.
%
%   See also ACCELBIASSCALEMODELCOMPARE, DECOMPOSESCALEMATRIX.

T = comparison.table;
nModels = numel(comparison.fits);
M = size(comparison.Y1A, 2);

%% --- ranking ---
figure('Name','Model comparison');
subplot(3,1,1);
bar(categorical(T.Model, T.Model), T.CV_RSS);
ylabel('Blocked-CV RSS');
title('Model ranking by BLOCKED cross-validation (lower is better) -- the criterion to trust');
grid on;

subplot(3,1,2);
bar(categorical(T.Model, T.Model), T.MeanR2);
ylabel('Mean in-sample R^2');
title('In-sample R^2 -- always improves with complexity; do NOT select on this');
grid on;

subplot(3,1,3);
bar(categorical(T.Model, T.Model), T.MeanSigmaInflation);
yline(1, '--k');
ylabel('sigma inflation');
title('GLS sigma / naive-iid sigma. >>1 means naive error bars were badly optimistic');
grid on;

%% --- fitted bias curves ---
for i = 1:M
    figure('Name', sprintf('Fitted bias(t) -- axis %d', i));
    hold on;
    for m = 1:nModels
        plot(comparison.tA, comparison.fits{m}.axis(i).biasFitted, ...
            'DisplayName', comparison.labels{m});
    end
    hold off;
    xlabel('Time'); ylabel('fitted bias');
    title(sprintf('Axis %d: fitted bias(t) by model', i));
    legend('show','Location','best'); grid on;
end

%% --- physical decomposition of the best model's scale matrix ---
bestLabel = T.Model{1};
iBest = find(strcmp(comparison.labels, bestLabel), 1);
d = comparison.fits{iBest}.decomp;

if ~isempty(d)
    figure('Name','Scale matrix decomposition (best model)');

    subplot(1,3,1);
    bar(d.anglesUrad);
    set(gca,'XTickLabel',{'about x','about y','about z'});
    ylabel('\murad');
    title('Misalignment (rotation part R)');
    grid on;

    subplot(1,3,2);
    bar(d.scales);
    yline(1,'--k');
    set(gca,'XTickLabel',{'axis 1','axis 2','axis 3'});
    ylabel('scale');
    title('Scale factors (diag U)');
    grid on;

    subplot(1,3,3);
    bar(d.nonOrtho);
    set(gca,'XTickLabel',{'U_{12}','U_{13}','U_{23}'});
    ylabel('non-orthogonality');
    title('Non-orthogonality (offdiag U)');
    grid on;

    sgtitle(sprintf(['Best model: %s.  cond(S) = %.3g %s'], bestLabel, d.condS, ...
        ternary(d.condS > 100, ' -- LARGE: off-diagonal terms are poorly determined', '')));
end

%% --- console summary ---
fprintf('\n============ Model comparison (ranked by blocked CV) ============\n');
disp(T);
if any(T.IC_unreliable)
    fprintf(['NOTE: residuals are autocorrelated for at least one model, so the\n' ...
             '      AIC_ref / BIC_ref columns are NOT valid selection criteria.\n' ...
             '      Rank by CV_RSS.\n']);
end
if ~isempty(d)
    fprintf('\nBest model scale decomposition:\n');
    fprintf('  misalignment [urad] : %8.1f %8.1f %8.1f\n', d.anglesUrad);
    fprintf('  scale factors        : %8.4f %8.4f %8.4f\n', d.scales);
    fprintf('  non-orthogonality    : %8.5f %8.5f %8.5f\n', d.nonOrtho);
    fprintf('  cond(S) = %.3g, proper rotation = %d\n', d.condS, d.isProper);
end
fprintf('================================================================\n');

end

function out = ternary(c, a, b)
if c, out = a; else, out = b; end
end
