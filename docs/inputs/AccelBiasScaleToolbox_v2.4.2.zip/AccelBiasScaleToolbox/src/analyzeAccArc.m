function out = analyzeAccArc(tObs, Yobs, tMod, Ymod, varargin)
%ANALYZEACCARC  One-call analysis of an observed vs. modeled acceleration
%   arc: preflight -> filter-consistency -> model selection -> fit ->
%   physical decomposition -> report. The recommended entry point.
%
%   out = analyzeAccArc(tObs, Yobs, tMod, Ymod)
%   out = analyzeAccArc(..., 'Name', Value, ...)
%
%   This exists because getting the SEQUENCE and the OPTIONS right by hand
%   is error-prone, and the errors are expensive: using the wrong filter
%   normalization is a ~450 ppm scale error, forgetting filter consistency
%   is several percent, and fitting an unobservable scale produces
%   confident nonsense. This wrapper applies the defaults this toolbox's
%   analysis established, in the right order, and surfaces every caveat.
%
%   It does NOT hide the steps -- each intermediate result is returned, and
%   you can (and for anything publishable, should) inspect them. It is a
%   safe default path, not a black box.
%
%   PIPELINE
%     1. accelSeriesPreflight  -- data quality, observability, timing,
%                                 noise character. Read out.flags.
%     2. crnFilter + filterConsistency -- put the model into ACC_1B's band
%                                 using the EXACT ATBD kernel.
%     3. flagEdgeEffects        -- down-weight CRN-contaminated segment ends
%     4. accelBiasScaleModelCompare -- rank bias/scale models by blocked CV
%     5. accelBiasScaleModelFit -- fit the winner, with GLS + bootstrap,
%                                 the bias basis filtered to match
%     6. accFrameToSRF('check') -- catch an axis-permutation frame error
%     7. (optional) accelTimeVaryingScaleFit per axis, if requested or if
%                                 the static residuals suggest scale drift
%
%   NAME-VALUE
%     'Product'        ('ACC')   CRN preset
%     'FilterStrategy' ('explicit')  'explicit' uses the exact ATBD kernel;
%                                 'commonmode' if unsure of the operational
%                                 filter; 'none' to skip (not recommended)
%     'ScaleModel'     ('full')  'diagonal' | 'full' | mask
%     'BiasCandidates' ({})      cell of BiasModel structs for the model
%                                 comparison; a sensible default set is used
%                                 if empty
%     'TimeVaryingScale' ('auto')  'auto' (fit it only if the static
%                                 residuals look like drift), 'always',
%                                 or 'never'
%     'EdgeMode'       ('zero')  passed to flagEdgeEffects
%     'Bootstrap'      (true)    block-bootstrap CIs on the final fit
%     'Save'           ('')      if non-empty, save the calibration there
%     'Verbose'        (true)    print a readable summary
%
%   OUTPUT (struct)
%     .preflight     accelSeriesPreflight report
%     .comparison    accelBiasScaleModelCompare result
%     .fit           the chosen accelBiasScaleModelFit
%     .decomp        polar decomposition of the fitted S
%     .frameCheck    accFrameToSRF('check', S) per-... verdict
%     .timeVarying   per-axis accelTimeVaryingScaleFit (if run)
%     .edgeInfo      flagEdgeEffects info
%     .flags         consolidated, de-duplicated caveat list
%     .summary       one-line-per-axis text summary
%
%   Example
%     out = analyzeAccArc(tAcc, Yacc, tMod, Ymod, 'Save', 'arc001.mat');
%     disp(out.summary);
%
%   See also ACCELSERIESPREFLIGHT, FILTERCONSISTENCY, CRNFILTER,
%            ACCELBIASSCALEMODELCOMPARE, ACCELBIASSCALEMODELFIT,
%            ACCELTIMEVARYINGSCALEFIT, FLAGEDGEEFFECTS, ACCFRAMETOSRF,
%            ACCELCALIBRATIONIO.

ip = inputParser;
ip.addParameter('Product', 'ACC', @ischar);
ip.addParameter('FilterStrategy', 'explicit', @ischar);
ip.addParameter('ScaleModel', 'full');
ip.addParameter('BiasCandidates', {}, @iscell);
ip.addParameter('TimeVaryingScale', 'auto', @ischar);
ip.addParameter('EdgeMode', 'zero', @ischar);
ip.addParameter('Bootstrap', true, @islogical);
ip.addParameter('Save', '', @ischar);
ip.addParameter('Verbose', true, @islogical);
ip.parse(varargin{:});
opt = ip.Results;

if isvector(Yobs), Yobs = Yobs(:); end
if isvector(Ymod), Ymod = Ymod(:); end
M = size(Yobs,2);
allFlags = {};

%% --- build the exact CRN kernel once ---
[h, hInfo] = crnFilter(opt.Product);

%% --- 1. preflight ---
out.preflight = accelSeriesPreflight(tObs, Yobs, tMod, Ymod, ...
    'FilterStrategy', opt.FilterStrategy, 'FilterCoef', h, ...
    'PlotDiagnostics', false, 'Spectral', false);
for k = 1:numel(out.preflight.axis)
    allFlags = [allFlags, out.preflight.axis(k).flags]; %#ok<AGROW>
end

%% --- default bias candidates ---
cands = opt.BiasCandidates;
if isempty(cands)
    cands = {
        struct('label','const',  'ScaleModel',opt.ScaleModel, 'BiasModel',struct('type','constant'))
        struct('label','poly3',  'ScaleModel',opt.ScaleModel, 'BiasModel',struct('type','polynomial','order',3))
        struct('label','pspline','ScaleModel',opt.ScaleModel, 'BiasModel',struct('type','pspline','numInteriorKnots',30,'placement','quantile'))
    };
    cands = cands(:)';
end

%% --- 2+4. model comparison (aligns + filters internally) ---
out.comparison = accelBiasScaleModelCompare(tObs, Yobs, tMod, Ymod, cands, ...
    'FilterStrategy', opt.FilterStrategy, 'FilterCoef', h, ...
    'PlotDiagnostics', false);

bestLabel = out.comparison.table.Model{1};
iBest = find(strcmp(out.comparison.labels, bestLabel), 1);
bestSpec = cands{iBest};

%% --- 3. edge weights on the aligned grid ---
tA = out.comparison.tA;
[wEdge, out.edgeInfo] = flagEdgeEffects(tA, h, 'Mode', opt.EdgeMode);
if out.edgeInfo.contaminatedFraction > 0.02
    allFlags{end+1} = sprintf(['%.1f%% of aligned samples are within a CRN ' ...
        'half-span (%.0f s) of a segment boundary and were down-weighted; ' ...
        'edge output is reflection-approximated, not real.'], ...
        100*out.edgeInfo.contaminatedFraction, out.edgeInfo.halfSpanSeconds);
end

%% --- 5. final fit of the winner, bias basis filtered to match ---
out.fit = accelBiasScaleModelFit(tA, out.comparison.Y1A, out.comparison.Y2A, ...
    bestSpec, 'Robust', true, 'NoiseModel', true, ...
    'BiasFilter', h, 'Bootstrap', opt.Bootstrap);

%% --- 6. decomposition + frame check ---
out.decomp = out.fit.decomp;
if M == 3
    out.frameCheck = accFrameToSRF('check', out.fit.S);
    if ~strcmp(out.frameCheck.verdict, 'plausible')
        allFlags{end+1} = out.frameCheck.message;
    end
else
    out.frameCheck = [];
end

%% --- 7. time-varying scale, if warranted ---
out.timeVarying = [];
doTV = false;
switch lower(opt.TimeVaryingScale)
    case 'always', doTV = true;
    case 'never',  doTV = false;
    case 'auto'
        % run it if any axis' static residual looks like drift: strong
        % low-frequency autocorrelation not explained as measurement noise
        for k = 1:M
            nm = out.fit.axis(k).noiseModel;
            if ~isempty(nm) && nm.nEffRatio < 0.2
                doTV = true; break;
            end
        end
    otherwise
        error('analyzeAccArc:badTVS', 'TimeVaryingScale must be auto|always|never.');
end

if doTV
    for k = 1:M
        tv = accelTimeVaryingScaleFit(tA, out.comparison.Y1A(:,k), ...
            out.comparison.Y2A(:,k), 'Weights', wEdge, ...
            'Robust', true, 'NoiseModel', true);
        out.timeVarying(k).fit = tv; %#ok<AGROW>
        if tv.isDriftSignificant
            allFlags{end+1} = sprintf(['Axis %d: scale drift (%.4f, SNR %.1f) is ' ...
                'resolved above its uncertainty -- a STATIC scale is inadequate ' ...
                'for this axis; use s(t). This is a likely source of an apparent ' ...
                '"wildly varying" scale.'], k, tv.scaleDrift, tv.scaleDriftSNR); %#ok<AGROW>
        end
    end
end

%% --- consolidate ---
out.flags = unique(allFlags, 'stable');

%% --- summary ---
lines = {};
for k = 1:M
    s = out.fit.S(k,k);
    infl = mean(out.fit.axis(k).sigmaInflation);
    nmv = ''; if ~isempty(out.fit.axis(k).noiseModel), nmv = out.fit.axis(k).noiseModel.verdict; end
    lines{end+1} = sprintf('axis %d: scale %.5f  (sigma x%.1f, noise %s)', k, s, infl, nmv); %#ok<AGROW>
end
if M == 3 && ~isempty(out.decomp)
    lines{end+1} = sprintf('misalignment [urad]: %.0f %.0f %.0f', out.decomp.anglesUrad);
    lines{end+1} = sprintf('scales: %.5f %.5f %.5f', out.decomp.scales);
end
out.summary = strjoin(lines, newline);

%% --- save ---
if ~isempty(opt.Save)
    accelCalibrationIO('save', opt.Save, out.fit, ...
        'Meta', struct('bestModel', bestLabel, ...
                       'filterProduct', hInfo.product, ...
                       'filterDCGain', hInfo.dcGain, ...
                       'filterStrategy', opt.FilterStrategy));
end

%% --- report ---
if opt.Verbose
    fprintf('\n===== analyzeAccArc: %s =====\n', bestLabel);
    fprintf('%s\n', out.summary);
    if isempty(out.flags)
        fprintf('No caveats.\n');
    else
        fprintf('\nCaveats (%d):\n', numel(out.flags));
        for f = 1:numel(out.flags)
            fprintf('  [!] %s\n', out.flags{f});
        end
    end
    fprintf('=============================\n');
end

end
