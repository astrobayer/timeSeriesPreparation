function [w, info] = flagEdgeEffects(t, h, varargin)
%FLAGEDGEEFFECTS  Identify and down-weight samples corrupted by the CRN
%   filter's edge/transient response at the ends of every continuous
%   data segment.
%
%   [w, info] = flagEdgeEffects(t, h)
%   [w, info] = flagEdgeEffects(t, h, 'Name', Value, ...)
%
%   The CRN kernel spans Nf samples (1407 for ACC = 140.7 s). Within a
%   kernel half-span (Nh = 703 samples ~ 70 s) of the start or end of any
%   continuous data segment, the filtered value is computed partly from
%   samples that do not exist -- reflection padding merely APPROXIMATES
%   them. Those outputs are not trustworthy: they are neither the L1
%   product (which had real neighbours) nor cleanly missing. Left in the
%   fit at full weight, they pull the bias and scale.
%
%   Every gap creates two such contaminated regions (the end of the
%   preceding segment and the start of the following one), so a day with
%   many gaps can carry a large contaminated fraction: with 20 gaps, about
%   50 minutes -- ~3.5% of a day.
%
%   This function finds the segment boundaries (from time discontinuities)
%   and returns a weight vector that is 0 (or a taper) inside the
%   contaminated half-span and 1 elsewhere. Feed it to the fit.
%
%   INPUT
%     t : Nx1 epochs of the series to be fitted (post-alignment)
%     h : the CRN kernel used (from CRNFILTER). Only its length matters.
%
%   NAME-VALUE
%     'GapFactor' (5)      a step > GapFactor*median(dt) starts a new
%                          segment (matches QUALITYCHECK's gap definition)
%     'Mode'      ('zero') 'zero'  -> weight 0 in the contaminated half-span
%                          'taper' -> raised-cosine ramp from 0 at the
%                                     boundary to 1 at the half-span edge,
%                                     a softer transition
%     'HalfSpan'  ([])     override the contaminated half-span, in SAMPLES.
%                          Default (numel(h)-1)/2.
%
%   OUTPUT
%     w    : Nx1 weights in [0,1]
%     info : .nSegments, .nContaminated, .contaminatedFraction,
%            .halfSpanSamples, .halfSpanSeconds, .segmentEdges
%
%   Example
%     h = crnFilter('ACC');
%     w = flagEdgeEffects(tA, h);
%     fit = accelTimeVaryingScaleFit(tA, y1A, y2A, 'Weights', w);
%
%   See also CRNFILTER, APPLYCRNFILTER, ACCELTIMEVARYINGSCALEFIT,
%            ACCELBIASSCALEMODELFIT.

ip = inputParser;
ip.addParameter('GapFactor', 5, @isnumeric);
ip.addParameter('Mode', 'zero', @ischar);
ip.addParameter('HalfSpan', [], @(x) isempty(x) || isnumeric(x));
ip.parse(varargin{:});
opt = ip.Results;

t = t(:);
n = numel(t);

Nh = opt.HalfSpan;
if isempty(Nh)
    Nh = (numel(h) - 1)/2;
end
Nh = round(Nh);

%% --- find continuous-segment boundaries from time gaps ---
dt = diff(t);
dtMed = median(dt(dt > 0));
isBreak = dt > opt.GapFactor * dtMed;      % index i: gap between i and i+1
segStart = [1; find(isBreak) + 1];
segEnd   = [find(isBreak); n];
nSeg = numel(segStart);

%% --- build weights ---
w = ones(n, 1);
for s = 1:nSeg
    i0 = segStart(s);
    i1 = segEnd(s);

    % contaminated indices: first Nh and last Nh of the segment
    loEnd = min(i0 + Nh - 1, i1);
    hiStart = max(i1 - Nh + 1, i0);

    switch lower(opt.Mode)
        case 'zero'
            w(i0:loEnd) = 0;
            w(hiStart:i1) = 0;
        case 'taper'
            % rising ramp at segment start
            k = (i0:loEnd);
            frac = (k - i0) / max(loEnd - i0, 1);      % 0 at boundary -> 1
            w(k) = min(w(k).', 0.5*(1 - cos(pi*frac))).';
            % falling ramp at segment end
            k = (hiStart:i1);
            frac = (i1 - k) / max(i1 - hiStart, 1);    % 0 at boundary -> 1
            w(k) = min(w(k).', 0.5*(1 - cos(pi*frac))).';
        otherwise
            error('flagEdgeEffects:badMode', 'Mode must be ''zero'' or ''taper''.');
    end
end

info.nSegments = nSeg;
info.nContaminated = nnz(w < 1);
info.contaminatedFraction = nnz(w < 1) / n;
info.halfSpanSamples = Nh;
info.halfSpanSeconds = Nh * dtMed;
info.segmentEdges = [segStart, segEnd];

end
