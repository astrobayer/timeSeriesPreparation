function [coef, w, iter] = robustLinearFit(X, y, varargin)
%ROBUSTLINEARFIT  IRLS bisquare-weighted linear regression, y = X*coef,
%   with an optional quadratic penalty.
%
%   [coef, w, iter] = robustLinearFit(X, y)
%   [coef, w, iter] = robustLinearFit(X, y, 'Name', Value, ...)
%
%   Unlike ROBUSTFIT, this does NOT prepend its own intercept column, so
%   it composes with arbitrary design matrices (spline bias blocks,
%   multi-axis scale blocks). Supply every column explicitly.
%
%   NAME-VALUE
%     'MaxIter' (50)     IRLS iterations
%     'Tune'    (4.685)  bisquare tuning constant (95% Gaussian efficiency)
%     'Tol'     (1e-6)   relative coefficient convergence tolerance
%     'Penalty' ([])     p x p penalty matrix, added as lambda*P to the
%                        weighted normal equations each iteration
%     'Lambda'  (0)      penalty weight
%
%   OUTPUT
%     coef : px1 coefficients
%     w    : Nx1 final bisquare weights (0 => fully rejected observation)
%     iter : iterations actually performed
%
%   The scale estimate is a normal-consistent MAD of the current
%   residuals, recomputed each iteration.
%
%   Example
%     coef = robustLinearFit([B, y2], y1, 'Lambda', 10, 'Penalty', P);
%
%   See also GLSLINEARFIT, DIFFPENALTYMATRIX.

ip = inputParser;
ip.addParameter('MaxIter', 50, @isnumeric);
ip.addParameter('Tune', 4.685, @isnumeric);
ip.addParameter('Tol', 1e-6, @isnumeric);
ip.addParameter('Penalty', [], @(x) isempty(x) || ismatrix(x));
ip.addParameter('Lambda', 0, @isnumeric);
ip.parse(varargin{:});
opt = ip.Results;

y = y(:);
n = size(X,1);
p = size(X,2);

P = opt.Penalty;
if isempty(P), P = zeros(p); end
lam = opt.Lambda;

coef = solveWeighted(X, y, ones(n,1), P, lam);
w = ones(n,1);

for iter = 1:opt.MaxIter
    r = y - X*coef;
    s = madSigma(r);
    if s < eps
        break;
    end
    u = r / (opt.Tune * s);
    wNew = (1 - u.^2).^2;
    wNew(abs(u) >= 1) = 0;

    coefNew = solveWeighted(X, y, wNew, P, lam);

    if norm(coefNew - coef) / max(norm(coef), eps) < opt.Tol
        coef = coefNew; w = wNew;
        break;
    end
    coef = coefNew; w = wNew;
end

end

% -------------------------------------------------------------------
function coef = solveWeighted(X, y, w, P, lam)
sw = sqrt(w);
Xw = sw .* X;
yw = sw .* y;
if lam == 0
    coef = Xw \ yw;
else
    A = Xw'*Xw + lam*P;
    coef = A \ (Xw'*yw);
end
end

% -------------------------------------------------------------------
function s = madSigma(r)
m = median(r);
s = median(abs(r - m)) * 1.4826;
end
