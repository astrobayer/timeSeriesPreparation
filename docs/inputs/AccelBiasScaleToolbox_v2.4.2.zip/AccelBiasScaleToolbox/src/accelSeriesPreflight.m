function report = accelSeriesPreflight(t1, y1, t2, y2, varargin)
%ACCELSERIESPREFLIGHT  Preprocessing diagnostics for an observed vs.
%   modeled acceleration pair, run BEFORE any full adjustment.
%
%   report = accelSeriesPreflight(t1, y1, t2, y2)
%   report = accelSeriesPreflight(..., 'Name', Value, ...)
%
%   Answers, cheaply: is the disagreement between these two series
%   actually physics, or is it an artifact of data quality, timing,
%   spectral mismatch, or an ill-posed estimation problem? Every flag it
%   raises corresponds to something that would otherwise be silently
%   absorbed into the fitted bias/scale parameters.
%
%   CHECKS PERFORMED (per axis)
%     1. Data quality of each raw series (QUALITYCHECK): gaps, duplicate
%        or non-monotonic timestamps, MAD outliers.
%     2. Alignment (ALIGNACCELSERIES) with a gap-aware screen, using
%        amplitude-preserving interpolation.
%     3. Timing offset (CROSSCORRLAG) -- a clock error masquerades as bias.
%     4. Filter consistency (FILTERCONSISTENCY) -- ACC1B is low-pass
%        filtered, a pointwise force model is not. Left uncorrected, the
%        model's excess high-frequency power is partially absorbed by the
%        SCALE parameter.
%     5. SCALE OBSERVABILITY (SCALEOBSERVABILITY) -- the single most
%        common explanation for "bias stable, scale wild". In low-dynamic-
%        range windows, bias and scale are collinear and scale is simply
%        not identifiable. Windows where it is not are reported, not
%        estimated.
%     6. Windowed bias/scale preview (SLIDINGWINDOWFIT), demeaned and
%        observability-gated.
%     7. Residual noise model (ESTIMATENOISEMODEL) -- reports the
%        effective sample size. If nEffRatio << 1, every formal sigma and
%        every AIC/BIC in a downstream fit is optimistic.
%     8. Heteroscedasticity (HETEROSCEDASTICITYCHECK) -- multiplicative
%        (=> let scale vary) vs additive (=> bias) error.
%     9. Spectral comparison, via LOMBSCARGLEPSD on the raw uneven epochs
%        (no gap interpolation, hence no fabricated data in the spectrum).
%
%   NAME-VALUE
%     'MaxGapFactor'    (5)
%     'InterpMethod'    ('pchip')   amplitude-preserving; 'linear'
%                                   attenuates and biases scale low
%     'MaxInterpGap'    ([])        default 3*median(dt1)
%     'FilterStrategy'  ('none')    'none' | 'commonmode' | 'explicit' |
%                                   'empirical'. Use 'commonmode' if you
%                                   do not have the true ACC1B filter.
%     'FilterCutoff'    (0.035)
%     'FilterCoef'      ([])
%     'WindowLength'    ([])        default span/50
%     'WindowOverlap'   (0.5)
%     'Robust'          (true)
%     'MaxLagFrac'      (0.02)
%     'Spectral'        (true)      compute Lomb-Scargle spectra (slow on
%                                   long arcs; set false to skip)
%     'PlotDiagnostics' (true)
%
%   OUTPUT (report.axis(k), one per axis)
%     .quality, .alignment, .observability, .globalFit, .slidingFit,
%     .noiseModel, .heteroscedasticity, .spectral, .flags
%
%   The .flags cellstr is the headline output: a plain-language list of
%   everything that would corrupt the adjustment, in priority order.
%
%   See also SCALEOBSERVABILITY, FILTERCONSISTENCY, ESTIMATENOISEMODEL,
%            ACCELBIASSCALEMODELCOMPARE.

ip = inputParser;
ip.addParameter('MaxGapFactor', 5, @isnumeric);
ip.addParameter('InterpMethod', 'pchip', @ischar);
ip.addParameter('MaxInterpGap', [], @(x) isempty(x) || isnumeric(x));
ip.addParameter('FilterStrategy', 'none', @ischar);
ip.addParameter('FilterCutoff', 0.035, @isnumeric);
ip.addParameter('FilterCoef', [], @(x) isempty(x) || isvector(x));
ip.addParameter('WindowLength', [], @(x) isempty(x) || isnumeric(x));
ip.addParameter('WindowOverlap', 0.5, @isnumeric);
ip.addParameter('Robust', true, @islogical);
ip.addParameter('MaxLagFrac', 0.02, @isnumeric);
ip.addParameter('Spectral', true, @islogical);
ip.addParameter('PlotDiagnostics', true, @islogical);
ip.parse(varargin{:});
opt = ip.Results;

t1 = t1(:); t2 = t2(:);
if isvector(y1), y1 = y1(:); end
if isvector(y2), y2 = y2(:); end

nAxes = size(y1,2);
if size(y2,2) ~= nAxes
    error('accelSeriesPreflight:axisMismatch', ...
        'y1 has %d columns, y2 has %d -- must match (per-axis).', nAxes, size(y2,2));
end

report = struct();
for k = 1:nAxes
    report.axis(k) = analyzeOneAxis(t1, y1(:,k), t2, y2(:,k), opt);
end

if opt.PlotDiagnostics
    plotAccelPreflight(report);
end

end

% ===================================================================
function ax = analyzeOneAxis(t1, y1, t2, y2, opt)

ax.flags = {};

%% 1. raw data quality
ax.quality.series1 = qualityCheck(t1, y1, opt.MaxGapFactor);
ax.quality.series2 = qualityCheck(t2, y2, opt.MaxGapFactor);

if ax.quality.series1.nonMonotonic || ax.quality.series2.nonMonotonic
    ax.flags{end+1} = 'Non-monotonic timestamps -- sort/deduplicate before fitting.';
end
if ax.quality.series1.gapFraction > 0.05 || ax.quality.series2.gapFraction > 0.05
    ax.flags{end+1} = sprintf(['Gaps span >5%% of the arc (series1 %.1f%%, ' ...
        'series2 %.1f%%). Use quantile knot placement for spline biases, ' ...
        'or knots will land inside holes where no data constrains them.'], ...
        100*ax.quality.series1.gapFraction, 100*ax.quality.series2.gapFraction);
end
if ax.quality.series1.outlierFraction > 0.01 || ax.quality.series2.outlierFraction > 0.01
    ax.flags{end+1} = 'More than 1% MAD-outliers -- likely ACC glitches/twangs; screen or use a robust fit.';
end

%% 2. alignment
[tA, y1A, y2A, alignInfo] = alignAccelSeries(t1, y1, t2, y2, ...
    'InterpMethod', opt.InterpMethod, 'MaxInterpGap', opt.MaxInterpGap);
ax.alignment = alignInfo;
if alignInfo.droppedFraction > 0.1
    ax.flags{end+1} = sprintf(['%.1f%% of observed epochs have no model sample ' ...
        'within MaxInterpGap -- coverage mismatch.'], 100*alignInfo.droppedFraction);
end
if numel(tA) < 20
    ax.flags{end+1} = 'Fewer than 20 aligned samples -- diagnostics below are unreliable.';
    ax = fillEmpty(ax, tA, y1A, y2A);
    return;
end

%% 3. timing offset
[lagEst, corrMax] = crossCorrLag(tA, y1A, y2A, opt.MaxLagFrac);
ax.alignment.timeLagEstimate = lagEst;
ax.alignment.timeLagCorr = corrMax;
if isfinite(lagEst) && abs(lagEst) > 0 && corrMax > 0.3
    ax.flags{end+1} = sprintf(['Cross-correlation peaks at a nonzero lag ' ...
        '(%.3g time units, corr %.2f) -- a timetag/clock offset will be ' ...
        'absorbed into bias if not fixed first.'], lagEst, corrMax);
end

%% 4. filter consistency
ax.filterInfo = [];
if ~strcmpi(opt.FilterStrategy, 'none')
    [y1A, y2A, fcInfo] = filterConsistency(tA, y1A, y2A, opt.FilterStrategy, ...
        'Cutoff', opt.FilterCutoff, 'FilterCoef', opt.FilterCoef);
    ax.filterInfo = fcInfo;
else
    ax.flags{end+1} = ['FilterStrategy = ''none''. If the observed series is ' ...
        'ACC1B (already low-pass filtered) and the model is evaluated ' ...
        'pointwise, they occupy different spectral bands and the model''s ' ...
        'excess high-frequency power will be partly absorbed by SCALE. ' ...
        'Consider ''commonmode''.'];
end

%% 5. scale observability over the whole arc
obs = scaleObservability(y2A);
ax.observability = obs;
if ~obs.observable
    ax.flags{end+1} = sprintf('SCALE NOT OBSERVABLE over this arc: %s', obs.reason);
end

%% 6. global fit (demeaned, so bias and scale are decorrelated)
mu = mean(y2A);
X = [ones(numel(y2A),1), y2A - mu];
if opt.Robust
    coef = robustLinearFit(X, y1A);
else
    coef = X \ y1A;
end
scale0 = coef(2);
bias0 = coef(1) - coef(2)*mu;
yfit = bias0 + scale0*y2A;
resid = y1A - yfit;

SST = sum((y1A - mean(y1A)).^2);
ax.globalFit.bias = bias0;
ax.globalFit.scale = scale0;
ax.globalFit.R2 = 1 - (resid'*resid)/max(SST, eps);
ax.globalFit.residualStd = std(resid);
ax.globalFit.biasScaleCorr = obs.biasScaleCorr;

if ax.globalFit.R2 < 0.3
    ax.flags{end+1} = sprintf(['Global R^2 = %.2f -- a single bias/scale over ' ...
        'the whole arc fits poorly; finer time resolution is needed.'], ax.globalFit.R2);
end

%% 7. windowed preview
span = tA(end) - tA(1);
winLen = opt.WindowLength;
if isempty(winLen), winLen = span/50; end

ax.slidingFit = slidingWindowFit(tA, y1A, y2A, winLen, opt.WindowOverlap, ...
    'Robust', opt.Robust, 'Demean', true, 'GateObservable', true);

if ax.slidingFit.nWindows > 0
    fracUnobs = ax.slidingFit.nUnobservable / ax.slidingFit.nWindows;
    if fracUnobs > 0.2
        ax.flags{end+1} = sprintf(['%.0f%% of windows have an UNIDENTIFIABLE ' ...
            'scale (low dynamic range / bias-scale collinearity). A scale ' ...
            'that "varies wildly" in your adjustment is most likely this ' ...
            'estimation artifact, not physics. Constraining scale near 1 ' ...
            'hides it rather than fixing it.'], 100*fracUnobs);
    end
end
if ~isnan(ax.slidingFit.scaleStd) && ax.slidingFit.scaleStd > 0.05
    ax.flags{end+1} = sprintf(['Windowed scale varies (std %.3f) even among ' ...
        'OBSERVABLE windows -- consistent with a genuine multiplicative ' ...
        '(density/Cd) model error.'], ax.slidingFit.scaleStd);
end

%% 8. residual noise model
nm = estimateNoiseModel(resid);
ax.noiseModel = nm;
if nm.nEffRatio < 0.8
    ax.flags{end+1} = sprintf(['Residuals are %s (AR order %d, lag-1 acf %.2f, ' ...
        'n_eff/n = %.2f). Formal sigmas from an OLS fit are optimistic by ' ...
        'roughly %.1fx, and AIC/BIC model selection is unreliable. Use GLS ' ...
        '(glsLinearFit), blocked CV, and a block bootstrap.'], ...
        nm.verdict, nm.order, nm.acf1, nm.nEffRatio, sqrt(1/max(nm.nEffRatio,eps)));
end

%% 9. heteroscedasticity
[rho, verdict] = heteroscedasticityCheck(resid, y2A);
ax.heteroscedasticity.corrAbsResidVsAbsModel = rho;
ax.heteroscedasticity.verdict = verdict;
if strcmp(verdict, 'multiplicative-dominated')
    ax.flags{end+1} = sprintf(['Residual magnitude tracks model magnitude ' ...
        '(rho %.2f): the error is multiplicative, so SCALE should be free ' ...
        'to vary; a fixed scale with a varying bias will fit poorly.'], rho);
end

%% 10. spectra (Lomb-Scargle on the true, uneven epochs)
ax.spectral = struct();
if opt.Spectral
    try
        [P1, f1] = lombScarglePSD(tA, y1A);
        [P2, ~]  = lombScarglePSD(tA, y2A);
        [Pr, ~]  = lombScarglePSD(tA, resid);
        ax.spectral.f = f1;
        ax.spectral.Pobs = P1;
        ax.spectral.Pmod = P2;
        ax.spectral.Pres = Pr;
    catch ME
        ax.spectral.error = ME.message;
    end
end

end

% -------------------------------------------------------------------
function ax = fillEmpty(ax, tA, y1A, y2A) %#ok<INUSD>
ax.observability = [];
ax.globalFit = struct('bias',NaN,'scale',NaN,'R2',NaN, ...
    'residualStd',NaN,'biasScaleCorr',NaN);
ax.slidingFit = slidingWindowFit([], [], [], 1, 0.5);
ax.noiseModel = [];
ax.heteroscedasticity = struct('corrAbsResidVsAbsModel',NaN,'verdict','indeterminate');
ax.spectral = struct();
ax.filterInfo = [];
end
