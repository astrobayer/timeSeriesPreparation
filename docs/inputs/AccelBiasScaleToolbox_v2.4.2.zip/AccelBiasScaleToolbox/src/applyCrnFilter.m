function [yOut, tOut] = applyCrnFilter(tIn, yIn, h, varargin)
%APPLYCRNFILTER  Put a modelled acceleration through the ACC_1B processing
%   chain, so that it can legitimately be compared with ACC_1B.
%
%   [yOut, tOut] = applyCrnFilter(tIn, yIn, h)
%   [yOut, tOut] = applyCrnFilter(tIn, yIn, h, 'Name', Value, ...)
%
%   The ATBD (JPL D-27672, section 3) builds ACC_1B from ACC_1A by:
%     (i)  resampling the raw linear accelerations onto a uniform 10 Hz
%          grid in corrected time,
%     (ii) convolving with the CRN kernel (140.7 s span, ~0.0355 Hz), and
%     (iii) SAMPLING the result at integer seconds -> a 1 Hz product.
%
%   To make a force model comparable, the model must go through the SAME
%   chain. Two mistakes are common and both bias the scale factor:
%
%     * Filtering the model on its own coarse grid. The CRN kernel is
%       DEFINED on the 10 Hz grid (Nf = 1407 taps at fs = 10 Hz). Applying
%       it, or a decimated version of it, at 1 Hz or 5 Hz is a different
%       filter. Evaluate the model at 10 Hz first.
%     * Averaging the filtered model down to 1 Hz. ACC_1B is SAMPLED, not
%       block-averaged -- averaging applies an extra boxcar and removes
%       power the real product retains.
%
%   INPUT
%     tIn : Nx1 epochs of the modelled series [s]. Need not be uniform.
%     yIn : Nx1 or NxM modelled accelerations.
%     h   : CRN kernel from CRNFILTER (its info.fs sets the working rate)
%
%   NAME-VALUE
%     'Fs'         (10)      working rate the kernel is defined on [Hz]
%     'OutputRate' (1)       output sample rate [Hz]; ACC_1B is 1 Hz
%     'InterpMethod' ('pchip')  used to lift the model onto the 10 Hz grid.
%                    Amplitude-preserving; 'linear' would attenuate, and
%                    that attenuation is absorbed by the scale factor.
%     'OutputTimes' ([])     explicit output epochs. If given, the filtered
%                    10 Hz series is sampled (pchip) at exactly these times
%                    -- use the ACC_1B epochs so that no further
%                    interpolation of the OBSERVED series is ever needed.
%     'Edge'       ('reflect')  'reflect' pads by reflection to suppress
%                    start/end transients; 'nan' marks the first and last
%                    Nh samples invalid instead. The kernel is 140.7 s
%                    long, so ~70 s at each end of every arc is unavoidably
%                    contaminated -- with 'reflect' it is merely
%                    approximated, not measured.
%
%   OUTPUT
%     yOut, tOut : the filtered, sampled model, directly comparable to
%                  ACC_1B.
%
%   Filtering is zero-phase in the sense that the kernel is symmetric and
%   applied centred (no forward-backward pass, which would square the
%   response). The ATBD filter is already linear-phase; centring it removes
%   the group delay exactly.
%
%   Example
%     h = crnFilter('ACC');
%     [yModFilt, tModFilt] = applyCrnFilter(tMod, yMod, h, ...
%          'OutputTimes', tAcc1B);
%
%   See also CRNFILTER, FILTERCONSISTENCY.

ip = inputParser;
ip.addParameter('Fs', 10, @isnumeric);
ip.addParameter('OutputRate', 1, @isnumeric);
ip.addParameter('InterpMethod', 'pchip', @ischar);
ip.addParameter('OutputTimes', [], @(x) isempty(x) || isvector(x));
ip.addParameter('Edge', 'reflect', @ischar);
ip.parse(varargin{:});
o = ip.Results;

tIn = tIn(:);
if isvector(yIn), yIn = yIn(:); end
h = h(:);
Nh = (numel(h) - 1)/2;
if mod(numel(h), 2) == 0
    error('applyCrnFilter:evenKernel', 'CRN kernel must have odd length.');
end

%% --- (i) lift the model onto the uniform working grid the kernel expects ---
dt = 1/o.Fs;
tw = (tIn(1) : dt : tIn(end)).';
Yw = interp1(tIn, yIn, tw, o.InterpMethod);

%% --- (ii) convolve with the CRN kernel ---
M = size(Yw, 2);
Yf = nan(size(Yw));
for j = 1:M
    Yf(:,j) = centredConv(Yw(:,j), h, o.Edge, Nh);
end

%% --- (iii) sample (do NOT average) at the output epochs ---
if ~isempty(o.OutputTimes)
    tOut = o.OutputTimes(:);
else
    stride = round(o.Fs / o.OutputRate);
    idx = 1:stride:numel(tw);
    tOut = tw(idx);
    yOut = Yf(idx, :);
    return;
end

yOut = interp1(tw, Yf, tOut, 'pchip', NaN);

end

% -------------------------------------------------------------------
function y = centredConv(x, h, edgeMode, Nh)
%CENTREDCONV  Symmetric-kernel convolution with no group delay.
n = numel(x);

switch lower(edgeMode)
    case 'reflect'
        np = min(Nh, n-1);
        xp = [2*x(1) - flipud(x(2:np+1)); x; 2*x(end) - flipud(x(end-np:end-1))];
        yFull = conv(xp, h, 'same');
        y = yFull(np+1 : np+n);
    case 'nan'
        yFull = conv(x, h, 'same');
        y = yFull;
        y(1:min(Nh,n)) = NaN;
        y(max(1,end-Nh+1):end) = NaN;
    otherwise
        error('applyCrnFilter:badEdge', 'Edge must be ''reflect'' or ''nan''.');
end
end
