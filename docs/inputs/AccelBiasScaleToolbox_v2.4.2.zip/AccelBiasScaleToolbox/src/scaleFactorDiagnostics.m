function diag = scaleFactorDiagnostics(perRev, indices, varargin)
%SCALEFACTORDIAGNOSTICS  Separate the physical CAUSE of a drifting
%   accelerometer scale factor by regressing the per-revolution scale
%   against space-weather and orbit-geometry indices over a multi-day arc.
%
%   diag = scaleFactorDiagnostics(perRev, indices)
%   diag = scaleFactorDiagnostics(perRev, indices, 'Name', Value, ...)
%   diag = scaleFactorDiagnostics(result, indices, ...)   % result from
%                                                         % ANALYZEACCSCALEARC
%
%   WHY THIS EXISTS
%   ANALYZEACCSCALEARC establishes, on a single day, that the per-rev scale
%   anti-correlates with modeled drag -- the signature of a force-model
%   (density/Cd) deficiency rather than a sensor error. But a single day
%   CANNOT separate the three candidate causes, because over one day the
%   drag varies only ~10% and only with orbital phase, so a density-model
%   error, a Cd (geometry) error, and a genuine slow sensor drift are all
%   confounded with the same orbital cycle. This function performs the
%   separation the roadmap calls for: given several days that span varied
%   solar/geomagnetic activity, it multiple-regresses the per-rev scale
%   on the indices that discriminate the causes.
%
%   THE DECISION TABLE (per axis)
%     scale tracks F10.7 / Kp / Dst         -> DENSITY-model error
%                                              (thermosphere density wrong)
%     scale tracks beta-angle / arg-of-lat  -> GEOMETRY / Cd error
%       ONLY (not the activity indices)        (drag-coefficient / attitude)
%     scale drifts SECULARLY, independent   -> SENSOR drift / aging
%       of every drag predictor                (or thermal), instrument-side
%     no significant predictor              -> unresolved; scale is flat
%                                              or dominated by noise
%
%   The regression is on STANDARDIZED predictors so coefficient magnitudes
%   are directly comparable, with honest (block-bootstrap) confidence
%   intervals because per-rev scales inherit the residual autocorrelation
%   of the underlying series. A predictor is called significant only when
%   its bootstrap CI excludes zero.
%
%   INPUT
%     perRev   - EITHER the .perRev struct from ANALYZEACCSCALEARC, OR a
%                full ANALYZEACCSCALEARC result struct (its .perRev is used
%                automatically). Must provide:
%                  .tMid    Rx1  per-rev window-center time [s from start]
%                  .scale   Rx3  per-rev diagonal scale (NaN = unobservable)
%                  .dragMag Rx1  per-rev mean modeled |a| (optional, added
%                                as a predictor if present)
%     indices  - struct of per-rev geophysical/geometry indices, each an
%                Rx1 vector aligned 1:1 with perRev.tMid (same length R,
%                same order). Recognized field names (any subset):
%                  .F107    solar radio flux (density driver)
%                  .F107a   81-day averaged F10.7 (density driver)
%                  .Kp      planetary K-index  (density driver)
%                  .Dst     disturbance storm-time index (density driver)
%                  .Ap      planetary A-index  (density driver)
%                  .beta    orbit beta-angle [deg] (geometry driver)
%                  .argLat  argument of latitude [deg] (geometry driver;
%                           entered as sin+cos to respect its periodicity)
%                Unrecognized fields are still admitted as predictors but
%                left UNCLASSIFIED (they contribute to the fit and are
%                reported, but do not vote on the cause).
%
%   NAME-VALUE
%     'Axes'        (1:3)      which observed axes to diagnose
%     'AxisNames'   ({'X (along-track)','Y (cross-track)','Z (radial)'})
%     'Secular'     (true)     add a standardized linear time term as a
%                              SENSOR-drift predictor
%     'MinRevs'     (12)       minimum observable revs to attempt a fit;
%                              below this the axis is reported unresolved
%     'NumBoot'     (2000)     block-bootstrap resamples for the CIs
%     'BlockRevs'   ([])       bootstrap block length in revs; []=> derived
%                              from the lag-1 autocorrelation of the per-rev
%                              scale (ceil(5*tau), tau=-1/log|rho1|)
%     'Alpha'       (0.05)     CI level (0.05 => 95% CI)
%     'MinR2'       (0.10)     if the index model explains less variance
%                              than this, the axis is reported 'unresolved'
%                              regardless of individual CIs -- guards
%                              against a spurious cause on a flat or
%                              noise-dominated scale
%     'Standardize' (true)     z-score predictors before the fit
%     'Verbose'     (true)     print a per-axis verdict table
%
%   OUTPUT (struct)
%     .axis          1xA struct array, one per diagnosed axis:
%        .name          axis label
%        .nRevs         number of observable revs used
%        .predictors    1xP cellstr of predictor names (in design order)
%        .family        1xP cellstr, each 'density'|'geometry'|'sensor'|
%                       'other' (which cause each predictor votes for)
%        .coef          1xP standardized regression coefficients
%        .coefCI        Px2 bootstrap CI per coefficient
%        .coefSig       1xP logical, CI excludes zero
%        .tStat         1xP coef / bootstrap-sigma
%        .R2            coefficient of determination of the index model
%        .dominant      name of the largest significant predictor ('' none)
%        .cause         'density'|'geometry'|'sensor'|'mixed'|'unresolved'
%        .causeStrength 0..1, |dominant standardized coef| share of the
%                       significant-predictor coefficient magnitude
%        .verdict       plain-language per-axis conclusion
%     .summary       1xA cellstr, the per-axis verdicts
%     .table         MATLAB table (axis x cause) for quick inspection,
%                    empty if the table type is unavailable
%     .flags         cellstr of caveats (short arcs, collinear predictors,
%                    activity range too small to separate causes, ...)
%     .provenance    struct: run time/date, toolbox and Claude version
%
%   IDENTIFIABILITY CAVEATS (issued in .flags when detected)
%     * If the activity indices barely vary over the arc (e.g. a quiet
%       week), density and geometry causes remain confounded exactly as in
%       the single-day case, and the function says so rather than guessing.
%     * If two predictors are strongly collinear (|corr|>0.9) the split
%       between their families is unreliable; both are flagged.
%     * Per-rev scales are themselves low-confidence near the collinearity
%       floor (see ACCELTIMEVARYINGSCALEFIT); treat a weak cause with the
%       skepticism its wide CI implies.
%
%   EXAMPLE
%     % multi-day arc, then attach indices to each per-rev window
%     r  = analyzeAccScaleArc(obsList, modelList, 'Plot', false);
%     ix = attachIndices(r.perRev.tMid, startMJD);   % your index loader
%     d  = scaleFactorDiagnostics(r, ix);
%     disp(d.summary')
%
%   See also ANALYZEACCSCALEARC, ANALYZEACCARC, ACCELTIMEVARYINGSCALEFIT,
%            BLOCKBOOTSTRAP, DECOMPOSESCALEMATRIX.
%
%   ---------------------------------------------------------------------
%   Authoring provenance
%     Date      : 2026-07-15
%     Time      : 14:00 UTC
%     Author    : Claude (Anthropic), model Claude Opus 4.8
%     Toolbox   : AccelBiasScaleToolbox
%   Implements the multi-day index-regression "next step" specified in
%   ROADMAP.md section 6. Per-run execution time/date is in diag.provenance.
%   ---------------------------------------------------------------------

%% ---- accept a full analyzeAccScaleArc result or a bare perRev struct ----
if isfield(perRev, 'perRev')
    perRev = perRev.perRev;
end
if ~all(isfield(perRev, {'tMid','scale'}))
    error('scaleFactorDiagnostics:badPerRev', ...
        'perRev must contain fields tMid and scale (from ANALYZEACCSCALEARC).');
end

ip = inputParser;
ip.addParameter('Axes', 1:3, @isnumeric);
ip.addParameter('AxisNames', {'X (along-track)','Y (cross-track)','Z (radial)'}, @iscell);
ip.addParameter('Secular', true, @islogical);
ip.addParameter('MinRevs', 12, @isnumeric);
ip.addParameter('NumBoot', 2000, @isnumeric);
ip.addParameter('BlockRevs', [], @isnumeric);
ip.addParameter('Alpha', 0.05, @isnumeric);
ip.addParameter('MinR2', 0.10, @isnumeric);
ip.addParameter('Standardize', true, @islogical);
ip.addParameter('Verbose', true, @islogical);
ip.parse(varargin{:});
opt = ip.Results;

tMid  = perRev.tMid(:);
scale = perRev.scale;
R = numel(tMid);
if size(scale,1) ~= R
    error('scaleFactorDiagnostics:sizeMismatch', ...
        'perRev.scale must have as many rows as perRev.tMid.');
end

flags = {};

%% ---- assemble the predictor design (shared across axes) ----
[P, pNames, pFamily, flags] = buildPredictors(indices, tMid, R, opt, flags);
if isempty(P)
    error('scaleFactorDiagnostics:noPredictors', ...
        ['No usable per-rev predictors were supplied. Provide at least one ' ...
         'of F107/F107a/Kp/Dst/Ap/beta/argLat as an Rx1 vector, or enable ' ...
         '''Secular''.']);
end

% add drag magnitude as an "other" predictor if available (diagnostic only:
% it is what the single-day analysis already used; here it helps the fit but
% does not itself discriminate density vs Cd)
if isfield(perRev, 'dragMag') && any(isfinite(perRev.dragMag))
    dm = perRev.dragMag(:);
    P = [P, zc(dm, opt.Standardize)];
    pNames{end+1}  = 'dragMag';
    pFamily{end+1} = 'other';
end

% collinearity warning between predictors
flags = collinearityFlags(P, pNames, flags);

% Drop degenerate columns (near-constant, or exactly collinear with an
% earlier column) so the per-axis design is full rank. A constant predictor
% carries no diagnostic information; an exactly-collinear one is redundant
% and would make the fit rank-deficient. Near-collinear (but not exact)
% columns are kept and covered by the collinearity flag above.
[P, pNames, pFamily, dropped] = dropDegenerate(P, pNames, pFamily);
if ~isempty(dropped)
    flags{end+1} = sprintf(['Dropped %d degenerate predictor(s) [%s] that were ' ...
        'constant or exactly collinear over this arc; they carry no ' ...
        'separable information here.'], numel(dropped), strjoin(dropped, ', '));
end

% activity-range adequacy: if no density-family predictor spans a useful
% range, density vs geometry stay confounded (the single-day problem)
flags = activityRangeFlags(indices, pFamily, pNames, flags);

%% ---- per-axis regression + bootstrap ----
axes_ = opt.Axes(:).';
A = numel(axes_);
axStruct = repmat(emptyAxis(), 1, A);

for a = 1:A
    i = axes_(a);
    name = axisName(opt.AxisNames, i);
    y = scale(:, i);
    good = isfinite(y) & all(isfinite(P), 2);
    nUse = nnz(good);

    ax = emptyAxis();
    ax.name = name;
    ax.nRevs = nUse;
    ax.predictors = pNames;
    ax.family = pFamily;

    if nUse < opt.MinRevs
        ax.cause = 'unresolved';
        ax.verdict = sprintf(['%s: only %d observable rev(s) (< %d) -- too ' ...
            'few to regress against indices. Supply more days.'], ...
            name, nUse, opt.MinRevs);
        axStruct(a) = ax;
        continue;
    end

    Xg = [ones(nUse,1), P(good,:)];
    yg = y(good);
    coefFull = Xg \ yg;
    yhat = Xg * coefFull;
    ss = sum((yg - yhat).^2);
    sst = sum((yg - mean(yg)).^2);
    ax.R2 = 1 - ss / max(sst, realmin);

    % block bootstrap over contiguous revs to get honest CIs
    blk = opt.BlockRevs;
    if isempty(blk)
        blk = blockLenFromScale(yg);
    end
    boot = bootstrapCoef(Xg, yg, blk, opt.NumBoot);
    bootP = boot(:, 2:end);                 % drop intercept column
    coef = coefFull(2:end).';
    lo = quantile(bootP, opt.Alpha/2, 1);
    hi = quantile(bootP, 1-opt.Alpha/2, 1);
    sig = (lo .* hi) > 0;                    % CI excludes zero
    bsig = std(bootP, 0, 1);
    tstat = coef ./ max(bsig, realmin);

    ax.coef   = coef;
    ax.coefCI = [lo.' hi.'];
    ax.coefSig = sig;
    ax.tStat  = tstat;

    % dominant significant predictor and cause attribution
    if ax.R2 < opt.MinR2
        ax.cause = 'unresolved';
        ax.dominant = '';
        ax.causeStrength = 0;
    else
        [ax.cause, ax.dominant, ax.causeStrength] = ...
            attributeCause(coef, sig, pFamily, pNames);
    end
    ax.verdict = verdictText(ax);

    axStruct(a) = ax;
end

%% ---- assemble ----
diag.axis = axStruct;
diag.summary = {axStruct.verdict};
diag.table = buildTable(axStruct);
diag.flags = unique(flags, 'stable');
runNow = datetime('now');
diag.provenance = struct( ...
    'runDatetime',   char(runNow, 'yyyy-MM-dd HH:mm:ss'), ...
    'runDatenum',    datenum(runNow), ...
    'toolbox',       'AccelBiasScaleToolbox', ...
    'codeAuthored',  '2026-07-15', ...
    'claudeVersion', 'Claude Opus 4.8 (Anthropic)');

if opt.Verbose
    printDiagnostics(diag);
end

end

% ===================================================================
% helpers
% ===================================================================
function [P, names, family, flags] = buildPredictors(indices, tMid, R, opt, flags)
% Build the standardized predictor matrix and its per-column cause family.
P = []; names = {}; family = {};

% recognized density-driver and geometry-driver index names
densityNames  = {'F107','F107a','Kp','Dst','Ap'};
geometryNames = {'beta'};   % argLat handled specially (periodic)

fn = fieldnames(indices);
for k = 1:numel(fn)
    nm = fn{k};
    v = indices.(nm);
    if strcmpi(nm, 'argLat')
        continue;   % handled below as sin/cos pair
    end
    if ~isnumeric(v) || numel(v) ~= R
        flags{end+1} = sprintf(['Index ''%s'' is not an Rx1 numeric vector ' ...
            '(R=%d); ignored.'], nm, R); %#ok<AGROW>
        continue;
    end
    P(:, end+1) = zc(v(:), opt.Standardize); %#ok<AGROW>
    names{end+1} = nm; %#ok<AGROW>
    if any(strcmpi(nm, densityNames))
        family{end+1} = 'density'; %#ok<AGROW>
    elseif any(strcmpi(nm, geometryNames))
        family{end+1} = 'geometry'; %#ok<AGROW>
    else
        family{end+1} = 'other'; %#ok<AGROW>
    end
end

% argument of latitude -> sin/cos, geometry family (respects periodicity)
if isfield(indices, 'argLat') && isnumeric(indices.argLat) && numel(indices.argLat) == R
    al = deg2rad(indices.argLat(:));
    P(:, end+1) = sin(al);   names{end+1} = 'argLat_sin'; family{end+1} = 'geometry';
    P(:, end+1) = cos(al);   names{end+1} = 'argLat_cos'; family{end+1} = 'geometry';
end

% secular sensor-drift term
if opt.Secular
    P(:, end+1) = zc(tMid(:), opt.Standardize);
    names{end+1} = 'secular'; family{end+1} = 'sensor';
end
end

% -------------------------------------------------------------------
function z = zc(x, doStd)
% center (and optionally scale) a column, NaN-robust
mu = mean(x, 'omitnan');
if doStd
    sd = std(x, 'omitnan');
    if sd <= 0, sd = 1; end
else
    sd = 1;
end
z = (x - mu) / sd;
end

% -------------------------------------------------------------------
function blk = blockLenFromScale(y)
% bootstrap block length in revs from lag-1 autocorrelation of the per-rev
% scale: tau = -1/log|rho1|, ell = ceil(5*tau), as in BLOCKBOOTSTRAP.
y = y - mean(y);
n = numel(y);
if n < 4, blk = 1; return; end
r1 = (y(1:end-1).' * y(2:end)) / max(y.'*y, realmin);
r1 = min(abs(r1), 0.999);
if r1 < 1e-3
    blk = 1;
else
    tau = -1/log(r1);
    blk = max(1, min(ceil(5*tau), floor(n/2)));
end
end

% -------------------------------------------------------------------
function [P, names, family, dropped] = dropDegenerate(P, names, family)
% Remove constant columns and columns exactly collinear with an earlier one
% (QR-based rank detection), so the design matrix is full column rank.
keep = true(1, size(P,2));
% 1) constant / zero-variance columns
for j = 1:size(P,2)
    if std(P(:,j), 'omitnan') <= eps
        keep(j) = false;
    end
end
% 2) exact collinearity among the surviving columns, via QR with pivoting
idx = find(keep);
if numel(idx) >= 2
    A = P(:, idx);
    A = A(all(isfinite(A),2), :);
    if size(A,1) >= 2
        r = rank(A);
        if r < numel(idx)
            % greedily keep columns that increase rank
            chosen = [];
            for c = 1:numel(idx)
                trial = [chosen, idx(c)];
                if rank(P(all(isfinite(P(:,trial)),2), trial)) == numel(trial)
                    chosen = trial;
                end
            end
            drop2 = setdiff(idx, chosen);
            keep(drop2) = false;
        end
    end
end
dropped = names(~keep);
P = P(:, keep); names = names(keep); family = family(keep);
end

% -------------------------------------------------------------------
function boot = bootstrapCoef(X, y, blk, nboot)
% moving-block bootstrap of the regression coefficients
n = numel(y); p = size(X,2);
boot = nan(nboot, p);
maxStart = n - blk + 1;
if maxStart < 1, maxStart = 1; blk = n; end
nblk = ceil(n/blk);
for b = 1:nboot
    idx = zeros(nblk*blk, 1);
    st = randi(maxStart, nblk, 1);
    for k = 1:nblk
        idx((k-1)*blk + (1:blk)) = st(k) + (0:blk-1);
    end
    idx = idx(1:n);
    idx(idx > n) = n;
    Xb = X(idx, :); yb = y(idx);
    if rank(Xb) == p
        boot(b, :) = (Xb \ yb).';
    else
        boot(b, :) = (pinv(Xb) * yb).';   % minimum-norm fallback
    end
end
boot = boot(all(isfinite(boot), 2), :);
if isempty(boot)
    % degenerate arc: report the point fit with zero-width CIs rather than
    % erroring, so the caller still gets a (low-confidence) verdict.
    boot = (X \ y).';
end
end

% -------------------------------------------------------------------
function [cause, dominant, strength] = attributeCause(coef, sig, family, names)
% Vote the dominant significant predictor's family as the cause. If the
% top two significant predictors are of different families and comparable
% magnitude, call it 'mixed'.
cause = 'unresolved'; dominant = ''; strength = 0;
acoef = abs(coef);
acoef(~sig) = 0;                 % only significant predictors vote
if ~any(acoef > 0)
    return;
end
[srt, ord] = sort(acoef, 'descend');
dominant = names{ord(1)};
domFamily = family{ord(1)};
total = sum(srt);
strength = srt(1) / max(total, realmin);

% classify: family of the dominant predictor, unless a different-family
% runner-up is within 20% of it => mixed
cause = domFamily;
if numel(srt) >= 2 && srt(2) > 0 && ~strcmp(family{ord(2)}, domFamily)
    if srt(2) / srt(1) > 0.8
        cause = 'mixed';
    end
end
% 'other'-family dominant predictor is not a physical verdict on its own
if strcmp(cause, 'other')
    cause = 'unresolved';
end
end

% -------------------------------------------------------------------
function txt = verdictText(ax)
name = ax.name;
switch ax.cause
    case 'density'
        txt = sprintf(['%s: scale tracks solar/geomagnetic activity ' ...
            '(dominant %s, R2=%.2f) -> DENSITY-model error (thermosphere ' ...
            'density), not a sensor scale error.'], name, ax.dominant, ax.R2);
    case 'geometry'
        txt = sprintf(['%s: scale tracks orbit geometry (dominant %s, ' ...
            'R2=%.2f) but NOT the activity indices -> Cd / geometry ' ...
            '(drag-coefficient or attitude) error.'], name, ax.dominant, ax.R2);
    case 'sensor'
        txt = sprintf(['%s: scale drifts secularly, independent of drag ' ...
            '(dominant %s, R2=%.2f) -> SENSOR drift / aging (instrument ' ...
            'side), not the force model.'], name, ax.dominant, ax.R2);
    case 'mixed'
        txt = sprintf(['%s: scale is driven by more than one cause of ' ...
            'comparable strength (top: %s, R2=%.2f). Report both; a longer ' ...
            'or more active arc may separate them.'], name, ax.dominant, ax.R2);
    otherwise
        if ax.nRevs > 0
            txt = sprintf(['%s: no index significantly predicts the scale ' ...
                '(R2=%.2f) -> scale is flat or noise-dominated over this arc; ' ...
                'no force-model or sensor cause resolved.'], name, ax.R2);
        else
            txt = sprintf('%s: unresolved.', name);
        end
end
end

% -------------------------------------------------------------------
function flags = collinearityFlags(P, names, flags)
if size(P,2) < 2, return; end
C = corrcoef(P);
for i = 1:size(P,2)
    for j = i+1:size(P,2)
        if isfinite(C(i,j)) && abs(C(i,j)) > 0.9
            flags{end+1} = sprintf(['Predictors ''%s'' and ''%s'' are ' ...
                'collinear (r=%.2f); their cause families cannot be cleanly ' ...
                'separated on this arc.'], names{i}, names{j}, C(i,j)); %#ok<AGROW>
        end
    end
end
end

% -------------------------------------------------------------------
function flags = activityRangeFlags(indices, family, names, flags)
% if there is a density family but its indices barely move, warn that the
% density-vs-geometry separation is weak (the single-day confound persists)
hasDensity = any(strcmp(family, 'density'));
if ~hasDensity
    flags{end+1} = ['No solar/geomagnetic activity index (F107/Kp/Dst/...) ' ...
        'was supplied, so a density-model error cannot be separated from a ' ...
        'Cd/geometry error. Provide activity indices to complete the ' ...
        'separation the roadmap calls for.'];
    return;
end
% relative range of each density index
for k = 1:numel(names)
    if strcmp(family{k}, 'density') && isfield(indices, names{k})
        v = indices.(names{k}); v = v(isfinite(v));
        if isempty(v), continue; end
        rel = (max(v) - min(v)) / max(abs(mean(v)), realmin);
        if rel < 0.1
            flags{end+1} = sprintf(['Activity index ''%s'' varies only %.0f%% ' ...
                'over the arc -- likely too quiet to separate a density-model ' ...
                'error from a Cd error. Include a geomagnetic storm.'], ...
                names{k}, 100*rel); %#ok<AGROW>
        end
    end
end
end

% -------------------------------------------------------------------
function T = buildTable(axStruct)
try
    nm = {axStruct.name}.';
    cause = {axStruct.cause}.';
    dom = {axStruct.dominant}.';
    R2 = [axStruct.R2].';
    nRev = [axStruct.nRevs].';
    T = table(nm, cause, dom, R2, nRev, ...
        'VariableNames', {'axis','cause','dominant','R2','nRevs'});
catch
    T = [];
end
end

% -------------------------------------------------------------------
function ax = emptyAxis()
ax = struct('name','', 'nRevs',0, 'predictors',{{}}, 'family',{{}}, ...
    'coef',[], 'coefCI',[], 'coefSig',[], 'tStat',[], 'R2',NaN, ...
    'dominant','', 'cause','unresolved', 'causeStrength',0, 'verdict','');
end

% -------------------------------------------------------------------
function nm = axisName(names, i)
if i >= 1 && i <= numel(names), nm = names{i}; else, nm = sprintf('axis %d', i); end
end

% -------------------------------------------------------------------
function printDiagnostics(d)
fprintf('\n===== scaleFactorDiagnostics: multi-day cause attribution =====\n');
for a = 1:numel(d.axis)
    ax = d.axis(a);
    fprintf('  %-16s cause: %-10s  R2=%.2f  (n=%d rev)\n', ...
        ax.name, upper(ax.cause), ax.R2, ax.nRevs);
    if ~isempty(ax.coef)
        for p = 1:numel(ax.predictors)
            mark = ternary(ax.coefSig(p), '*', ' ');
            fprintf('       %s %-12s coef=%+.4f  CI [%+.4f, %+.4f]  (%s)\n', ...
                mark, ax.predictors{p}, ax.coef(p), ...
                ax.coefCI(p,1), ax.coefCI(p,2), ax.family{p});
        end
    end
end
fprintf('\nVerdict:\n');
for a = 1:numel(d.axis), fprintf('  %s\n', d.axis(a).verdict); end
if ~isempty(d.flags)
    fprintf('\nCaveats:\n');
    for k = 1:numel(d.flags), fprintf('  [!] %s\n', d.flags{k}); end
end
fprintf('  (* = bootstrap CI excludes zero)\n');
fprintf('================================================================\n');
end

function o = ternary(c,a,b), if c, o=a; else, o=b; end, end
