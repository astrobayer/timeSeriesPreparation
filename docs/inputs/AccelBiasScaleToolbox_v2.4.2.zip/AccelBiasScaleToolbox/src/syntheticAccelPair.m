function [tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair(varargin)
%SYNTHETICACCELPAIR  Generate a realistic observed/modeled acceleration
%   pair with KNOWN injected truth, for end-to-end validation.
%
%   [tObs, Yobs, tMod, Ymod, truth] = syntheticAccelPair()
%   [...] = syntheticAccelPair('Name', Value, ...)
%
%   Unit tests on noise-free data verify that each function inverts its
%   own forward model -- which is necessary but weak: it cannot catch the
%   INTERACTION bugs that actually corrupt real analyses (a knot landing
%   inside a gap, a filter mismatch leaking into scale, autocorrelated
%   residuals producing confident-but-wrong error bars). Those only appear
%   when every defect is present at once. This generator injects them all
%   simultaneously, so the pipeline can be scored against ground truth.
%
%   Forward model:
%     1. A modeled non-gravitational acceleration with orbital-period
%        structure: once-per-rev drag + twice-per-rev SRP-like terms, a
%        slowly varying drag amplitude (a "storm"), and eclipse-driven
%        switching. Sampled on its own grid (tMod).
%     2. The observed series is built as
%              Yobs = bias(t) + S * Ymod + colored noise
%        with S a full 3x3 matrix (misalignment rotation x scale/
%        non-orthogonality stretch) and bias(t) a smooth spline drift.
%     3. The observed series is LOW-PASS FILTERED (as ACC1B is) while the
%        model is left unfiltered -- reproducing the filter mismatch.
%     4. Noise is AR(1) (colored), not white.
%     5. Gaps are cut, and glitch spikes injected.
%     6. Observed and model land on DIFFERENT time grids.
%
%   NAME-VALUE
%     'Duration'    (86400)  span [s]
%     'DtObs'       (1)      observed sampling [s]
%     'DtMod'       (5)      model sampling [s] (deliberately different)
%     'OrbitPeriod' (5400)   [s]
%     'Scales'      ([0.96 1.03 1.10])  true per-axis scale factors
%     'MisalignUrad'([2000 -1000 1500]) true misalignment angles [urad]
%     'NonOrtho'    ([0.01 0.0 0.005])  true U(1,2), U(1,3), U(2,3)
%     'BiasAmp'     (0.05)   amplitude of the smooth bias drift
%     'NoiseStd'    (0.02)   innovation std of the AR(1) noise
%     'NoiseRho'    (0.9)    AR(1) coefficient (0 => white)
%     'NumGaps'     (3)      data holes cut from the observed series
%     'GapLen'      (600)    length of each gap [s]
%     'NumGlitches' (5)      outlier spikes in the observed series
%     'GlitchAmp'   (20)     spike amplitude, in units of NoiseStd
%     'FilterObs'   (true)   low-pass the observed series (ACC1B-like)
%     'Cutoff'      (0.02)   that filter's cutoff [Hz]
%     'Seed'        (42)
%
%   OUTPUT
%     tObs, Yobs : observed epochs and Nx3 accelerations (gappy, filtered,
%                  glitchy, colored-noise)
%     tMod, Ymod : model epochs and Kx3 accelerations (clean, unfiltered)
%     truth      : struct of everything injected --
%                  .S, .R, .U, .scales, .anglesUrad, .nonOrtho,
%                  .biasFun (function handle t -> 1x3 bias),
%                  .biasAtObs, .noiseRho, .filterCoef, .gapIntervals,
%                  .glitchIdx
%
%   Example
%     [tO,Yo,tM,Ym,truth] = syntheticAccelPair();
%     % ... run the pipeline, then compare against truth.S / truth.scales
%
%   See also ACCELBIASSCALEMODELFIT, DECOMPOSESCALEMATRIX, FILTERCONSISTENCY.

ip = inputParser;
ip.addParameter('Duration', 86400, @isnumeric);
ip.addParameter('DtObs', 1, @isnumeric);
ip.addParameter('DtMod', 5, @isnumeric);
ip.addParameter('OrbitPeriod', 5400, @isnumeric);
ip.addParameter('Scales', [0.96 1.03 1.10], @isnumeric);
ip.addParameter('MisalignUrad', [2000 -1000 1500], @isnumeric);
ip.addParameter('NonOrtho', [0.01 0.0 0.005], @isnumeric);
ip.addParameter('BiasAmp', 0.05, @isnumeric);
ip.addParameter('NoiseStd', 0.02, @isnumeric);
ip.addParameter('NoiseRho', 0.9, @isnumeric);
ip.addParameter('NumGaps', 3, @isnumeric);
ip.addParameter('GapLen', 600, @isnumeric);
ip.addParameter('NumGlitches', 5, @isnumeric);
ip.addParameter('GlitchAmp', 20, @isnumeric);
ip.addParameter('FilterObs', true, @islogical);
ip.addParameter('Cutoff', 0.02, @isnumeric);
ip.addParameter('Seed', 42, @isnumeric);
ip.parse(varargin{:});
o = ip.Results;

rng(o.Seed);

%% --- 1. the true scale matrix S = R * U ---
a = o.MisalignUrad(:) * 1e-6;
Wx = [   0   -a(3)  a(2)
       a(3)    0   -a(1)
      -a(2)  a(1)    0   ];
% exponential map of the skew matrix => an exactly orthogonal rotation
R = expmSkew(Wx);

U = diag(o.Scales(:));
U(1,2) = o.NonOrtho(1); U(2,1) = o.NonOrtho(1);
U(1,3) = o.NonOrtho(2); U(3,1) = o.NonOrtho(2);
U(2,3) = o.NonOrtho(3); U(3,2) = o.NonOrtho(3);

S = R * U;

%% --- 2. the model series on its own grid ---
tMod = (0 : o.DtMod : o.Duration)';
Ymod = forceModel(tMod, o.OrbitPeriod);

%% --- 3. the observed series, on its own (finer) grid ---
tObsFull = (0 : o.DtObs : o.Duration)';
YmodAtObs = forceModel(tObsFull, o.OrbitPeriod);

% smooth bias drift: a few sinusoidal components (a "spline-like" wander)
biasFun = @(t) o.BiasAmp * [ ...
    1.0*sin(2*pi*t/(0.7*o.Duration)) + 0.3, ...
    0.6*sin(2*pi*t/(0.4*o.Duration) + 1.0) - 0.2, ...
    0.8*sin(2*pi*t/(1.1*o.Duration) + 2.0) + 0.1 ];

biasAtObs = biasFun(tObsFull);

Yobs = biasAtObs + YmodAtObs * S.';

%% --- 4. colored (AR(1)) noise ---
for j = 1:3
    Yobs(:,j) = Yobs(:,j) + ar1Noise(numel(tObsFull), o.NoiseRho, o.NoiseStd);
end

%% --- 5. ACC1B-like low-pass on the OBSERVED series only ---
filterCoef = [];
if o.FilterObs
    fs = 1/o.DtObs;
    filterCoef = crnFilter(fs, 'Cutoff', o.Cutoff, 'NumConv', 5);
    for j = 1:3
        Yobs(:,j) = zeroPhase(Yobs(:,j), filterCoef);
    end
end

%% --- 6. glitch spikes (added AFTER filtering, as real ACC glitches are) ---
glitchIdx = [];
if o.NumGlitches > 0
    glitchIdx = randi(numel(tObsFull), o.NumGlitches, 1);
    for k = 1:o.NumGlitches
        j = randi(3);
        Yobs(glitchIdx(k), j) = Yobs(glitchIdx(k), j) + ...
            o.GlitchAmp * o.NoiseStd * sign(randn);
    end
end

%% --- 7. cut gaps ---
keep = true(numel(tObsFull),1);
gapIntervals = zeros(o.NumGaps, 2);
for k = 1:o.NumGaps
    g0 = (0.15 + 0.25*(k-1)) * o.Duration;
    g1 = g0 + o.GapLen;
    gapIntervals(k,:) = [g0, g1];
    keep(tObsFull >= g0 & tObsFull <= g1) = false;
end

tObs = tObsFull(keep);
Yobs = Yobs(keep, :);

%% --- truth ---
truth.S = S;
truth.R = R;
truth.U = U;
truth.scales = o.Scales(:);
truth.anglesUrad = o.MisalignUrad(:);
truth.nonOrtho = o.NonOrtho(:);
truth.biasFun = biasFun;
truth.biasAtObs = biasAtObs(keep, :);
truth.noiseRho = o.NoiseRho;
truth.noiseStd = o.NoiseStd;
truth.filterCoef = filterCoef;
truth.gapIntervals = gapIntervals;
truth.glitchIdx = glitchIdx;
truth.opts = o;

end

% ===================================================================
function Y = forceModel(t, Torb)
%FORCEMODEL  A plausible non-gravitational acceleration: drag with a
%   slowly varying (storm-like) amplitude, plus SRP-like terms gated by
%   eclipse, with once- and twice-per-rev structure.
w = 2*pi/Torb;

% drag amplitude wanders slowly (a geomagnetic "storm" mid-arc)
dragAmp = 1 + 0.8*exp(-((t - 0.55*max(t)) / (0.08*max(t))).^2);

% eclipse gate: SRP off for part of each revolution
sunlit = double(sin(w*t) > -0.3);

Y = [ ...
    dragAmp .* (1.0 + 0.35*sin(w*t) + 0.15*sin(2*w*t)), ...            % along-track drag
    sunlit  .* (0.25*cos(w*t) + 0.10*cos(2*w*t)) + 0.05*sin(w*t), ...  % cross-track
    sunlit  .* (0.40 + 0.20*sin(2*w*t + 0.5)) ];                       % radial-ish SRP
end

% -------------------------------------------------------------------
function R = expmSkew(W)
%EXPMSKEW  Rodrigues exponential of a 3x3 skew matrix (exactly orthogonal).
th = sqrt(W(3,2)^2 + W(1,3)^2 + W(2,1)^2);
if th < 1e-12
    R = eye(3) + W;
    [Q,~] = qr(R); R = Q * diag(sign(diag(Q)));  % re-orthogonalize
    return;
end
R = eye(3) + (sin(th)/th)*W + ((1-cos(th))/th^2)*(W*W);
end

% -------------------------------------------------------------------
function e = ar1Noise(n, rho, sigma)
e = zeros(n,1);
w = sigma * randn(n,1);
for k = 2:n
    e(k) = rho*e(k-1) + w(k);
end
end

% -------------------------------------------------------------------
function y = zeroPhase(x, h)
h = h(:);
L = numel(h);
npad = min(3*L, numel(x)-1);
xp = [2*x(1) - flipud(x(2:npad+1)); x; 2*x(end) - flipud(x(end-npad:end-1))];
y1 = filter(h, 1, xp);
y1 = flipud(filter(h, 1, flipud(y1)));
y = y1(npad+1 : npad+numel(x));
end
