function fit = glsLinearFit(X, y, varargin)
%GLSLINEARFIT  Linear fit with an AR noise model, honest covariance, and
%   optional ridge/roughness penalty. The workhorse estimator of the
%   toolbox.
%
%   fit = glsLinearFit(X, y)
%   fit = glsLinearFit(X, y, 'Name', Value, ...)
%
%   Procedure (iterated feasible GLS):
%     1. Fit by OLS (or IRLS if 'Robust') to get residuals.
%     2. Fit an AR(p) model to those residuals (ESTIMATENOISEMODEL).
%     3. Prewhiten BOTH X and y with that AR filter (PREWHITENSERIES).
%     4. Refit on the whitened system. Repeat 2-4 'NumIter' times.
%   The final coefficients are unbiased and the reported covariance is
%   computed on the whitened system, so its sigmas are not corrupted by
%   residual autocorrelation.
%
%   NAME-VALUE
%     'Robust'    (true)  IRLS bisquare inner fit (ROBUSTLINEARFIT)
%     'NoiseModel'(true)  estimate + apply the AR whitening filter. Set
%                         false to get a plain OLS/IRLS fit.
%     'MaxAROrder'(10)
%     'NumIter'   (2)     feasible-GLS iterations
%     'Penalty'   ([])    p x p penalty matrix (see DIFFPENALTYMATRIX)
%     'Lambda'    (0)     penalty weight
%
%   OUTPUT (struct)
%     .coef        px1 coefficients
%     .cov         pxp covariance, computed on the whitened system.
%                  For a penalized fit this is the "sandwich"
%                  A^-1 X'X A^-1 * sigma2 with A = X'X + lambda*P, which
%                  correctly ignores the (deterministic) penalty bias.
%     .sigma       px1 formal standard errors, sqrt(diag(cov))
%     .noiseModel  ESTIMATENOISEMODEL output for the final residuals
%     .residuals   raw (un-whitened) residuals, y - X*coef
%     .fitted      X*coef
%     .RSS, .R2
%     .edf         effective dof, trace(hat) (equals p when Lambda == 0)
%     .sigmaInflation  ratio of these sigmas to the naive iid-OLS sigmas.
%                  A value of ~5 means naive error bars were 5x too
%                  small. In a reference AR(1) rho=0.95 experiment the
%                  block-bootstrap inflation was 5.5-6.5x.
%
%   NOTE  Even these sigmas assume the AR model captures the residual
%   correlation. For a fully assumption-light interval, use BLOCKBOOTSTRAP.
%
%   See also ESTIMATENOISEMODEL, PREWHITENSERIES, ROBUSTLINEARFIT,
%            BLOCKBOOTSTRAP.

ip = inputParser;
ip.addParameter('Robust', true, @islogical);
ip.addParameter('NoiseModel', true, @islogical);
ip.addParameter('MaxAROrder', 10, @isnumeric);
ip.addParameter('NumIter', 2, @isnumeric);
ip.addParameter('Penalty', [], @(x) isempty(x) || ismatrix(x));
ip.addParameter('Lambda', 0, @isnumeric);
ip.parse(varargin{:});
opt = ip.Results;

y = y(:);
n = numel(y);
p = size(X,2);

P = opt.Penalty;
if isempty(P), P = zeros(p); end
lam = opt.Lambda;

%% --- step 1: initial fit on the raw system ---
coef = penalizedFit(X, y, P, lam, opt.Robust);

%% --- naive iid sigmas, kept for the inflation diagnostic ---
rNaive = y - X*coef;
s2Naive = (rNaive'*rNaive) / max(n - p, 1);
Anaive = X'*X + lam*P;
covNaive = s2Naive * safeInv(Anaive);
sigmaNaive = sqrt(max(diag(covNaive), 0));

%% --- steps 2-4: feasible GLS iterations ---
phi = zeros(0,1);
if opt.NoiseModel
    for it = 1:opt.NumIter
        r = y - X*coef;
        nm = estimateNoiseModel(r, 'MaxOrder', opt.MaxAROrder);
        phi = nm.phi;
        if isempty(phi)
            break;
        end
        Xw = prewhitenSeries(X, phi);
        yw = prewhitenSeries(y, phi);
        coef = penalizedFit(Xw, yw, P, lam, opt.Robust);
    end
end

%% --- covariance on the whitened system ---
if isempty(phi)
    Xe = X; ye = y;
else
    Xe = prewhitenSeries(X, phi);
    ye = prewhitenSeries(y, phi);
end
ne = numel(ye);
re = ye - Xe*coef;

A = Xe'*Xe + lam*P;
Ainv = safeInv(A);
H = Ainv * (Xe'*Xe);
edf = trace(H);
s2 = (re'*re) / max(ne - edf, 1);
covMat = s2 * (Ainv * (Xe'*Xe) * Ainv);   % sandwich; = s2*inv(X'X) if lam==0
covMat = (covMat + covMat')/2;

sigma = sqrt(max(diag(covMat), 0));

%% --- outputs on the ORIGINAL (un-whitened) scale ---
fitted = X*coef;
resid = y - fitted;
RSS = resid'*resid;
SST = sum((y - mean(y)).^2);

fit.coef = coef;
fit.cov = covMat;
fit.sigma = sigma;
fit.noiseModel = estimateNoiseModel(resid, 'MaxOrder', opt.MaxAROrder);
fit.residuals = resid;
fit.fitted = fitted;
fit.RSS = RSS;
fit.R2 = 1 - RSS/max(SST, eps);
fit.edf = edf;
fit.phi = phi;
fit.lambda = lam;
fit.sigmaNaive = sigmaNaive;
fit.sigmaInflation = sigma ./ max(sigmaNaive, realmin);

end

% -------------------------------------------------------------------
function coef = penalizedFit(X, y, P, lam, robust)
if lam == 0 && ~robust
    coef = X \ y;
elseif lam == 0 && robust
    coef = robustLinearFit(X, y);
elseif ~robust
    coef = (X'*X + lam*P) \ (X'*y);
else
    % robust + penalized: IRLS with the penalty inside each weighted solve
    coef = robustLinearFit(X, y, 'Penalty', P, 'Lambda', lam);
end
end

% -------------------------------------------------------------------
function Ai = safeInv(A)
A = (A + A')/2;
[R, flag] = chol(A);
if flag == 0
    Ai = R \ (R' \ eye(size(A,1)));
else
    Ai = pinv(A);
end
Ai = (Ai + Ai')/2;
end
