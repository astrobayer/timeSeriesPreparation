function W = prewhitenSeries(Y, phi)
%PREWHITENSERIES  Apply an AR(p) whitening filter to each column of Y.
%
%   W = prewhitenSeries(Y, phi)
%
%   Applies  w_t = y_t - sum_{k=1..p} phi_k * y_{t-k}  down each column.
%   The first p rows have no full history and are dropped, so
%   size(W,1) == size(Y,1) - p.
%
%   Applying the SAME filter to both the response and every column of the
%   design matrix turns a GLS problem with AR(p) errors into an ordinary
%   least-squares problem with (approximately) white errors -- after
%   which formal sigmas, t-tests, AIC/BIC and GCV become meaningful
%   again. Whitening only the response is a common and serious error: it
%   changes the estimand rather than the noise model.
%
%   INPUT
%     Y   : N x M matrix (a response vector, or a whole design matrix)
%     phi : p x 1 AR coefficients (from ESTIMATENOISEMODEL). Empty or
%           zero-length => Y returned unchanged.
%
%   OUTPUT
%     W : (N-p) x M whitened matrix
%
%   Example
%     nm = estimateNoiseModel(resid);
%     Xw = prewhitenSeries(X, nm.phi);
%     yw = prewhitenSeries(y, nm.phi);
%     coef = Xw \ yw;
%
%   See also ESTIMATENOISEMODEL, GLSLINEARFIT.

if isempty(phi)
    W = Y;
    return;
end

phi = phi(:);
p = numel(phi);
[n, m] = size(Y);

if n <= p
    error('prewhitenSeries:tooShort', ...
        'Series length (%d) must exceed the AR order (%d).', n, p);
end

W = zeros(n-p, m);
for t = (p+1):n
    lagged = Y(t-(1:p), :);            % p x m, row k = y_{t-k}
    W(t-p, :) = Y(t,:) - phi' * lagged;
end

end
