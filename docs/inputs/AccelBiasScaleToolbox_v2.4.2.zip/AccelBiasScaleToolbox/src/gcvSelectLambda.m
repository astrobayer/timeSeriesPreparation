function [lambdaOpt, out] = gcvSelectLambda(X, y, P, lambdaGrid)
%GCVSELECTLAMBDA  Choose a penalized-regression smoothing parameter by
%   generalized cross-validation (GCV).
%
%   [lambdaOpt, out] = gcvSelectLambda(X, y, P)
%   [lambdaOpt, out] = gcvSelectLambda(X, y, P, lambdaGrid)
%
%   Solves  coef(lambda) = (X'X + lambda*P) \ (X'y)  over a grid and
%   minimizes
%       GCV(lambda) = n * RSS(lambda) / (n - edf(lambda))^2,
%   where edf = trace(hat matrix) is the effective number of parameters.
%
%   This replaces discrete knot-count selection with one continuous
%   smoothness parameter: build a deliberately over-rich spline basis and
%   let GCV decide how much of it to use. It avoids the (arbitrary,
%   unstable) choice of numInteriorKnots.
%
%   CAVEAT -- GCV assumes independent residuals. With autocorrelated
%   residuals (the norm for smooth accelerometer series) GCV
%   systematically UNDER-smooths, because it mistakes correlated noise
%   for signal. Prewhiten first (see ESTIMATENOISEMODEL / PREWHITENSERIES)
%   or select via BLOCKEDCROSSVAL, which is robust to this.
%
%   INPUT
%     X          : n x p design matrix
%     y          : n x 1 response
%     P          : p x p penalty matrix (see DIFFPENALTYMATRIX). Only the
%                  penalized block need be nonzero; unpenalized columns
%                  (e.g. scale terms) get zero rows/cols.
%     lambdaGrid : vector of candidate lambdas (default logspace(-6,6,61))
%
%   OUTPUT
%     lambdaOpt : minimizing lambda
%     out.gcv    : GCV value per grid point
%     out.edf    : effective dof per grid point
%     out.coef   : coefficients at lambdaOpt
%     out.edfOpt : effective dof at lambdaOpt
%     out.grid   : the lambda grid used
%
%   Reference check: on a smooth truth + white noise with an over-rich
%   34-parameter basis, GCV selected edf = 13.4 and achieved RMSE 0.0075
%   against the truth, versus 0.0125 for the unpenalized fit.
%
%   See also DIFFPENALTYMATRIX, BLOCKEDCROSSVAL, BUILDBIASDESIGN.

if nargin < 4 || isempty(lambdaGrid)
    lambdaGrid = logspace(-6, 6, 61);
end

y = y(:);
n = numel(y);
XtX = X'*X;
Xty = X'*y;

nG = numel(lambdaGrid);
gcv = inf(nG,1);
edf = nan(nG,1);
coefAll = nan(size(X,2), nG);

for i = 1:nG
    A = XtX + lambdaGrid(i)*P;
    % symmetric solve; fall back to pinv if numerically singular
    [R, flag] = chol((A+A')/2);
    if flag == 0
        coef = R \ (R' \ Xty);
        H = R \ (R' \ XtX);
    else
        Ai = pinv((A+A')/2);
        coef = Ai * Xty;
        H = Ai * XtX;
    end
    e = trace(H);
    r = y - X*coef;
    rss = r'*r;
    denom = (n - e)^2;
    if denom > eps
        gcv(i) = n * rss / denom;
    end
    edf(i) = e;
    coefAll(:,i) = coef;
end

[~, iOpt] = min(gcv);
lambdaOpt = lambdaGrid(iOpt);

out.gcv = gcv;
out.edf = edf;
out.coef = coefAll(:,iOpt);
out.edfOpt = edf(iOpt);
out.grid = lambdaGrid(:);

end
