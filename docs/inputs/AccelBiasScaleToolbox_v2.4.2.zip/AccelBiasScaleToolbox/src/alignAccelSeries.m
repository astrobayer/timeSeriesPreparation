function [tA, Y1A, Y2A, alignInfo] = alignAccelSeries(t1, Y1, t2, Y2, varargin)
%ALIGNACCELSERIES  Resample series 2 onto the epochs of series 1, keeping
%   only epochs where series 2 genuinely has nearby data.
%
%   [tA, Y1A, Y2A, alignInfo] = alignAccelSeries(t1, Y1, t2, Y2)
%   [...] = alignAccelSeries(t1, Y1, t2, Y2, interpMethod, maxInterpGap)
%   [...] = alignAccelSeries(..., 'Name', Value, ...)
%
%   Alignment is JOINT across axes: an epoch is kept only if every column
%   of Y2 is valid there. This is required as soon as the fit mixes axes
%   (off-diagonal scale terms), since all modeled components must exist at
%   the same retained epoch.
%
%   INPUT
%     t1, Y1 : Nx1 epochs, NxM values (series 1, e.g. observed)
%     t2, Y2 : Kx1 epochs, KxM values (series 2, e.g. modeled)
%
%   NAME-VALUE (or positional, for backward compatibility)
%     'InterpMethod' ('pchip')  interpolation used to place Y2 on t1.
%                    'linear' ATTENUATES amplitude: it chords across each
%                    sample interval, which acts as an additional
%                    low-pass and shrinks the modeled signal slightly.
%                    That shrinkage is absorbed directly by the SCALE
%                    parameter, biasing it low by an amount that depends
%                    on the sampling ratio. 'pchip' or 'spline' preserve
%                    amplitude far better and are the right default.
%                    Best of all: evaluate the force model directly at the
%                    observation epochs and skip interpolation entirely.
%     'MaxInterpGap' ([])  max distance from a t1 epoch to the nearest t2
%                    sample for that epoch to be retained. Default
%                    3*median(diff(t1)). Prevents the interpolator from
%                    fabricating values across data holes.
%
%   OUTPUT
%     tA, Y1A, Y2A : the aligned, gap-screened triple
%     alignInfo    : .nCommonSamples, .droppedFraction, .maxInterpGap,
%                    .interpMethod
%
%   The nearest-neighbour screen is O(N+K) (a single 'nearest'
%   interpolation), not the O(N*K) pairwise scan an explicit loop would
%   give -- which matters: a day of 1 Hz data against a 10 s model grid is
%   ~7e9 distance evaluations the naive way.
%
%   See also ACCELSERIESPREFLIGHT, FILTERCONSISTENCY.

% --- accept both positional (legacy) and name-value forms ---
interpMethod = 'pchip';
maxInterpGap = [];
if numel(varargin) >= 1 && ischar(varargin{1}) && ...
        any(strcmpi(varargin{1}, {'linear','pchip','spline','nearest','makima'}))
    interpMethod = varargin{1};
    if numel(varargin) >= 2
        maxInterpGap = varargin{2};
    end
else
    ip = inputParser;
    ip.addParameter('InterpMethod', 'pchip', @ischar);
    ip.addParameter('MaxInterpGap', [], @(x) isempty(x) || isnumeric(x));
    ip.parse(varargin{:});
    interpMethod = ip.Results.InterpMethod;
    maxInterpGap = ip.Results.MaxInterpGap;
end

t1 = t1(:); t2 = t2(:);
if isvector(Y1), Y1 = Y1(:); end
if isvector(Y2), Y2 = Y2(:); end

dt1 = median(diff(t1));
if isempty(maxInterpGap)
    maxInterpGap = 3*dt1;
end

%% --- resample series 2 onto t1 ---
Y2_on_t1 = interp1(t2, Y2, t1, interpMethod, NaN);

% Newer MATLAB (R2026a+) interp1 silently ignores NaNs in the source data
% and interpolates ACROSS them, so a NaN in Y2 no longer propagates into
% Y2_on_t1 and the affected epoch would be kept. Propagate source invalidity
% explicitly: an interpolated epoch is only valid if the source samples it
% draws from are finite. We resample a per-column finiteness mask with
% 'linear' + 'extrap' and require it to stay ~1 (any contribution from a NaN
% source sample drops it below 1).
srcFinite = double(isfinite(Y2));
maskOnT1 = interp1(t2, srcFinite, t1, 'linear', 0);
sourceOK = maskOnT1 >= 1 - 1e-9;               % NxM, false where a NaN leaked in
Y2_on_t1(~sourceOK) = NaN;

%% --- nearest-neighbour distance, O(N+K) ---
% interp1 with 'nearest' maps each t1 epoch to the VALUE of the nearest t2
% epoch; feeding t2 as its own value therefore returns that epoch, and the
% distance follows. 'extrap' ensures epochs outside the t2 span still get
% their nearest neighbour (which will then correctly exceed the gap limit).
nearestT2 = interp1(t2, t2, t1, 'nearest', 'extrap');
nearestDt = abs(t1 - nearestT2);

validRow = all(isfinite(Y2_on_t1), 2) & all(isfinite(Y1), 2) & (nearestDt <= maxInterpGap);

tA  = t1(validRow);
Y1A = Y1(validRow, :);
Y2A = Y2_on_t1(validRow, :);

alignInfo.nCommonSamples = nnz(validRow);
alignInfo.droppedFraction = 1 - nnz(validRow)/max(numel(t1),1);
alignInfo.maxInterpGap = maxInterpGap;
alignInfo.interpMethod = interpMethod;
alignInfo.validRow = validRow;

end
