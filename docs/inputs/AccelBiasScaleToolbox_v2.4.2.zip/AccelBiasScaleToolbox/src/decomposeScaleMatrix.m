function d = decomposeScaleMatrix(S, covS)
%DECOMPOSESCALEMATRIX  Split a fitted scale/coupling matrix into physically
%   meaningful parts by polar decomposition:  S = R * U.
%
%   d = decomposeScaleMatrix(S)
%   d = decomposeScaleMatrix(S, covS)
%
%   A dense 3x3 scale matrix is hard to interpret and its individual
%   off-diagonal entries are usually strongly correlated (the three
%   modeled acceleration components share the orbital period and are far
%   from independent). The polar decomposition separates the two distinct
%   physical error sources that a dense S conflates:
%
%     R : orthogonal, det(R) = +1 -- a pure ROTATION. This is frame
%         MISALIGNMENT: the accelerometer sensitive axes are not exactly
%         where the force model thinks they are (SRF/ACC frame error,
%         quaternion latency, mounting error). It carries no scale
%         information.
%
%     U : symmetric positive-definite -- a pure STRETCH. Its diagonal is
%         the per-axis SCALE FACTOR; its off-diagonal entries are
%         NON-ORTHOGONALITY of the sensitive axes. It carries no rotation.
%
%   Reporting misalignment angles and scale factors separately is far more
%   diagnostic than reporting six correlated matrix entries: a pure
%   misalignment shows up as R != I with U ~ diag(1,1,1), whereas a
%   density/Cd error shows up as U(1,1) != 1 with R ~ I.
%
%   INPUT
%     S    : 3x3 (or MxM) fitted scale matrix. NaN entries (unestimated,
%            e.g. under a sparsity mask) are replaced by the corresponding
%            identity entry before decomposition, and flagged in
%            d.hadMissing.
%     covS : (optional) covariance of vec(S) -- if supplied, misalignment
%            angle uncertainties are propagated by a first-order (linear)
%            approximation. Omit if unavailable.
%
%   OUTPUT (struct)
%     .R              rotation (misalignment) matrix
%     .U              symmetric stretch (scale + non-orthogonality)
%     .anglesRad      3x1 small misalignment angles from the skew part of
%                     R, [about-x; about-y; about-z] (valid for small
%                     angles, which is the regime of interest)
%     .anglesUrad     the same, in microradians
%     .scales         diag(U) -- the per-axis scale factors
%     .nonOrtho       [U(1,2); U(1,3); U(2,3)] -- non-orthogonality terms
%     .anglesSigmaUrad  angle uncertainties (only if covS supplied)
%     .isProper       true if det(R) > 0 (a proper rotation, not a
%                     reflection). A reflection means S is badly
%                     conditioned or the fit is degenerate -- treat the
%                     decomposition as meaningless and investigate.
%     .condS          cond(S); large values mean the modeled axes are
%                     nearly collinear over this arc, so the off-diagonal
%                     terms are poorly determined regardless of their
%                     fitted values.
%     .hadMissing     true if NaN entries were substituted
%
%   Validated against an independent Python reference (scipy.linalg.polar):
%   for a synthetic S = R_true * U_true with 2000/-1000/1500 urad
%   misalignment, both R and U were recovered to ~1e-15 and the angles to
%   0.01 urad.
%
%   See also ACCELBIASSCALEMODELFIT.

m = size(S,1);
if size(S,2) ~= m
    error('decomposeScaleMatrix:notSquare', 'S must be square.');
end

d.hadMissing = any(~isfinite(S(:)));
if d.hadMissing
    I = eye(m);
    S(~isfinite(S)) = I(~isfinite(S));
end

%% --- polar decomposition S = R*U via the SVD ---
[Usvd, Sig, Vsvd] = svd(S);
R = Usvd * Vsvd';
U = Vsvd * Sig * Vsvd';
U = (U + U')/2;    % enforce exact symmetry

d.R = R;
d.U = U;
d.isProper = det(R) > 0;
d.condS = cond(S);

%% --- small-angle extraction from the skew part of R ---
W = 0.5*(R - R');
if m == 3
    angles = [W(3,2); W(1,3); W(2,1)];
else
    angles = [];
end
d.anglesRad = angles;
d.anglesUrad = angles * 1e6;

d.scales = diag(U);
if m == 3
    d.nonOrtho = [U(1,2); U(1,3); U(2,3)];
else
    d.nonOrtho = [];
end

%% --- optional first-order angle uncertainty propagation ---
d.anglesSigmaUrad = [];
if nargin > 1 && ~isempty(covS) && m == 3
    % angles are linear in the skew part of S to first order about S = I:
    %   w = vee(skew(S)) = 0.5 * [S32-S23; S13-S31; S21-S12]
    % Build the Jacobian of w wrt vec(S) (column-major, MATLAB order).
    J = zeros(3, 9);
    idx = @(i,j) (j-1)*3 + i;   % column-major index into vec(S)
    J(1, idx(3,2)) =  0.5;  J(1, idx(2,3)) = -0.5;
    J(2, idx(1,3)) =  0.5;  J(2, idx(3,1)) = -0.5;
    J(3, idx(2,1)) =  0.5;  J(3, idx(1,2)) = -0.5;
    covW = J * covS * J';
    d.anglesSigmaUrad = sqrt(max(diag(covW), 0)) * 1e6;
end

end
