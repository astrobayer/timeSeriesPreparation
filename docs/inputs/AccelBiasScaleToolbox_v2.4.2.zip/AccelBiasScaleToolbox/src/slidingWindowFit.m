function sw = slidingWindowFit(tA, y1A, y2A, windowLength, overlap, varargin)
%SLIDINGWINDOWFIT  Windowed bias/scale preview, with observability gating.
%
%   sw = slidingWindowFit(tA, y1A, y2A, windowLength, overlap)
%   sw = slidingWindowFit(..., 'Name', Value, ...)
%
%   Fits  y1 = bias + scale * y2  independently in each window, to show
%   how bias and scale would vary if the full adjustment were run at that
%   time resolution -- cheaply, before paying for the real estimation.
%
%   TWO THINGS THIS DOES THAT A NAIVE WINDOWED FIT DOES NOT:
%
%   1. DEMEANS the regressor within each window (option 'Demean', default
%      true). With a nonzero-mean drag signal the bias and scale columns
%      are strongly correlated by construction, so their estimates
%      anticorrelate and scale looks far noisier than it is. Centering
%      orthogonalizes them. The reported bias is mapped back to the
%      original (uncentered) parameterization, so it remains comparable
%      across windows.
%
%   2. REFUSES TO REPORT an unidentifiable scale (option 'GateObservable',
%      default true). In a quiet window y2 is nearly constant and scale is
%      not determinable at all; least squares still returns a number, but
%      it is an arbitrary point in a flat valley. Such windows get NaN and
%      are counted in .nUnobservable, instead of contaminating .scaleStd
%      with meaningless scatter. See SCALEOBSERVABILITY.
%
%   NAME-VALUE
%     'Demean'         (true)
%     'GateObservable' (true)
%     'Robust'         (true)   IRLS bisquare inner fit
%     'MinPts'         (10)     minimum samples for a window to be fit
%
%   OUTPUT (struct)
%     .tWindow, .bias, .scale, .nPts
%     .observable     logical per window
%     .biasScaleCorr  bias/scale estimate correlation per window
%     .relRange       regressor dynamic range per window
%     .scaleStd, .biasStd  std over OBSERVABLE windows only
%     .nUnobservable  count of windows where scale was not identifiable.
%                     If this is a large fraction, a wildly varying scale
%                     in your full adjustment is an estimation artifact,
%                     not physics.
%
%   See also SCALEOBSERVABILITY, ROBUSTLINEARFIT, ACCELSERIESPREFLIGHT.

ip = inputParser;
ip.addParameter('Demean', true, @islogical);
ip.addParameter('GateObservable', true, @islogical);
ip.addParameter('Robust', true, @islogical);
ip.addParameter('MinPts', 10, @isnumeric);
ip.parse(varargin{:});
opt = ip.Results;

tA = tA(:); y1A = y1A(:); y2A = y2A(:);

sw = emptyResult();
if isempty(tA), return; end

span = tA(end) - tA(1);
if span <= 0 || windowLength <= 0, return; end

step = windowLength * (1 - overlap);
if step <= 0
    error('slidingWindowFit:badOverlap', 'overlap must be < 1.');
end

starts = tA(1) : step : (tA(end) - windowLength);
if isempty(starts)
    starts = tA(1);
end

nW = numel(starts);
[tWindow, biasW, scaleW, nPts, corrW, rangeW] = deal(nan(nW,1));
obsW = false(nW,1);

for w = 1:nW
    idx = tA >= starts(w) & tA < starts(w) + windowLength;
    nPts(w) = nnz(idx);
    if nPts(w) < opt.MinPts
        continue;
    end

    yy1 = y1A(idx);
    yy2 = y2A(idx);

    ob = scaleObservability(yy2, 'Demean', opt.Demean);
    obsW(w) = ob.observable;
    corrW(w) = ob.biasScaleCorr;
    rangeW(w) = ob.relRange;
    tWindow(w) = starts(w) + windowLength/2;

    if opt.GateObservable && ~ob.observable
        continue;      % leave bias/scale as NaN: refuse to invent a number
    end

    % centering the regressor decorrelates bias from scale
    mu = 0;
    if opt.Demean
        mu = mean(yy2);
    end
    X = [ones(nPts(w),1), yy2 - mu];

    if opt.Robust
        coef = robustLinearFit(X, yy1);
    else
        coef = X \ yy1;
    end

    scaleW(w) = coef(2);
    % map the centered intercept back to the uncentered parameterization
    biasW(w) = coef(1) - coef(2)*mu;
end

sw.tWindow = tWindow;
sw.bias = biasW;
sw.scale = scaleW;
sw.nPts = nPts;
sw.observable = obsW;
sw.biasScaleCorr = corrW;
sw.relRange = rangeW;
sw.windowLength = windowLength;
sw.nUnobservable = nnz(~obsW & nPts >= opt.MinPts);
sw.nWindows = nW;

valid = isfinite(scaleW);
if nnz(valid) > 3
    sw.scaleStd = std(scaleW(valid));
    sw.biasStd  = std(biasW(valid));
end

end

% -------------------------------------------------------------------
function sw = emptyResult()
sw = struct('tWindow',[],'bias',[],'scale',[],'nPts',[], ...
    'observable',[],'biasScaleCorr',[],'relRange',[], ...
    'windowLength',NaN,'scaleStd',NaN,'biasStd',NaN, ...
    'nUnobservable',0,'nWindows',0);
end
