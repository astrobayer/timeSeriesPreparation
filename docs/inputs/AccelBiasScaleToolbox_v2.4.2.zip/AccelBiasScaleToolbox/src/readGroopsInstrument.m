function [time, data, aux] = readGroopsInstrument(fileName)
%READGROOPSINSTRUMENT  Read a GROOPS instrument-format ASCII file.
%
%   [TIME, DATA, AUX] = READGROOPSINSTRUMENT(FILENAME) reads a GROOPS
%   "instrument" ASCII export (e.g. a modeled non-gravitational
%   acceleration series). These files have the structure:
%
%       groops instrument version=YYYYMMDD
%       # <TYPE NAME>                       (e.g. ACCELEROMETER)
%       <typeId>  <someInt>                 (a type/dimension line)
%       # Time [MJD]  data0: ...  data1: ...
%       # =========================================
%       <numRecords>
%       <mjd>  <col0>  <col1>  <col2> ...
%       ...
%
%   The first data column is time in MJD; the remaining columns are the
%   instrument data values. Comment lines start with '#'; the lone
%   integer line just before the records is the record count.
%
%   INPUT
%     fileName - char/string, scalar. Path to a GROOPS instrument ASCII
%                file. Must exist.
%
%   OUTPUT
%     time - double, [N x 2]. To match READGRACEFOL1B's convention,
%            column 1 is the integer MJD and column 2 is seconds of day
%            (0 <= secOfDay < 86400), derived from the fractional MJD.
%            NOTE: the GROOPS MJD time system as written is whatever the
%            producer used (typically GPS or a continuous MJD); this
%            routine does not apply any leap-second correction. Time-
%            system reconciliation against the observation is handled by
%            the caller (see ANALYZEACCSCALEARC), which aligns on the UTC
%            day boundary.
%     data - double, [N x D]. The D data columns (e.g. D=3 for x,y,z
%            accelerations in m/s^2), in file column order.
%     aux  - struct with fields:
%              .fileName     - the input path
%              .type         - char, the instrument type (e.g.
%                              'ACCELEROMETER'), from the 2nd header line
%              .version      - char, the GROOPS format version string
%              .columnNames  - cellstr, [1 x D], parsed from the
%                              "# Time [MJD] data0: x ..." description
%                              line where available, else {'data0',...}
%              .mjdRaw       - double, [N x 1], the original fractional
%                              MJD column, unmodified
%              .numRecordsHeader - double, declared record count (NaN if
%                              absent)
%              .numRecordsActual - double, records actually read
%
%   EXAMPLE
%     [t, a, aux] = readGroopsInstrument('GRACEFO-1_nonConservative.txt');
%     plot(t(:,2), a(:,1))   % modeled along-track accel vs seconds of day
%
%   See also READGRACEFOL1B, ANALYZEACCSCALEARC.

if nargin < 1 || isempty(fileName)
    error('readGroopsInstrument:noFile', 'A file name is required.');
end
fileName = char(fileName);
if exist(fileName, 'file') ~= 2
    error('readGroopsInstrument:notFound', 'File not found: %s', fileName);
end

fid = fopen(fileName, 'rt');
if fid < 0
    error('readGroopsInstrument:openFailed', 'Could not open %s', fileName);
end
cleaner = onCleanup(@() fclose(fid));

version = '';
typeName = '';
columnNames = {};
numRecordsHeader = NaN;

rawMJD = [];
dataRows = {};

readingData = false;
while true
    tline = fgetl(fid);
    if ~ischar(tline)
        break;
    end
    s = strtrim(tline);
    if isempty(s)
        continue;
    end

    if startsWith(s, 'groops instrument')
        tok = regexp(s, 'version\s*=\s*(\S+)', 'tokens', 'once');
        if ~isempty(tok), version = tok{1}; end
        continue;
    end

    if startsWith(s, '#')
        % type line: "# ACCELEROMETER"
        if isempty(typeName)
            t2 = strtrim(erase(s, '#'));
            if ~isempty(t2) && isempty(regexp(t2, 'Time|=====|data\d', 'once'))
                typeName = t2;
            end
        end
        % column-description line: "# Time [MJD]  data0: x [m/s^2] ..."
        if contains(s, 'data0') || contains(lower(s), 'time [mjd]')
            % capture the "dataK: <name>" labels
            lbl = regexp(s, 'data\d+:\s*([^\[\]]+?)\s*(\[|$|data\d+:)', 'tokens');
            if ~isempty(lbl)
                columnNames = cellfun(@(c) strtrim(c{1}), lbl, 'UniformOutput', false);
            end
        end
        continue;
    end

    % a lone integer just before the records is the count
    if ~readingData
        n = str2double(s);
        parts = regexp(s, '\S+', 'match');
        if numel(parts) == 1 && ~isnan(n) && n == floor(n) && n > 0
            numRecordsHeader = n;
            readingData = true;
            continue;
        end
        % a two-integer type/dim line (e.g. "-8   1"): skip
        if numel(parts) == 2 && all(~isnan(str2double(parts)))
            continue;
        end
    end

    % data record
    vals = sscanf(s, '%f');
    if numel(vals) >= 2
        rawMJD(end+1,1) = vals(1); %#ok<AGROW>
        dataRows{end+1,1} = vals(2:end).'; %#ok<AGROW>
        readingData = true;
    end
end

if isempty(rawMJD)
    error('readGroopsInstrument:noData', 'No data records parsed from %s', fileName);
end

% assemble data matrix (pad/truncate defensively to the modal width)
widths = cellfun(@numel, dataRows);
D = mode(widths);
keep = widths == D;
if ~all(keep)
    warning('readGroopsInstrument:raggedRows', ...
        '%d record(s) in %s did not have the modal column count (%d) and were dropped.', ...
        nnz(~keep), fileName, D);
end
rawMJD = rawMJD(keep);
data = vertcat(dataRows{keep});

% MJD -> [intMJD, secOfDay]
intMJD = floor(rawMJD);
secOfDay = (rawMJD - intMJD) * 86400;
time = [intMJD, secOfDay];

if isempty(columnNames) || numel(columnNames) ~= D
    columnNames = arrayfun(@(k) sprintf('data%d', k-1), 1:D, 'UniformOutput', false);
end

aux = struct();
aux.fileName = fileName;
aux.type = typeName;
aux.version = version;
aux.columnNames = columnNames;
aux.mjdRaw = rawMJD;
aux.numRecordsHeader = numRecordsHeader;
aux.numRecordsActual = numel(rawMJD);

if ~isnan(numRecordsHeader) && numRecordsHeader ~= aux.numRecordsActual
    warning('readGroopsInstrument:recordCountMismatch', ...
        'Header declares %d records but %d were read from %s.', ...
        numRecordsHeader, aux.numRecordsActual, fileName);
end

end
