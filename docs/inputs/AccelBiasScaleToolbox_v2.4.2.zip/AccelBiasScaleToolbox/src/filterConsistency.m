function [yObsOut, yModOut, fc] = filterConsistency(t, yObs, yMod, strategy, varargin)
%FILTERCONSISTENCY  Put an observed (already-filtered) and a modeled
%   (unfiltered) acceleration series into the same spectral band before
%   any bias/scale fit.
%
%   [yObsOut, yModOut, fc] = filterConsistency(t, yObs, yMod, strategy)
%
%   ACC1B has been low-pass filtered and decimated by the Level-1
%   processor; a pointwise-evaluated force model has not. Fitting bias and
%   scale across that mismatch is fitting across a spectral discrepancy,
%   and the broadband excess in the model leaks preferentially into the
%   SCALE parameter. This routine removes the mismatch. It is one of the
%   two highest-leverage corrections in this toolbox (the other being
%   scale observability -- see SCALEOBSERVABILITY).
%
%   INPUT
%     t    : Nx1 uniform (or near-uniform) epochs
%     yObs : Nx1 observed series (assumed ALREADY filtered)
%     yMod : Nx1 modeled series  (assumed UNfiltered)
%
%   STRATEGY -- one of:
%
%     'explicit'    Apply a known CRN filter to the MODEL only, so it
%                   matches the observation. Correct in principle and the
%                   only strategy that preserves the observation's own
%                   band untouched -- but it requires the true ACC1B
%                   filter coefficients. Pass them via 'FilterCoef', or
%                   let CRNFILTER build an approximation (see its warning:
%                   the defaults are NOT the operational filter).
%
%     'commonmode'  Apply the SAME low-pass to BOTH series. Does not
%                   recover the observation's true band, but guarantees
%                   the two series are compared in an identical band,
%                   which is what the fit actually requires. Robust:
%                   it needs no knowledge of the operational filter.
%                   Costs some high-frequency information in the
%                   observation. RECOMMENDED DEFAULT when the exact
%                   ACC1B filter is unknown.
%
%     'empirical'   Estimate the effective magnitude response the L1
%                   processor applied, directly from the data, as
%                   |H(f)| = sqrt(Pobs(f) / Pmod(f)) smoothed across
%                   frequency, and apply it to the model. Requires no
%                   handbook, but ASSUMES the observed/model discrepancy
%                   at each frequency is filtering rather than genuine
%                   force-model error -- so it will happily absorb real
%                   model deficiencies into the "filter". Use it as a
%                   DIAGNOSTIC (inspect fc.Hmag: a clean monotone
%                   low-pass rolloff supports the filter interpretation;
%                   a ragged or >1 response does not), not blindly as a
%                   correction.
%
%     'none'        Pass through unchanged (for A/B comparison).
%
%   NAME-VALUE
%     'Product'    ('ACC')  CRN preset when building a kernel: 'ACC' or 'KBR'
%     'FilterCoef' ([])     FIR coefficients for 'explicit'/'commonmode'.
%                           If empty, CRNFILTER builds the exact ATBD kernel.
%     'Cutoff'     (0.035)  cutoff [Hz] when constructing a filter
%     'NumConv'    (7)      CRN self-convolutions
%     'SmoothBins' (9)      frequency smoothing for the 'empirical' |H(f)|
%
%   OUTPUT
%     yObsOut, yModOut : the filter-consistent pair
%     fc : struct with .strategy, .h (coefficients used), .Hmag/.f
%          (empirical response, if estimated), .fs
%
%   All filtering is ZERO-PHASE (forward-backward). A causal FIR would
%   introduce a group delay that CROSSCORRLAG would then report as a
%   spurious clock offset.
%
%   Reference
%     S.-C. Wu, G. Kruizinga, W. Bertiger, "Algorithm Theoretical Basis
%     Document for GRACE Level-1B Data Processing V1.2", JPL D-27672, 2006.
%
%   See also CRNFILTER, APPLYCRNFILTER, CROSSCORRLAG, ACCELSERIESPREFLIGHT.

ip = inputParser;
ip.addParameter('FilterCoef', [], @(x) isempty(x) || isvector(x));
ip.addParameter('Product', 'ACC', @ischar);
ip.addParameter('Cutoff', 0.035, @isnumeric);
ip.addParameter('NumConv', 7, @isnumeric);
ip.addParameter('SmoothBins', 9, @isnumeric);
ip.parse(varargin{:});
opt = ip.Results;

t = t(:); yObs = yObs(:); yMod = yMod(:);
dt = median(diff(t));
fs = 1/dt;

fc = struct('strategy', lower(strategy), 'h', [], 'Hmag', [], 'f', [], 'fs', fs);

switch lower(strategy)

    case 'none'
        yObsOut = yObs;
        yModOut = yMod;

    case 'explicit'
        h = opt.FilterCoef;
        if isempty(h)
            % the EXACT ACC_1B kernel from the ATBD -- not an approximation
            [h, hInfo] = crnFilter(opt.Product, 'fs', fs);
            fc.crnInfo = hInfo;
        end
        yObsOut = yObs;                       % already filtered by the L1 processor
        yModOut = centredFIR(yMod, h);        % bring the model into the same band
        fc.h = h;

    case 'commonmode'
        h = opt.FilterCoef;
        if isempty(h)
            [h, hInfo] = crnFilter(opt.Product, 'fs', fs);
            fc.crnInfo = hInfo;
        end
        yObsOut = centredFIR(yObs, h);
        yModOut = centredFIR(yMod, h);
        fc.h = h;

    case 'empirical'
        [Hmag, f] = empiricalMagResponse(yObs, yMod, fs, opt.SmoothBins);
        yObsOut = yObs;
        yModOut = applyMagResponse(yMod, Hmag, f, fs);
        fc.Hmag = Hmag;
        fc.f = f;

    otherwise
        error('filterConsistency:badStrategy', ...
            ['strategy must be ''explicit'', ''commonmode'', ' ...
             '''empirical'' or ''none''.']);
end

end

% -------------------------------------------------------------------
function y = centredFIR(x, h)
%CENTREDFIR  Convolution with a SYMMETRIC kernel, applied centred.
%
%   The CRN kernel is symmetric and therefore already exactly linear-phase.
%   Applying it centred removes the group delay exactly. Do NOT use a
%   forward-backward (filtfilt-style) pass here: that would apply the
%   filter TWICE, squaring its magnitude response and roughly doubling the
%   effective attenuation -- which then reappears as a scale-factor bias,
%   the very error this module exists to remove.
h = h(:);
Nh = (numel(h) - 1)/2;
n = numel(x);
np = min(round(Nh), n-1);
if np < 1
    y = x;
    return;
end
xp = [2*x(1) - flipud(x(2:np+1)); x; 2*x(end) - flipud(x(end-np:end-1))];
yFull = conv(xp, h, 'same');
y = yFull(np+1 : np+n);
end

% -------------------------------------------------------------------
function [Hmag, f] = empiricalMagResponse(yObs, yMod, fs, smoothBins)
%EMPIRICALMAGRESPONSE  |H(f)| = sqrt(Pobs/Pmod), smoothed.
n = numel(yObs);
w = hann(n);
Yo = fft(detrend(yObs).*w);
Ym = fft(detrend(yMod).*w);

nHalf = floor(n/2)+1;
Po = abs(Yo(1:nHalf)).^2;
Pm = abs(Ym(1:nHalf)).^2;
f = (0:nHalf-1)' * (fs/n);

Hmag = sqrt(Po ./ max(Pm, max(Pm)*1e-12));

% smooth across frequency (moving average) to tame periodogram variance
k = max(1, round(smoothBins));
Hmag = movmean(Hmag, k);

% a filter cannot amplify; clamp
Hmag = min(Hmag, 1);
Hmag(1) = 1;   % preserve DC gain, else an artificial bias is introduced
end

% -------------------------------------------------------------------
function y = applyMagResponse(x, Hmag, f, fs) %#ok<INUSD>
%APPLYMAGRESPONSE  Zero-phase application of a magnitude-only response.
n = numel(x);
X = fft(x);
nHalf = floor(n/2)+1;

H = Hmag(:);
if numel(H) ~= nHalf
    H = interp1(linspace(0,1,numel(H))', H, linspace(0,1,nHalf)', 'linear', 'extrap');
end

% build the full-length, conjugate-symmetric (=> zero-phase) response
Hfull = zeros(n,1);
Hfull(1:nHalf) = H;
if mod(n,2) == 0
    Hfull(nHalf+1:end) = flipud(H(2:end-1));
else
    Hfull(nHalf+1:end) = flipud(H(2:end));
end

y = real(ifft(X .* Hfull));
end
