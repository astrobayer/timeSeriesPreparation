function [indices, raw] = loadSpaceWeatherIndices(gfzFile, tMid, startMJD, varargin)
%LOADSPACEWEATHERINDICES  Read a GFZ Kp/ap/Ap/SN/F10.7 file and map its
%   space-weather indices onto per-revolution accelerometer windows, ready
%   for SCALEFACTORDIAGNOSTICS.
%
%   [indices, raw] = loadSpaceWeatherIndices(gfzFile, tMid, startMJD)
%   [indices, raw] = loadSpaceWeatherIndices(gfzFile, tMid, startMJD, ...
%                                            'Name', Value, ...)
%   [indices, raw] = loadSpaceWeatherIndices(result, ...)   % result from
%                                                           % ANALYZEACCSCALEARC
%
%   This is the "attach the indices to each per-rev window" glue that the
%   ROADMAP (section 6, step 3) leaves to the user. It parses the combined
%   GFZ daily file
%
%       Kp_ap_Ap_SN_F107_since_1932.txt   (or the _nowcast / yearly files)
%
%   from GFZ Potsdam (https://kp.gfz.de/en/data), whose daily lines carry
%   the 8 three-hourly Kp and ap values plus daily Ap, sunspot number SN,
%   observed F10.7 and adjusted F10.7. Each per-rev window's MID-time is
%   converted to Modified Julian Date via startMJD + tMid/86400 and the
%   indices are sampled there: the 3-hourly Kp/ap by linear interpolation
%   between interval mid-times, the daily F10.7/Ap/SN held across the UT
%   day (nearest, the file's native resolution). An 81-day centred running
%   mean of observed F10.7 (F107a) is computed from the daily series before
%   sampling -- the standard density-driver smoothing.
%
%   The returned INDICES struct plugs straight into SCALEFACTORDIAGNOSTICS;
%   RAW returns the fully parsed daily table so you can inspect, plot, or
%   attach further columns yourself.
%
%   INPUT
%     gfzFile  - char/string path to a GFZ Kp_ap_Ap_SN_F107*.txt file, OR
%                an ANALYZEACCSCALEARC result struct as the FIRST argument
%                (then tMid/startMJD are taken from it and the file path is
%                given via the 'File' name-value pair).
%     tMid     - Rx1 double, per-rev window-center time [s from startMJD]
%                (i.e. result.perRev.tMid). Omit if a result struct is
%                passed first.
%     startMJD - scalar double, integer MJD of the first observed midnight
%                (i.e. result.startMJD). Omit if a result struct is passed.
%
%   NAME-VALUE
%     'File'          ('')    GFZ file path, required only when the first
%                             argument is a result struct
%     'F107aWindowDays' (81)  centred window [days] for the F10.7 average
%     'KpInterp'      ('linear')  interpolation for the 3-hourly Kp/ap
%                             ('linear'|'nearest'|'pchip')
%     'DailyInterp'   ('nearest') sampling for daily F10.7/Ap/SN
%                             ('nearest'|'linear')
%     'UseAdjustedF107' (false) if true, .F107 is the adjusted flux
%                             (F10.7adj, for solar studies); default uses
%                             observed F10.7obs (recommended for
%                             ionospheric/atmospheric/density work)
%     'MissingFill'   ('nan') how to treat the GFZ missing code (-1):
%                             'nan' leaves gaps NaN; 'interp' fills by
%                             time interpolation over valid days first
%     'Fields' ({'F107','F107a','Kp','Ap','Dst','beta','argLat'})
%                             which INDICES fields to populate WHEN present
%                             in the file. Dst/beta/argLat are NOT in the
%                             GFZ file; supply them via 'Extra' (below).
%                             Unlisted-but-derivable fields are skipped.
%     'Extra'         (struct())  a struct of additional per-rev index
%                             vectors (Rx1) to merge into the output, e.g.
%                             Dst from another source, or orbit-geometry
%                             beta/argLat you computed from an orbit file.
%                             These pass through unchanged and override
%                             same-named GFZ-derived fields.
%     'Verbose'       (true)  print a short parse/coverage summary
%
%   OUTPUT
%     indices  - struct of Rx1 per-rev index vectors aligned 1:1 with tMid,
%                each named as SCALEFACTORDIAGNOSTICS expects:
%                  .F107   Rx1  observed (or adjusted) F10.7 [sfu]
%                  .F107a  Rx1  81-day centred mean observed F10.7 [sfu]
%                  .Kp     Rx1  planetary Kp (3-hourly, interpolated)
%                  .Ap     Rx1  daily Ap
%                  .SN     Rx1  daily sunspot number (if requested)
%                  (+ any fields merged from 'Extra', e.g. Dst/beta/argLat)
%                All vectors are numel(tMid) x 1. Windows outside the file's
%                date coverage are NaN.
%     raw      - struct with the parsed daily table and provenance:
%                  .date     Dx1 datetime (UT day, 00:00)
%                  .mjd      Dx1 MJD of UT-day start
%                  .Kp8      Dx8 the eight 3-hourly Kp per day
%                  .ap8      Dx8 the eight 3-hourly ap per day
%                  .Ap       Dx1 daily Ap
%                  .SN       Dx1 sunspot number
%                  .F107obs  Dx1 observed F10.7
%                  .F107adj  Dx1 adjusted F10.7
%                  .F107a    Dx1 81-day centred mean of F107obs
%                  .definitive Dx1 D-flag (0 prelim, 1/2 definitive)
%                  .file     the source path
%                  .nHeader  header lines skipped
%                  .provenance  run time/date, toolbox, Claude version
%
%   COVERAGE / QUALITY
%     * A caveat is printed (and returned in raw.provenance.notes) if any
%       per-rev window falls outside the file's dates, or if requested
%       density indices contain the -1 missing code inside the arc.
%     * The GFZ file is UT-day based; per-rev tMid is anchored on the
%       observed integer-MJD midnight, which is also a UT-day boundary, so
%       the two calendars line up without a leap-second correction (the
%       ~18 s GPS-UTC offset is far below the daily/3-hourly resolution of
%       these indices).
%
%   EXAMPLE
%     r  = analyzeAccScaleArc(obsList, modelList, 'Plot', false);
%     ix = loadSpaceWeatherIndices('Kp_ap_Ap_SN_F107_since_1932.txt', ...
%                                  r.perRev.tMid, r.startMJD);
%     % add orbit geometry you computed elsewhere:
%     ix2 = loadSpaceWeatherIndices(r, 'File', 'Kp_ap_Ap_SN_F107_2020.txt', ...
%                                   'Extra', struct('beta', betaPerRev, ...
%                                                   'argLat', argLatPerRev));
%     d  = scaleFactorDiagnostics(r, ix2);
%
%   See also SCALEFACTORDIAGNOSTICS, ANALYZEACCSCALEARC, READGROOPSINSTRUMENT.
%
%   ---------------------------------------------------------------------
%   Authoring provenance
%     Date      : 2026-07-15
%     Time      : 14:00 UTC
%     Author    : Claude (Anthropic), model Claude Opus 4.8
%     Toolbox   : AccelBiasScaleToolbox
%   GFZ file format: Kp_ap_Ap_SN_F107_format.txt (Matzka et al. 2021,
%   doi:10.1029/2020SW002641). Daily line = Y M D days days_m BSR dB
%   Kp1..8 ap1..8 Ap SN F10.7obs F10.7adj D (28 whitespace fields).
%   Per-run execution time/date is recorded in raw.provenance.
%   ---------------------------------------------------------------------

%% ---- accept a result struct as first argument ----
resultStruct = [];
if isstruct(gfzFile)
    resultStruct = gfzFile;
    if ~isfield(resultStruct, 'perRev') || ~isfield(resultStruct, 'startMJD') ...
            || ~isfield(resultStruct.perRev, 'tMid')
        error('loadSpaceWeatherIndices:badResult', ...
            ['When the first argument is a struct it must be an ' ...
             'ANALYZEACCSCALEARC result with .perRev.tMid and .startMJD.']);
    end
    % In struct-first form the caller passes only name-value pairs after the
    % struct (File=..., etc.). Any positional 2nd/3rd args are not allowed;
    % collect everything from position 2 onward as name-value.
    nv = {};
    if nargin >= 2, nv = [{tMid}, nv]; end          % actually first NV name
    if nargin >= 3, nv = [nv, {startMJD}]; end        % actually first NV value
    nv = [nv, varargin];
    varargin = nv;
    tMid = resultStruct.perRev.tMid(:);
    startMJD = resultStruct.startMJD;
end

ip = inputParser;
ip.addParameter('File', '', @(x) ischar(x) || isstring(x));
ip.addParameter('F107aWindowDays', 81, @isnumeric);
ip.addParameter('KpInterp', 'linear', @ischar);
ip.addParameter('DailyInterp', 'nearest', @ischar);
ip.addParameter('UseAdjustedF107', false, @islogical);
ip.addParameter('MissingFill', 'nan', @ischar);
ip.addParameter('Fields', {'F107','F107a','Kp','Ap','SN'}, @iscell);
ip.addParameter('Extra', struct(), @isstruct);
ip.addParameter('Verbose', true, @islogical);
ip.parse(varargin{:});
opt = ip.Results;

if ~isempty(resultStruct)
    gfzFile = opt.File;
end
gfzFile = char(gfzFile);
if isempty(gfzFile)
    error('loadSpaceWeatherIndices:noFile', ...
        'No GFZ file path supplied (use the first argument or ''File'').');
end
if ~isfile(gfzFile)
    error('loadSpaceWeatherIndices:fileNotFound', ...
        'GFZ file not found: %s', gfzFile);
end
tMid = tMid(:);
R = numel(tMid);
notes = {};

%% ---- parse the GFZ daily file ----
raw = parseGfzDaily(gfzFile);

% 81-day centred running mean of observed F10.7 (density driver smoothing)
raw.F107a = centredRunningMean(raw.F107obs, opt.F107aWindowDays);

%% ---- build daily and 3-hourly timelines in MJD ----
mjdDayStart = raw.mjd(:);                 % UT-day 00:00
mjdDayMid   = mjdDayStart + 0.5;          % UT-day 12:00 (F10.7 noon-ish)

% 3-hourly Kp/ap sample times at interval MID-times: 01:30, 04:30, ... 22:30
hMid = ((0:7)*3 + 1.5) / 24;              % fractional day
D = numel(mjdDayStart);
kpT = reshape(mjdDayStart.' + hMid.', [], 1);      % (8*D) x 1, day-major
kpV = reshape(raw.Kp8.', [], 1);
apV = reshape(raw.ap8.', [], 1);

% apply missing-data policy (GFZ code = -1)
[kpV, notes] = handleMissing(kpV, kpT, opt.MissingFill, 'Kp', notes);
[apV, notes] = handleMissing(apV, kpT, opt.MissingFill, 'ap', notes);
f107obs = raw.F107obs; f107adj = raw.F107adj; Ap = raw.Ap; SN = raw.SN; F107a = raw.F107a;
[f107obs, notes] = handleMissing(f107obs, mjdDayMid, opt.MissingFill, 'F107obs', notes);
[f107adj, notes] = handleMissing(f107adj, mjdDayMid, opt.MissingFill, 'F107adj', notes);
[F107a,   notes] = handleMissing(F107a,   mjdDayMid, opt.MissingFill, 'F107a',   notes);
Ap = nanReplace(Ap, -1); SN = nanReplace(SN, -1);

%% ---- sample onto per-rev window mid-times ----
mjdRev = startMJD + tMid/86400;

% coverage check
outLo = mjdRev < min(mjdDayStart);
outHi = mjdRev > max(mjdDayStart) + 1;    % +1: last UT day extends to next midnight
nOut = nnz(outLo | outHi);
if nOut > 0
    notes{end+1} = sprintf(['%d of %d per-rev window(s) fall outside the GFZ ' ...
        'file date range [%s .. %s]; their indices are NaN. Provide a file ' ...
        'that spans the whole arc.'], nOut, R, ...
        datestr(raw.date(1),'yyyy-mm-dd'), datestr(raw.date(end),'yyyy-mm-dd'));
end

sampKp = interp1safe(kpT, kpV, mjdRev, opt.KpInterp);
sampAp = interp1safe(kpT, apV, mjdRev, opt.KpInterp);   % ap is also 3-hourly
% Daily indices (F10.7, Ap-daily, SN) are one value per UT day. For
% 'nearest' (the default and the physically correct choice) we sample by
% UT-DAY MEMBERSHIP: floor(mjdRev) selects the day the window falls in, and
% the value is held across that whole day -- NOT nearest-to-midday, which
% would flip to the next day's value after 18:00. 'linear' interpolates
% between consecutive UT-day midday knots for a smooth daily proxy.
if strcmpi(opt.DailyInterp, 'linear')
    sampF107obs = interp1safe(mjdDayMid, f107obs, mjdRev, 'linear');
    sampF107adj = interp1safe(mjdDayMid, f107adj, mjdRev, 'linear');
    sampF107a   = interp1safe(mjdDayMid, F107a,   mjdRev, 'linear');
    sampApDay   = interp1safe(mjdDayMid, Ap,      mjdRev, 'linear');
    sampSN      = interp1safe(mjdDayMid, SN,      mjdRev, 'linear');
else
    sampF107obs = sampleByDay(mjdDayStart, f107obs, mjdRev);
    sampF107adj = sampleByDay(mjdDayStart, f107adj, mjdRev);
    sampF107a   = sampleByDay(mjdDayStart, F107a,   mjdRev);
    sampApDay   = sampleByDay(mjdDayStart, Ap,      mjdRev);
    sampSN      = sampleByDay(mjdDayStart, SN,      mjdRev);
end

if opt.UseAdjustedF107
    f107out = sampF107adj;
else
    f107out = sampF107obs;
end

%% ---- assemble the indices struct (only requested/derivable fields) ----
indices = struct();
want = @(nm) any(strcmpi(nm, opt.Fields));
if want('F107'),  indices.F107  = f107out(:);  end
if want('F107a'), indices.F107a = sampF107a(:); end
if want('Kp'),    indices.Kp    = sampKp(:);   end
if want('Ap'),    indices.Ap    = sampApDay(:); end
if want('SN'),    indices.SN    = sampSN(:);   end

% merge user-supplied Extra fields (override same-named GFZ fields)
efn = fieldnames(opt.Extra);
for k = 1:numel(efn)
    v = opt.Extra.(efn{k});
    if numel(v) ~= R
        notes{end+1} = sprintf(['Extra field ''%s'' has %d elements, expected ' ...
            '%d (per-rev); it was NOT merged.'], efn{k}, numel(v), R); %#ok<AGROW>
        continue;
    end
    indices.(efn{k}) = v(:);
end

% missing-density warning inside the arc
if want('F107') && any(isnan(f107out(~(outLo|outHi))))
    notes{end+1} = ['Observed F10.7 has missing values (-1) inside the arc; ' ...
        'affected windows are NaN. Consider MissingFill=''interp''.'];
end

%% ---- provenance ----
runNow = datetime('now');
raw.provenance = struct( ...
    'runDatetime',   char(runNow, 'yyyy-MM-dd HH:mm:ss'), ...
    'runDatenum',    datenum(runNow), ...
    'toolbox',       'AccelBiasScaleToolbox', ...
    'codeAuthored',  '2026-07-15', ...
    'claudeVersion', 'Claude Opus 4.8 (Anthropic)', ...
    'source',        gfzFile, ...
    'formatRef',     'Kp_ap_Ap_SN_F107_format.txt (Matzka et al. 2021)', ...
    'notes',         {notes});

if opt.Verbose
    printSummary(indices, raw, tMid, startMJD, mjdRev, notes);
end

end

% ===================================================================
% helpers
% ===================================================================
function raw = parseGfzDaily(fname)
% Parse the GFZ combined daily file. Header lines start with '#'. Each data
% line has 28 whitespace-separated fields:
%   Y M D days days_m BSR dB Kp1..8 ap1..8 Ap SN F10.7obs F10.7adj D
fid = fopen(fname, 'r');
if fid < 0
    error('loadSpaceWeatherIndices:openFail', 'Cannot open %s', fname);
end
c = onCleanup(@() fclose(fid));

Y=[];Mo=[];Da=[];mjd=[];Kp8=[];ap8=[];Ap=[];SN=[];F107obs=[];F107adj=[];Dfl=[];
nHeader = 0;
while true
    ln = fgetl(fid);
    if ~ischar(ln), break; end
    s = strtrim(ln);
    if isempty(s), continue; end
    if s(1) == '#', nHeader = nHeader + 1; continue; end
    p = sscanf(s, '%f').';
    if numel(p) < 27
        continue;   % skip malformed/short lines
    end
    % daily layout indices (1-based):
    %  1 Y  2 M  3 D  4 days  5 days_m  6 BSR  7 dB
    %  8..15 Kp1..8   16..23 ap1..8   24 Ap  25 SN  26 F107obs  27 F107adj  28 D
    Y(end+1,1)=p(1); Mo(end+1,1)=p(2); Da(end+1,1)=p(3); %#ok<AGROW>
    % MJD from calendar date (UT-day start). days-since-1932 (p4) is an
    % alternative but we derive MJD directly for a clean absolute anchor.
    mjd(end+1,1) = ymd2mjd(p(1),p(2),p(3)); %#ok<AGROW>
    Kp8(end+1,:) = p(8:15);    %#ok<AGROW>
    ap8(end+1,:) = p(16:23);   %#ok<AGROW>
    Ap(end+1,1)  = p(24);      %#ok<AGROW>
    SN(end+1,1)  = p(25);      %#ok<AGROW>
    F107obs(end+1,1) = p(26);  %#ok<AGROW>
    F107adj(end+1,1) = p(27);  %#ok<AGROW>
    if numel(p) >= 28, Dfl(end+1,1) = p(28); else, Dfl(end+1,1) = NaN; end %#ok<AGROW>
end
if isempty(Y)
    error('loadSpaceWeatherIndices:noData', ...
        ['No daily data rows parsed from %s. Is this the one-line-per-day ' ...
         'Kp_ap_Ap_SN_F107*.txt file (not the 3-hourly Kp_ap_*.txt)?'], fname);
end
% ensure chronological order
[mjd, ord] = sort(mjd);
raw.date = datetime(Y(ord), Mo(ord), Da(ord));
raw.mjd = mjd;
raw.Kp8 = Kp8(ord,:);
raw.ap8 = ap8(ord,:);
raw.Ap = Ap(ord);
raw.SN = SN(ord);
raw.F107obs = F107obs(ord);
raw.F107adj = F107adj(ord);
raw.definitive = Dfl(ord);
raw.file = fname;
raw.nHeader = nHeader;
end

% -------------------------------------------------------------------
function m = ymd2mjd(y, mo, d)
% civil date -> Modified Julian Date (integer, UT-day start), Fliegel-Van
% Flandern via MATLAB datenum (MJD = datenum - 678942 with the 1858-11-17
% epoch: datenum(1858,11,17)=678942).
m = datenum(y, mo, d) - 678942;
end

% -------------------------------------------------------------------
function y = centredRunningMean(x, win)
% centred running mean ignoring NaNs / GFZ -1 missing code
x = x(:); x(x == -1) = NaN;
n = numel(x); y = nan(n,1);
h = floor(win/2);
for i = 1:n
    lo = max(1, i-h); hi = min(n, i+h);
    seg = x(lo:hi);
    seg = seg(isfinite(seg));
    if ~isempty(seg), y(i) = mean(seg); end
end
end

% -------------------------------------------------------------------
function [v, notes] = handleMissing(v, t, policy, name, notes)
v = v(:); bad = (v == -1);
if ~any(bad), return; end
switch lower(policy)
    case 'interp'
        good = ~bad & isfinite(v);
        if nnz(good) >= 2
            v(bad) = interp1(t(good), v(good), t(bad), 'linear', NaN);
        else
            v(bad) = NaN;
        end
        notes{end+1} = sprintf('%s: %d missing value(s) filled by interpolation.', name, nnz(bad));
    otherwise
        v(bad) = NaN;
        notes{end+1} = sprintf('%s: %d missing value(s) set to NaN.', name, nnz(bad));
end
end

% -------------------------------------------------------------------
function x = nanReplace(x, code)
x = x(:); x(x == code) = NaN;
end

% -------------------------------------------------------------------
function yi = interp1safe(t, v, ti, method)
% interpolate with NaN-holes removed; no extrapolation (out-of-range -> NaN)
t = t(:); v = v(:);
ok = isfinite(t) & isfinite(v);
if nnz(ok) < 2
    yi = nan(size(ti)); return;
end
yi = interp1(t(ok), v(ok), ti, method, NaN);
end

% -------------------------------------------------------------------
function yi = sampleByDay(mjdDayStart, v, ti)
% Sample a once-per-UT-day value by day membership: the value for the day
% containing ti (i.e. floor(ti) matches the UT-day integer MJD) is held
% across the whole day. Windows outside the covered days return NaN.
mjdDayStart = mjdDayStart(:); v = v(:);
yi = nan(size(ti));
dayOf = floor(ti);
for k = 1:numel(ti)
    idx = find(mjdDayStart == dayOf(k), 1);
    if ~isempty(idx), yi(k) = v(idx); end
end
end

% -------------------------------------------------------------------
function printSummary(indices, raw, tMid, startMJD, mjdRev, notes)
fprintf('\n===== loadSpaceWeatherIndices =====\n');
fprintf('  source     : %s\n', raw.file);
fprintf('  daily rows : %d  (%s .. %s)\n', numel(raw.mjd), ...
    datestr(raw.date(1),'yyyy-mm-dd'), datestr(raw.date(end),'yyyy-mm-dd'));
fprintf('  per-rev    : %d window(s), MJD %.4f .. %.4f\n', ...
    numel(tMid), min(mjdRev), max(mjdRev));
fn = fieldnames(indices);
for k = 1:numel(fn)
    v = indices.(fn{k});
    fprintf('   %-7s range [%.3g, %.3g], %d NaN\n', fn{k}, ...
        min(v,[],'omitnan'), max(v,[],'omitnan'), nnz(isnan(v)));
end
if ~isempty(notes)
    fprintf('  notes:\n');
    for k = 1:numel(notes), fprintf('   [!] %s\n', notes{k}); end
end
fprintf('===================================\n');
end
