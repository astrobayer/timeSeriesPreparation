function [rho, verdict] = heteroscedasticityCheck(residual, modelValue)
%HETEROSCEDASTICITYCHECK  Classify whether fit residuals scale with model
%   magnitude (multiplicative error, e.g. density/Cd mis-model) or are
%   magnitude-independent (additive error, e.g. sensor bias/noise).
%
%   [rho, verdict] = heteroscedasticityCheck(residual, modelValue)
%
%   INPUT
%     residual   : Nx1 fit residuals (y_obs - y_fitted)
%     modelValue : Nx1 modeled values used in the fit (same rows)
%
%   OUTPUT
%     rho     : Spearman correlation between |residual| and |modelValue|
%               (NaN if fewer than 11 samples or modelValue is constant)
%     verdict : 'multiplicative-dominated' (rho > 0.4)
%               'additive-dominated'       (rho < 0.15)
%               'mixed'                    (0.15 <= rho <= 0.4)
%               'indeterminate'            (rho is NaN)
%
%   See also CORR, ACCELSERIESPREFLIGHT.

residual = residual(:); modelValue = modelValue(:);
absResid = abs(residual);
absModel = abs(modelValue);

if numel(absModel) > 10 && std(absModel) > 0
    rho = corr(absResid, absModel, 'type', 'Spearman');
else
    rho = NaN;
end

if isnan(rho)
    verdict = 'indeterminate';
elseif rho > 0.4
    verdict = 'multiplicative-dominated';
elseif rho < 0.15
    verdict = 'additive-dominated';
else
    verdict = 'mixed';
end

end
