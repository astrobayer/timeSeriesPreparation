function P = diffPenaltyMatrix(nBasis, d)
%DIFFPENALTYMATRIX  Difference-penalty matrix P = D'*D for P-splines.
%
%   P = diffPenaltyMatrix(nBasis)      % d = 2 (default, roughness)
%   P = diffPenaltyMatrix(nBasis, d)
%
%   D is the d-th order difference operator on the spline coefficients
%   (Eilers & Marx 1996). Penalizing coef'*P*coef shrinks the fitted
%   curve toward a polynomial of degree d-1: with d = 2 the null space
%   is {constant, linear}, so an unbounded penalty recovers a straight
%   line rather than forcing the bias to zero. That is the right prior
%   for an instrument bias that may drift linearly.
%
%   INPUT
%     nBasis : number of spline basis functions (= size(B,2))
%     d      : difference order (default 2)
%
%   OUTPUT
%     P : nBasis x nBasis symmetric positive-semidefinite penalty, with
%         rank nBasis - d (i.e. a d-dimensional null space)
%
%   Example
%     B = bsplineBasis(t, 30, 4);
%     P = diffPenaltyMatrix(size(B,2), 2);
%     coef = (B'*B + lambda*P) \ (B'*y);
%
%   See also BSPLINEBASIS, GCVSELECTLAMBDA, BUILDBIASDESIGN.

if nargin < 2 || isempty(d), d = 2; end

if nBasis <= d
    error('diffPenaltyMatrix:tooFewBasis', ...
        'nBasis (%d) must exceed the difference order d (%d).', nBasis, d);
end

D = diff(eye(nBasis), d, 1);
P = D' * D;
P = (P + P')/2;   % enforce exact symmetry

end
