readGraceFoL1b.m and readGraceFoL1bMulti.m in this folder are the USER-PROVIDED
GRACE-FO L1B ASCII readers, included so the toolbox runs standalone. They are not
authored as part of AccelBiasScaleToolbox; if you maintain your own copies, put
those earlier on the MATLAB path and delete these.

readGroopsInstrument.m (in the parent src/ folder) IS part of this toolbox and
reads the GROOPS instrument-format model files, which the L1B readers do not cover.
