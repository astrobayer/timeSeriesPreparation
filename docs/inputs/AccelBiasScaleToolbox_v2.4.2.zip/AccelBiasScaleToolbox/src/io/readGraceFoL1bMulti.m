function [time, obs, aux] = readGraceFoL1bMulti(fileNames, options)
%READGRACEFOL1BMULTI  Read and concatenate several GRACE-FO L1B ASCII files.
%
%   [TIME, OBS, AUX] = READGRACEFOL1BMULTI(FILENAMES) calls
%   READGRACEFOL1B on each file in FILENAMES (e.g. consecutive daily
%   ACC1B files) and vertically concatenates the results into a single
%   continuous TIME/OBS record, which is how these products are used in
%   practice (multi-day arcs, not single days in isolation).
%
%   [TIME, OBS, AUX] = READGRACEFOL1BMULTI(FILENAMES, 'TimeVariable', NAME)
%   forwards a TimeVariable override to every call of READGRACEFOL1B,
%   see its help text for details.
%
%   INPUT
%     fileNames - string array or cellstr, [1 x K], K = number of files
%                 List of Level-1B ASCII file paths, in the order they
%                 should be concatenated (typically chronological). Each
%                 file must be readable by READGRACEFOL1B and all files
%                 must expose the same set of observation columns
%                 (aux.obsNames); a mismatch raises an error rather than
%                 silently concatenating incompatible data.
%
%     'TimeVariable' - string, scalar, 1x1, optional name-value argument
%                 Forwarded unchanged to every READGRACEFOL1B call.
%                 Default "" (automatic detection per file).
%
%   OUTPUT
%     time - double, [N x 2], N = total number of records across all
%            files (sum of each file's record count). Same layout as
%            READGRACEFOL1B: column 1 = integer MJD, column 2 = seconds
%            of day.
%     obs  - double, [N x M], M = number of observation columns (must be
%            identical, in name and order, across all input files).
%     aux  - struct, 1x1, with fields:
%              .obsNames        - cellstr, [1 x M], as in READGRACEFOL1B
%                                   (taken from the first file)
%              .variableNames   - cellstr, [1 x V], from the first file
%              .variableUnits   - struct, from the first file
%              .timeVariable    - char, time variable(s) used, from the
%                                   first file
%              .timeSystem      - char, 'GPS'
%              .epochDescription- char, time-origin description
%              .epochMJD        - double, scalar, 51544
%              .fileNames       - string, [K x 1], the input file list
%              .headers         - cell, [K x 1] of cellstr, raw YAML
%                                   header text of each file
%              .recordsPerFile  - double, [K x 1], record count actually
%                                   read from each file (splits(time,1)
%                                   == cumsum(recordsPerFile))
%              .numRecordsHeader- double, [K x 1], per-file num_records
%                                   as declared in each header (NaN if
%                                   undeclared)
%              .numRecordsActual- double, [K x 1], per-file actual
%                                   record counts (same as recordsPerFile)
%              .<name>          - any per-record auxiliary field (e.g.
%                                   qualflg, GRACEFO_id) that is present,
%                                   with a consistent type, in every
%                                   file, vertically concatenated in
%                                   file order. Fields that are missing
%                                   or type-inconsistent in at least one
%                                   file are dropped with a warning
%                                   (id readGraceFoL1bMulti:fieldDropped)
%                                   rather than guessed at.
%
%   EXAMPLE
%     files = compose("ACC1B_2019-01-%02d_C_04.txt", 1:5);
%     [t, acc, aux] = readGraceFoL1bMulti(files);
%
%   See also READGRACEFOL1B

arguments
    fileNames (1,:) string {mustBeNonempty}
    options.TimeVariable (1,1) string = ""
end

nFiles = numel(fileNames);
timeAll = cell(nFiles, 1);
obsAll  = cell(nFiles, 1);
auxAll  = cell(nFiles, 1);

for i = 1:nFiles
    if options.TimeVariable ~= ""
        [timeAll{i}, obsAll{i}, auxAll{i}] = ...
            readGraceFoL1b(fileNames(i), 'TimeVariable', options.TimeVariable);
    else
        [timeAll{i}, obsAll{i}, auxAll{i}] = readGraceFoL1b(fileNames(i));
    end
end

refObsNames = auxAll{1}.obsNames;
for i = 2:nFiles
    if ~isequal(auxAll{i}.obsNames, refObsNames)
        error('readGraceFoL1bMulti:inconsistentVariables', ...
            ['File "%s" has observation columns {%s} that differ from ', ...
             'file "%s" {%s}. All files must expose the same variables.'], ...
            fileNames(i), strjoin(auxAll{i}.obsNames, ', '), ...
            fileNames(1), strjoin(refObsNames, ', '));
    end
end

time = vertcat(timeAll{:});
obs  = vertcat(obsAll{:});

aux = struct();
aux.obsNames         = refObsNames;
aux.variableNames    = auxAll{1}.variableNames;
aux.variableUnits    = auxAll{1}.variableUnits;
aux.timeVariable     = auxAll{1}.timeVariable;
aux.timeSystem       = auxAll{1}.timeSystem;
aux.epochDescription = auxAll{1}.epochDescription;
aux.epochMJD         = auxAll{1}.epochMJD;
aux.fileNames        = fileNames(:);
aux.headers          = cellfun(@(a) a.header, auxAll, 'UniformOutput', false);
aux.recordsPerFile   = cellfun(@(t) size(t, 1), timeAll);
aux.numRecordsHeader = cellfun(@(a) a.numRecordsHeader, auxAll);
aux.numRecordsActual = cellfun(@(a) a.numRecordsActual, auxAll);

% ---- merge per-record auxiliary fields common to every file -----------
metaFields = {'obsNames', 'variableNames', 'variableUnits', 'header', 'fileName', ...
              'timeVariable', 'timeSystem', 'epochDescription', 'epochMJD', ...
              'numRecordsHeader', 'numRecordsActual'};
candidateFields = setdiff(fieldnames(auxAll{1}), metaFields, 'stable');

for f = 1:numel(candidateFields)
    fn = candidateFields{f};
    consistent = true;
    refClass = class(auxAll{1}.(fn));
    for i = 2:nFiles
        if ~isfield(auxAll{i}, fn) || ~strcmp(class(auxAll{i}.(fn)), refClass)
            consistent = false;
            break
        end
    end
    if consistent
        values = cellfun(@(a) a.(fn), auxAll, 'UniformOutput', false);
        try
            aux.(fn) = vertcat(values{:});
        catch
            consistent = false;
        end
    end
    if ~consistent
        warning('readGraceFoL1bMulti:fieldDropped', ...
            'Auxiliary field "%s" is missing or inconsistently typed in at least one file and was not concatenated.', fn);
    end
end

end
