function [time, obs, aux] = readGraceFoL1b(fileName, options)
%READGRACEFOL1B  Generic reader for GRACE-FO Level-1B ASCII products.
%
%   [TIME, OBS, AUX] = READGRACEFOL1B(FILENAME) reads any GRACE-FO
%   Level-1B RL04 ASCII product (ACC1B, SCA1B, KBR1B, GNV1B, GNI1B,
%   GNP1B, GPS1B, IMU1B, MAG1B, THR1B, CLK1B, TIM1B, USO1B, VSL1B, ...).
%   These products share a common file structure: a YAML-encoded header
%   terminated by the line "# End of YAML header", followed by
%   whitespace-delimited data records whose column order matches the
%   "variable_descriptions" list in the header.
%
%   [TIME, OBS, AUX] = READGRACEFOL1B(FILENAME, 'TimeVariable', NAME)
%   overrides automatic time-tag detection. NAME is either a single
%   variable name (e.g. "gps_time") or two names joined with '+' for
%   split integer/fractional-second pairs (e.g. "rcvtime_intg+rcvtime_frac").
%
%   INPUT
%     fileName - string / char, scalar, 1x1 (required, positional)
%                Path (relative or absolute) to a GRACE-FO Level-1B
%                ASCII product file. Both plain text and gzip-compressed
%                files are accepted:
%                  - plain ASCII,     e.g. "ACC1B_2019-01-01_C_04.txt"
%                  - gzip-compressed, e.g. "ACC1B_2019-01-01_C_04.txt.gz"
%                (detected via the ".gz" extension; the file is
%                transparently unzipped into a temporary directory that
%                is deleted again on return, including on error).
%                Must exist on disk (validated with mustBeFile).
%
%     'TimeVariable' - string, scalar, 1x1, optional name-value argument
%                Name of the header variable(s) to use as the time tag,
%                overriding automatic detection (see above). Default ""
%                (automatic: "gps_time", falling back to a small list of
%                known intg/frac pairs).
%
%   OUTPUT
%     time - double, [N x 2], N = number of data records in the file
%            Column 1: integer Modified Julian Day (MJD), GPS time
%                      reference, e.g. 51544 for 2000-01-01T00:00:00.
%            Column 2: seconds of day, double, 0 <= time(:,2) < 86400
%                      (decimal, sub-microsecond resolution).
%            GRACE(-FO) Level-1B time tags are "GPS time" = continuous
%            seconds past 2000-01-01 12:00:00 (no leap seconds). This
%            routine converts that scalar count into integer-day plus
%            fractional-seconds-of-day using floor/mod arithmetic
%            (rather than direct division), which avoids large-number
%            floating-point cancellation and preserves the full
%            precision of the original time tag.
%
%     obs  - double, [N x M], M = number of observation columns
%            (product-dependent, e.g. M=6 for ACC1B: 3 linear + 3
%            angular accelerations)
%            All numeric science-data columns, i.e. every column from
%            the file except the time tag(s) and any column classified
%            as auxiliary (quality flags, identifiers, non-numeric
%            fields, see aux.obsNames and the classification rule
%            below). Column j of obs corresponds to aux.obsNames{j},
%            row i of obs corresponds to row i of time.
%
%     aux  - struct, 1x1, with fields:
%              .fileName        - string, the input argument as given
%              .obsNames        - cellstr, [1 x M], names of the columns
%                                   contained in OBS, in column order
%              .variableNames   - cellstr, [1 x V], V = total number of
%                                   variables in the file header (V >= M),
%                                   every variable name in original file
%                                   column order (time + obs + aux)
%              .variableUnits   - struct, 1x1, one field per variable
%                                   that declared a "units:" entry in the
%                                   header; field name = sanitized
%                                   variable name, value = char unit
%                                   string (e.g. 'm/s^2', 'second')
%              .timeVariable    - char, name(s) of the variable(s) used
%                                   for TIME, e.g. 'gps_time' or
%                                   'rcvtime_intg+rcvtime_frac'
%              .timeSystem      - char, always 'GPS' (no leap seconds)
%              .epochDescription- char, human-readable definition of the
%                                   time origin
%              .epochMJD        - double, scalar, MJD of the time origin
%                                   (51544 = 2000-01-01 00:00:00)
%              .numRecordsHeader- double, scalar, num_records value
%                                   declared in the header (NaN if the
%                                   header did not declare one)
%              .numRecordsActual- double, scalar, number of data records
%                                   actually read (== N). A mismatch
%                                   with numRecordsHeader triggers a
%                                   warning (id readGraceFoL1b:recordCountMismatch)
%                                   but is not fatal.
%              .header          - cellstr, [H x 1], H = number of header
%                                   lines, raw YAML header text as read
%                                   from the file (including the
%                                   "# End of YAML header" line)
%              .<name>          - one additional field per auxiliary
%                                   (non-observation) variable, named
%                                   after the sanitized original variable
%                                   name. Type depends on content:
%                                     * double, [N x 1] for numeric
%                                       flags/ids (e.g. qualflg)
%                                     * char,   [N x 1] for single-
%                                       character string columns (e.g.
%                                       GRACEFO_id: 'C'/'D')
%                                     * cellstr,[N x 1] for any other
%                                       non-numeric column
%
%   Column classification rule (obs vs. aux)
%     A column is treated as auxiliary (kept out of OBS, exposed only
%     via AUX) if any of the following holds:
%       - it is the time-tag column itself
%       - it cannot be parsed as a plain numeric value (e.g. a
%         satellite id letter)
%       - its variable name contains "flag" or "qual" (case-insensitive)
%     Every other numeric column is treated as an observation.
%
%   Row integrity
%     Every data line must contain exactly as many whitespace-separated
%     tokens as there are variable_descriptions entries in the header.
%     If any line does not (truncated/corrupted file), an error
%     (id readGraceFoL1b:columnMismatch) is raised naming the offending
%     file line number, rather than silently misaligning columns.
%
%   EXAMPLE
%     [t, acc, aux] = readGraceFoL1b('ACC1B_2019-01-01_C_04.txt');
%     plot(t(:,2), acc(:,1))   % linear acceleration x vs. seconds of day
%
%     % override automatic time-tag detection
%     [t, obs, aux] = readGraceFoL1b('PAIR1B_test.txt', ...
%                                     'TimeVariable', 'rcvtime_intg+rcvtime_frac');
%
%   See also READGRACEFOL1BMULTI
%
%   Notes on robustness / scope
%     - Only the ASCII (YAML header) distribution format is supported,
%       which is the current RL04+ distribution format for all GRACE-FO
%       L1B products. Legacy binary files are not supported and raise
%       an explicit error.
%     - Column classification (observation vs. auxiliary) is generic:
%       any column that cannot be parsed as a pure numeric value, or
%       whose variable name contains "flag"/"qual", is treated as
%       auxiliary rather than as an observation. This keeps e.g.
%       qualflg, GRACEFO_id, sat_id out of OBS while still fully
%       exposing them via AUX.
%     - Requires MATLAB R2020b or later (uses the "arguments" block and
%       the mustBeFile validation function).

arguments
    fileName (1,1) string {mustBeFile}
    options.TimeVariable (1,1) string = ""
end

% ---- unzip if needed ---------------------------------------------------
cleanupTmp = onCleanup(@() []); %#ok<NASGU>
localFile = fileName;
if endsWith(fileName, '.gz', 'IgnoreCase', true)
    outDir = tempname; mkdir(outDir);
    unzipped = gunzip(fileName, outDir);
    localFile = unzipped{1};
    cleanupTmp = onCleanup(@() rmdir(outDir, 's'));
end

% ---- read header -----------------------------------------------------
fid = fopen(localFile, 'rt');
if fid < 0
    error('readGraceFoL1b:openFailed', 'Could not open file: %s', localFile);
end
headerLines = {};
tline = fgetl(fid);
foundEnd = false;
while ischar(tline)
    headerLines{end+1} = tline; %#ok<AGROW>
    if contains(tline, 'End of YAML header')
        foundEnd = true;
        break
    end
    tline = fgetl(fid);
end
if ~foundEnd
    fclose(fid);
    error('readGraceFoL1b:badHeader', ...
        'No "# End of YAML header" marker found; this does not look like a GRACE-FO L1B ASCII product.');
end
headerText = strjoin(headerLines, newline);

if ~isempty(regexpi(headerText, 'format:\s*bin', 'once'))
    fclose(fid);
    error('readGraceFoL1b:binaryNotSupported', ...
        'Binary Level-1B files are not supported. Please use the ASCII (YAML header) product.');
end

% ---- parse variable names + units from the YAML header --------------
[nameTok, nameStart] = regexp(headerText, '-\s*name:\s*(\S+)', 'tokens', 'start');
if isempty(nameTok)
    fclose(fid);
    error('readGraceFoL1b:noVariables', 'No variable_descriptions entries found in header.');
end
varNames = cellfun(@(c) strtrim(erase(c{1}, {'''', '"'})), nameTok, 'UniformOutput', false);

endMarkerPos = strfind(headerText, '# End of YAML header');
blockEnds = [nameStart(2:end) - 1, endMarkerPos(1) - 1];
units = cell(size(varNames));
for k = 1:numel(varNames)
    blockText = headerText(nameStart(k):blockEnds(k));
    u = regexp(blockText, 'units:\s*([^\n\r]+)', 'tokens', 'once');
    if ~isempty(u)
        units{k} = strtrim(erase(u{1}{1}, {'''', '"'}));
    else
        units{k} = '';
    end
end
nVar = numel(varNames);

numRecTok = regexp(headerText, 'num_records:\s*(\d+)', 'tokens', 'once');
if ~isempty(numRecTok)
    numRecordsHeader = str2double(numRecTok{1});
else
    numRecordsHeader = NaN;
end

% ---- read data records with strict row-integrity checking -------------
rawLineScan = textscan(fid, '%s', 'Delimiter', '\n', 'Whitespace', '');
fclose(fid);
lines = rawLineScan{1};
firstDataLineNo = numel(headerLines) + 1;

tokens = regexp(lines, '\S+', 'match');
tokenCounts = cellfun(@numel, tokens);
nonBlank = tokenCounts > 0;

badIdx = find(nonBlank & tokenCounts ~= nVar, 1);
if ~isempty(badIdx)
    fileLineNo = firstDataLineNo + badIdx - 1;
    error('readGraceFoL1b:columnMismatch', ...
        ['Data line %d has %d whitespace-separated token(s), expected %d ', ...
         '(based on %d variable_descriptions entries in the header). ', ...
         'The file may be truncated or corrupted.'], ...
        fileLineNo, tokenCounts(badIdx), nVar, nVar);
end

dataLineIdx = find(nonBlank);
tokens = tokens(dataLineIdx);
nRec = numel(tokens);
if nRec == 0
    error('readGraceFoL1b:noData', 'No data records found in %s', fileName);
end
tokMat = vertcat(tokens{:});   % [nRec x nVar] cell array, one row per record

if ~isnan(numRecordsHeader) && numRecordsHeader ~= nRec
    warning('readGraceFoL1b:recordCountMismatch', ...
        'Header declares num_records=%d but %d data record(s) were read from %s.', ...
        numRecordsHeader, nRec, fileName);
end

data = nan(nRec, nVar);
isNumericCol = true(1, nVar);
for k = 1:nVar
    colStrings = tokMat(:, k);
    vals = str2double(colStrings);
    nanMask = isnan(vals);
    isLiteralNaN = strcmpi(colStrings, 'nan') | strcmpi(colStrings, 'nanf');
    if any(nanMask & ~isLiteralNaN)
        isNumericCol(k) = false;
    else
        data(:, k) = vals;
    end
end

% ---- identify the time column(s) --------------------------------------
if options.TimeVariable ~= ""
    tv = options.TimeVariable;
    if contains(tv, '+')
        parts = strtrim(split(tv, '+'));
        i1 = find(strcmpi(varNames, parts(1)), 1);
        i2 = find(strcmpi(varNames, parts(2)), 1);
        if isempty(i1) || isempty(i2)
            error('readGraceFoL1b:timeVariableNotFound', ...
                'TimeVariable "%s" not found among header variables: %s', tv, strjoin(varNames, ', '));
        end
        gpsSeconds = data(:, i1) + data(:, i2);
        timeColIdx = [i1, i2];
        timeVarUsed = sprintf('%s+%s', varNames{i1}, varNames{i2});
    else
        i1 = find(strcmpi(varNames, tv), 1);
        if isempty(i1)
            error('readGraceFoL1b:timeVariableNotFound', ...
                'TimeVariable "%s" not found among header variables: %s', tv, strjoin(varNames, ', '));
        end
        gpsSeconds = data(:, i1);
        timeColIdx = i1;
        timeVarUsed = varNames{i1};
    end
else
    timeColIdx = find(strcmpi(varNames, 'gps_time'), 1);
    if ~isempty(timeColIdx)
        gpsSeconds = data(:, timeColIdx);
        timeVarUsed = varNames{timeColIdx};
    else
        pairCandidates = {{'rcvtime_intg', 'rcvtime_frac'}, {'time_intg', 'time_frac'}, ...
                           {'gps_intg', 'gps_frac'}};
        timeColIdx = [];
        for p = 1:numel(pairCandidates)
            i1 = find(strcmpi(varNames, pairCandidates{p}{1}), 1);
            i2 = find(strcmpi(varNames, pairCandidates{p}{2}), 1);
            if ~isempty(i1) && ~isempty(i2)
                gpsSeconds = data(:, i1) + data(:, i2);
                timeColIdx = [i1, i2];
                timeVarUsed = sprintf('%s+%s', varNames{i1}, varNames{i2});
                break
            end
        end
        if isempty(timeColIdx)
            error('readGraceFoL1b:noTime', ...
                'Could not identify a time tag column among: %s', strjoin(varNames, ', '));
        end
    end
end

% GRACE(-FO) GPS time = continuous seconds past 2000-01-01 12:00:00
% (no leap seconds). MJD 51544.0 = 2000-01-01 00:00:00.
mjdEpoch = 51544;
totalSec = gpsSeconds + 43200;           % seconds since mjdEpoch, 0h
daysFull = floor(totalSec / 86400);
secOfDay = totalSec - daysFull * 86400;  % robust modulo, keeps sub-us fidelity
time = [mjdEpoch + daysFull, secOfDay];

% ---- split remaining columns into obs vs. aux --------------------------
isAuxOnly = ~isNumericCol;
for k = 1:nVar
    if any(regexpi(varNames{k}, 'flag|qual', 'once'))
        isAuxOnly(k) = true;
    end
end
isAuxOnly(timeColIdx) = true;

obsCols = find(~isAuxOnly);
obs = data(:, obsCols);

aux = struct();
aux.fileName = fileName;
aux.variableNames = varNames;
aux.obsNames = varNames(obsCols);
aux.timeVariable = timeVarUsed;
aux.timeSystem = 'GPS';
aux.epochDescription = 'Continuous seconds past 2000-01-01 12:00:00 GPS (no leap seconds)';
aux.epochMJD = mjdEpoch;
aux.numRecordsHeader = numRecordsHeader;
aux.numRecordsActual = nRec;
aux.header = headerLines(:);

unitStruct = struct();
for k = 1:nVar
    fn = matlab.lang.makeValidName(varNames{k});
    if ~isempty(units{k})
        unitStruct.(fn) = units{k};
    end
end
aux.variableUnits = unitStruct;

for k = 1:nVar
    if ismember(k, timeColIdx)
        continue
    end
    if ~isAuxOnly(k)
        continue
    end
    fn = matlab.lang.makeValidName(varNames{k});
    if isNumericCol(k)
        aux.(fn) = data(:, k);
    else
        col = tokMat(:, k);
        if all(cellfun(@numel, col) == 1)
            aux.(fn) = char(col);      % e.g. GRACEFO_id: 'C'/'D'
        else
            aux.(fn) = col;            % general string column
        end
    end
end

end
