function q = qualityCheck(t, y, maxGapFactor)
%QUALITYCHECK  Basic data-quality diagnostics for a single time series.
%
%   q = qualityCheck(t, y, maxGapFactor)
%
%   INPUT
%     t            : Nx1 monotonically-nondecreasing-if-clean time vector
%     y            : Nx1 values (NaN/Inf allowed, counted not removed)
%     maxGapFactor : a step dt(k) is flagged as a "gap" if
%                    dt(k) > maxGapFactor * median(dt)
%
%   OUTPUT (struct)
%     .nNaN                 count of non-finite y samples
%     .nonMonotonic          true if any dt <= 0 (unsorted or duplicate)
%     .duplicateTimestamps   count of dt == 0
%     .dtMedian, .dtStd      nominal sampling interval statistics
%                            (computed over dt > 0 only)
%     .nGaps                 count of steps exceeding the gap threshold
%     .gapFraction           fraction of the total time span spent
%                            inside flagged gaps
%     .outlierFraction       fraction of finite samples farther than
%                            5*MAD (normal-consistent) from the median
%
%   Example
%     q = qualityCheck(t, y, 5);
%     if q.gapFraction > 0.05, warning('excessive data gaps'); end
%
%   See also ALIGNACCELSERIES, ACCELSERIESPREFLIGHT.

t = t(:); y = y(:);
q.nNaN = nnz(~isfinite(y));

dt = diff(t);
q.nonMonotonic = any(dt <= 0);
q.duplicateTimestamps = nnz(dt == 0);

posDt = dt(dt > 0);
if isempty(posDt)
    q.dtMedian = NaN;
    q.dtStd = NaN;
    q.nGaps = 0;
    q.gapFraction = NaN;
else
    q.dtMedian = median(posDt);
    q.dtStd = std(posDt);
    gapThresh = maxGapFactor * q.dtMedian;
    isGap = posDt > gapThresh;
    q.nGaps = nnz(isGap);
    span = t(end) - t(1);
    if span > 0
        q.gapFraction = sum(posDt(isGap)) / span;
    else
        q.gapFraction = NaN;
    end
end

yFinite = y(isfinite(y));
if numel(yFinite) > 10
    m = median(yFinite);
    madv = median(abs(yFinite - m)) * 1.4826;
    if madv > 0
        q.outlierFraction = nnz(abs(yFinite - m) > 5*madv) / numel(yFinite);
    else
        q.outlierFraction = 0;
    end
else
    q.outlierFraction = NaN;
end

end
