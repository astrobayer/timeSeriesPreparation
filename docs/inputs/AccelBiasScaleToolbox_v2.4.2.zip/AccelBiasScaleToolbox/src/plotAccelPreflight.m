function plotAccelPreflight(report)
%PLOTACCELPREFLIGHT  Figures and console summary for ACCELSERIESPREFLIGHT.
%
%   plotAccelPreflight(report)
%
%   Produces, per axis:
%     - windowed scale/bias preview, with UNOBSERVABLE windows marked
%     - bias-scale correlation and regressor dynamic range per window
%       (the diagnostic that explains a "wild" scale)
%     - Lomb-Scargle spectra of observation, model, and residual
%   and prints the flag list, which is the headline output.
%
%   See also ACCELSERIESPREFLIGHT, SCALEOBSERVABILITY.

nAxes = numel(report.axis);

for k = 1:nAxes
    ax = report.axis(k);
    sf = ax.slidingFit;

    %% --- windowed preview + observability ---
    if ~isempty(sf.tWindow)
        figure('Name', sprintf('Preflight axis %d -- windowed bias/scale', k));

        subplot(3,1,1);
        hold on;
        plot(sf.tWindow, sf.scale, '.-');
        bad = ~sf.observable & isfinite(sf.tWindow);
        if any(bad)
            yl = ylim;
            plot(sf.tWindow(bad), repmat(yl(1), nnz(bad), 1), 'rx', ...
                'DisplayName', 'unobservable');
        end
        yline(1, '--k');
        hold off;
        ylabel('scale');
        title(sprintf(['Axis %d: windowed scale (std over observable windows = %.3g); ' ...
            'red x = scale NOT identifiable'], k, sf.scaleStd));
        grid on;

        subplot(3,1,2);
        plot(sf.tWindow, sf.bias, '.-');
        yline(0, '--k');
        ylabel('bias');
        title(sprintf('Windowed bias (std = %.3g)', sf.biasStd));
        grid on;

        subplot(3,1,3);
        yyaxis left;
        plot(sf.tWindow, abs(sf.biasScaleCorr), '.-');
        ylabel('|corr(bias, scale)|');
        ylim([0 1]);
        yyaxis right;
        semilogy(sf.tWindow, sf.relRange, '.-');
        ylabel('std/|mean| of model');
        xlabel('Time');
        title('Why scale misbehaves: collinearity (left) and dynamic range (right)');
        grid on;
    end

    %% --- spectra ---
    if isfield(ax.spectral, 'f') && ~isempty(ax.spectral.f)
        figure('Name', sprintf('Preflight axis %d -- Lomb-Scargle spectra', k));
        loglog(ax.spectral.f, ax.spectral.Pobs, ...
               ax.spectral.f, ax.spectral.Pmod, ...
               ax.spectral.f, ax.spectral.Pres);
        legend('observed','modeled','residual','Location','best');
        xlabel('Frequency'); ylabel('Lomb-Scargle power');
        title(sprintf(['Axis %d: spectra on the TRUE uneven epochs. ' ...
            'Observed rolling off above the model => filter mismatch.'], k));
        grid on;
    end
end

%% --- console summary ---
fprintf('\n================ accelSeriesPreflight summary ================\n');
for k = 1:nAxes
    ax = report.axis(k);
    fprintf('\n--- Axis %d ---\n', k);

    if isfield(ax.globalFit,'scale')
        fprintf('  Global fit : bias = %.4g, scale = %.4g, R2 = %.3f\n', ...
            ax.globalFit.bias, ax.globalFit.scale, ax.globalFit.R2);
    end
    if ~isempty(ax.observability)
        fprintf('  Scale observable over arc: %d  (cond %.3g, bias-scale corr %.3f)\n', ...
            ax.observability.observable, ax.observability.cond, ...
            ax.observability.biasScaleCorr);
    end
    if ~isempty(ax.noiseModel)
        fprintf('  Residual noise: %s (AR %d, acf1 %.2f, n_eff/n = %.2f)\n', ...
            ax.noiseModel.verdict, ax.noiseModel.order, ...
            ax.noiseModel.acf1, ax.noiseModel.nEffRatio);
    end
    fprintf('  Heteroscedasticity: %s\n', ax.heteroscedasticity.verdict);
    if isfield(ax.slidingFit,'nUnobservable')
        fprintf('  Windows with unidentifiable scale: %d / %d\n', ...
            ax.slidingFit.nUnobservable, ax.slidingFit.nWindows);
    end

    if isempty(ax.flags)
        fprintf('  No caveats flagged.\n');
    else
        fprintf('  CAVEATS:\n');
        for f = 1:numel(ax.flags)
            fprintf('   [!] %s\n', ax.flags{f});
        end
    end
end
fprintf('\n=============================================================\n');

end
