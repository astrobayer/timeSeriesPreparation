function comparison = accelBiasScaleModelCompare(t1, Y1, t2, Y2, modelSpecs, varargin)
%ACCELBIASSCALEMODELCOMPARE  Fit several candidate bias/scale models to
%   identical data and rank them by BLOCKED cross-validation, so the
%   parameterization for the full (expensive) adjustment can be chosen up
%   front.
%
%   comparison = accelBiasScaleModelCompare(t1, Y1, t2, Y2, modelSpecs)
%   comparison = accelBiasScaleModelCompare(..., 'Name', Value, ...)
%
%   RANKING CRITERION: out-of-fold prediction error on CONTIGUOUS time
%   blocks (BLOCKEDCROSSVAL), NOT AIC/BIC. Accelerometer-minus-model
%   residuals are strongly autocorrelated; AIC/BIC assume they are
%   independent, overstate the likelihood by roughly n/nEff, and therefore
%   systematically over-select complex bias models. Blocked CV holds out
%   whole time blocks, which a model that has merely memorized correlated
%   noise cannot extrapolate into. AIC/BIC are reported for reference only
%   and are flagged as unreliable whenever the noise diagnostic says the
%   residuals are correlated -- which it almost always will.
%
%   INPUT
%     t1, Y1 : observed epochs / values (Nx1 or NxM)
%     t2, Y2 : modeled epochs / values (Kx1 or KxM), own sampling
%     modelSpecs : cell array of specs for ACCELBIASSCALEMODELFIT, each
%                  with .ScaleModel, .BiasModel and an optional .label
%
%   NAME-VALUE
%     'InterpMethod'      ('pchip')
%     'MaxInterpGap'      ([])
%     'FilterStrategy'    ('none')  passed to FILTERCONSISTENCY. Set to
%                         'commonmode' (or 'explicit' with the real ACC1B
%                         coefficients) when comparing a filtered
%                         observation against an unfiltered model --
%                         otherwise every candidate model is scored across
%                         the same spectral mismatch and the ranking can
%                         be dominated by it.
%     'FilterCutoff'      (0.035)
%     'NumFolds'          (5)
%     'CVGap'             (0)  purge samples adjacent to each test block
%     'Robust'            (true)
%     'NoiseModel'        (true)
%     'PlotDiagnostics'   (true)
%
%   OUTPUT
%     .table  : sorted by CV_RSS ascending (best model first). Columns:
%               Model, CV_RSS, CV_RMSE, MeanR2, TotalEDF,
%               MeanSigmaInflation, NoiseVerdict, AIC_unreliable,
%               BIC_unreliable
%     .fits   : cell array of ACCELBIASSCALEMODELFIT outputs
%     .tA, .Y1A, .Y2A : the shared aligned data all models were scored on
%     .alignInfo, .filterInfo
%
%   See also BLOCKEDCROSSVAL, ACCELBIASSCALEMODELFIT, FILTERCONSISTENCY.

ip = inputParser;
ip.addParameter('InterpMethod', 'pchip', @ischar);
ip.addParameter('MaxInterpGap', [], @(x) isempty(x) || isnumeric(x));
ip.addParameter('FilterStrategy', 'none', @ischar);
ip.addParameter('FilterCutoff', 0.035, @isnumeric);
ip.addParameter('FilterCoef', [], @(x) isempty(x) || isvector(x));
ip.addParameter('NumFolds', 5, @isnumeric);
ip.addParameter('CVGap', 0, @isnumeric);
ip.addParameter('Robust', true, @islogical);
ip.addParameter('NoiseModel', true, @islogical);
ip.addParameter('PlotDiagnostics', true, @islogical);
ip.parse(varargin{:});
opt = ip.Results;

if isvector(Y1), Y1 = Y1(:); end
if isvector(Y2), Y2 = Y2(:); end

%% --- align once; every model is scored on identical rows ---
[tA, Y1A, Y2A, alignInfo] = alignAccelSeries(t1, Y1, t2, Y2, ...
    'InterpMethod', opt.InterpMethod, 'MaxInterpGap', opt.MaxInterpGap);

%% --- filter consistency (applied per axis, before any fitting) ---
filterInfo = [];
if ~strcmpi(opt.FilterStrategy, 'none')
    for j = 1:size(Y1A,2)
        [Y1A(:,j), Y2A(:,j), filterInfo] = filterConsistency(tA, Y1A(:,j), Y2A(:,j), ...
            opt.FilterStrategy, 'Cutoff', opt.FilterCutoff, 'FilterCoef', opt.FilterCoef);
    end
end

M = size(Y1A,2);
nModels = numel(modelSpecs);

fits = cell(nModels,1);
labels = cell(nModels,1);
[cvRSS, cvRMSE, meanR2, totEDF, meanInfl] = deal(nan(nModels,1));
[aicRef, bicRef] = deal(nan(nModels,1));
noiseVerdict = cell(nModels,1);

for m = 1:nModels
    spec = modelSpecs{m};

    f = accelBiasScaleModelFit(tA, Y1A, Y2A, spec, ...
        'Robust', opt.Robust, 'NoiseModel', opt.NoiseModel, ...
        'NumFolds', opt.NumFolds);
    fits{m} = f;

    if isfield(spec,'label') && ~isempty(spec.label)
        labels{m} = spec.label;
    else
        labels{m} = f.modelLabel;
    end

    %% --- blocked CV score, summed over axes ---
    [B, biasInfo] = buildBiasDesign(tA, spec.BiasModel);
    nB = biasInfo.nParams;
    mask = scaleMask(spec.ScaleModel, M);
    mu = mean(Y2A, 1);
    Y2c = Y2A - mu;

    rssTot = 0; nPred = 0;
    for i = 1:M
        sa = find(mask(i,:));
        X = [B, Y2c(:, sa)];
        P = zeros(size(X,2));
        if biasInfo.isPenalized
            P(1:nB,1:nB) = biasInfo.penalty;
        end
        lam = f.axis(i).lambda;
        cv = blockedCrossVal(X, Y1A(:,i), 'NumFolds', opt.NumFolds, ...
            'Penalty', P, 'Lambda', lam, 'Gap', opt.CVGap, 'Robust', false);
        rssTot = rssTot + cv.rss;
        nPred = nPred + cv.nPredicted;
    end
    cvRSS(m) = rssTot;
    cvRMSE(m) = sqrt(rssTot / max(nPred,1));

    meanR2(m) = mean([f.axis.R2]);
    totEDF(m) = sum([f.axis.edf]);
    meanInfl(m) = mean(cellfun(@(s) mean(s), {f.axis.sigmaInflation}));

    nms = {f.axis.noiseModel};
    ratios = cellfun(@(s) s.nEffRatio, nms);
    if mean(ratios) > 0.8
        noiseVerdict{m} = 'iid-like';
    elseif mean(ratios) >= 0.3
        noiseVerdict{m} = 'mildly-correlated';
    else
        noiseVerdict{m} = 'strongly-correlated';
    end

    % reference-only AIC/BIC; see the header for why these are not used
    n = size(Y1A,1);
    rssRaw = sum([f.axis.RSS]);
    k = totEDF(m);
    aicRef(m) = n*log(rssRaw/n) + 2*k;
    bicRef(m) = n*log(rssRaw/n) + k*log(n);
end

unreliable = ~strcmp(noiseVerdict, 'iid-like');

comparison.table = table(labels, cvRSS, cvRMSE, meanR2, totEDF, meanInfl, ...
    noiseVerdict, aicRef, bicRef, unreliable, ...
    'VariableNames', {'Model','CV_RSS','CV_RMSE','MeanR2','TotalEDF', ...
    'MeanSigmaInflation','NoiseVerdict','AIC_ref','BIC_ref','IC_unreliable'});
comparison.table = sortrows(comparison.table, 'CV_RSS', 'ascend');

comparison.fits = fits;
comparison.labels = labels;
comparison.tA = tA;
comparison.Y1A = Y1A;
comparison.Y2A = Y2A;
comparison.alignInfo = alignInfo;
comparison.filterInfo = filterInfo;

if opt.PlotDiagnostics
    plotBiasScaleModelCompare(comparison);
end

end

% -------------------------------------------------------------------
function mask = scaleMask(sm, M)
if ischar(sm)
    switch lower(sm)
        case 'diagonal', mask = eye(M) > 0;
        case 'full',     mask = true(M,M);
        otherwise
            error('accelBiasScaleModelCompare:unknownScaleModel', ...
                'Unknown ScaleModel "%s".', sm);
    end
else
    mask = logical(sm);
end
end
