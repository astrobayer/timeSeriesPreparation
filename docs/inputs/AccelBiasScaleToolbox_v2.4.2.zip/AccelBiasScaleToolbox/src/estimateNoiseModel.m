function nm = estimateNoiseModel(r, varargin)
%ESTIMATENOISEMODEL  Fit an AR(p) model to regression residuals and report
%   how badly the iid assumption is violated.
%
%   nm = estimateNoiseModel(r)
%   nm = estimateNoiseModel(r, 'MaxOrder', 10, 'Order', [])
%
%   Both an accelerometer series and a modeled non-gravitational
%   acceleration series are smooth, so their difference is strongly
%   autocorrelated. Every default statistic in an OLS/IRLS fit (formal
%   sigmas, t-tests, AIC/BIC, GCV) assumes independent residuals and is
%   therefore optimistic -- often by a large factor. This function
%   quantifies the violation and produces the AR coefficients needed to
%   prewhiten (see PREWHITENSERIES) or to run GLS (see GLSLINEARFIT).
%
%   INPUT
%     r : Nx1 residual series, assumed on a (near-)uniform time grid
%
%   NAME-VALUE
%     'MaxOrder' (10)  largest AR order considered by AIC selection
%     'Order'    ([])  force a specific order, skipping selection
%     'MaxLags'  ([])  lags used for the ACF / n_eff sum
%                      (default min(N/4, 200))
%     'ExcludeMask' ([])  Nx1 logical; true = DROP this sample.
%
%       *** USE THIS FOR ACC_1B FILLED DATA. ***
%       The Level-1 processor fills ACC data gaps by CUBIC INTERPOLATION
%       over up to 200 points per side, for gaps as long as 100 s (ATBD
%       App. A and section 3, step 3), and flags the filled samples. Those
%       samples are not measurements: they are a smooth deterministic
%       curve. Feeding them to an autocorrelation estimator makes the
%       residual look far more correlated than it is, deflating n_eff and
%       inflating every error bar derived from it -- and if a filled span
%       is long, the AR fit is describing the interpolator rather than the
%       instrument. Pass the ACC_1B fill flag here so those samples are
%       excluded.
%
%       Excluded samples are removed before the ACF is formed. That
%       introduces a small discontinuity at each removal, which is
%       preferable to the alternative; if the filled fraction is large,
%       prefer BLOCKBOOTSTRAP, which does not need a noise model at all.
%
%   OUTPUT (struct)
%     .order        selected AR order p
%     .phi          px1 AR coefficients (r_t = sum phi_k r_{t-k} + e_t)
%     .sigma2       innovation variance
%     .aic          AIC per candidate order (0..MaxOrder)
%     .acf1         lag-1 autocorrelation of the raw residual
%     .nEff         effective sample size, n / (1 + 2*sum_k rho_k), with
%                   the sum truncated at the first non-positive rho
%     .nEffRatio    nEff / N. Formal sigmas computed under the iid
%                   assumption should be inflated by roughly
%                   sqrt(1/nEffRatio); AIC/BIC comparisons are unreliable
%                   when this is far below 1.
%     .verdict      'iid-like' (nEffRatio > 0.8) | 'mildly-correlated'
%                   (0.3-0.8) | 'strongly-correlated' (< 0.3)
%
%   Reference check (independent Python): for a true AR(2) process with
%   phi = [0.75, -0.20], this estimator recovered [0.765, -0.210];
%   prewhitening dropped the lag-1 autocorrelation from 0.632 to 0.005,
%   and nEffRatio was 0.33.
%
%   See also PREWHITENSERIES, GLSLINEARFIT, BLOCKBOOTSTRAP.

p = inputParser;
p.addParameter('MaxOrder', 10, @isnumeric);
p.addParameter('Order', [], @(x) isempty(x) || isnumeric(x));
p.addParameter('MaxLags', [], @(x) isempty(x) || isnumeric(x));
p.addParameter('ExcludeMask', [], @(x) isempty(x) || islogical(x) || isnumeric(x));
p.parse(varargin{:});
opt = p.Results;

r = r(:);
if ~isempty(opt.ExcludeMask)
    keep = ~logical(opt.ExcludeMask(:));
    if numel(keep) ~= numel(r)
        error('estimateNoiseModel:maskSize', ...
            'ExcludeMask has %d elements but the residual has %d.', ...
            numel(keep), numel(r));
    end
    r = r(keep);
end
r = r(isfinite(r));
n = numel(r);
if n < 20
    nm = struct('order',0,'phi',[],'sigma2',var(r),'aic',[], ...
        'acf1',NaN,'nEff',n,'nEffRatio',1,'verdict','indeterminate');
    return;
end

maxLags = opt.MaxLags;
if isempty(maxLags)
    maxLags = min(floor(n/4), 200);
end
rho = localACF(r, maxLags);   % rho(1) = lag 0 = 1

%% --- order selection by AIC ---
if isempty(opt.Order)
    pmax = min(opt.MaxOrder, floor(n/10));
    aic = inf(pmax+1, 1);
    for k = 0:pmax
        if k == 0
            s2 = var(r, 1);
        else
            [~, s2] = yuleWalker(rho, k, var(r,1));
        end
        s2 = max(s2, realmin);
        aic(k+1) = n*log(s2) + 2*k;
    end
    [~, iBest] = min(aic);
    order = iBest - 1;
else
    order = opt.Order;
    aic = [];
end

if order == 0
    phi = zeros(0,1);
    sigma2 = var(r, 1);
else
    [phi, sigma2] = yuleWalker(rho, order, var(r,1));
end

%% --- effective sample size ---
s = 0;
for k = 2:numel(rho)      % rho(2) = lag 1
    if rho(k) <= 0
        break;
    end
    s = s + rho(k);
end
nEff = n / (1 + 2*s);
nEffRatio = nEff / n;

if nEffRatio > 0.8
    verdict = 'iid-like';
elseif nEffRatio >= 0.3
    verdict = 'mildly-correlated';
else
    verdict = 'strongly-correlated';
end

nm.order = order;
nm.phi = phi;
nm.sigma2 = sigma2;
nm.aic = aic;
nm.acf1 = rho(min(2,numel(rho)));
nm.nEff = nEff;
nm.nEffRatio = nEffRatio;
nm.verdict = verdict;

end

% -------------------------------------------------------------------
function rho = localACF(x, nlags)
x = x(:) - mean(x);
n = numel(x);
nlags = min(nlags, n-1);
c = zeros(nlags+1,1);
for k = 0:nlags
    c(k+1) = sum(x(1:n-k) .* x(k+1:n)) / n;
end
if c(1) > 0
    rho = c / c(1);
else
    rho = [1; zeros(nlags,1)];
end
end

% -------------------------------------------------------------------
function [phi, sigma2] = yuleWalker(rho, p, varX)
%YULEWALKER  Solve the Yule-Walker equations R*phi = r for AR(p).
R = toeplitz(rho(1:p));       % rho(1)=1 at lag 0
rhs = rho(2:p+1);
phi = R \ rhs(:);
sigma2 = varX * (1 - phi' * rhs(:));
sigma2 = max(sigma2, realmin);
end
