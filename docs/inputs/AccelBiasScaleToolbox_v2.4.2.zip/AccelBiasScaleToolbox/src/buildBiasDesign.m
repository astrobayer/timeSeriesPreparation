function [B, info] = buildBiasDesign(t, biasModel)
%BUILDBIASDESIGN  Construct the bias design matrix: bias(t) = B * coef.
%
%   [B, info] = buildBiasDesign(t, biasModel)
%
%   biasModel.type is one of:
%
%     'constant'   B = ones(N,1). One parameter.
%
%     'polynomial' biasModel.order = p. Orthogonalized (QR) polynomial
%                  basis in centered/scaled time, degrees 0..p. The
%                  orthogonalization keeps high orders and long arcs
%                  well-conditioned; without it a raw Vandermonde in
%                  MJD is catastrophically ill-conditioned.
%
%     'spline'     biasModel.numInteriorKnots, .order (default 4),
%                  .placement ('uniform' | 'quantile', default
%                  'quantile'). Unpenalized B-spline basis; the knot
%                  count directly sets the flexibility.
%
%     'pspline'    Penalized spline. biasModel.numInteriorKnots should be
%                  deliberately GENEROUS (e.g. 30-40); flexibility is
%                  then controlled continuously by a roughness penalty
%                  rather than by the knot count. Extra fields:
%                    .penaltyOrder (default 2)  difference order
%                    .lambda       (default [])  if empty, the caller is
%                                  expected to select it (e.g. by
%                                  GCVSELECTLAMBDA or BLOCKEDCROSSVAL)
%                  This is the recommended type when the bias drift
%                  timescale is not known a priori.
%
%   OUTPUT
%     B    : N x nParams design matrix
%     info : .type, .nParams
%            .penalty     nParams x nParams penalty (zeros unless
%                         'pspline'); pass to GCVSELECTLAMBDA / the fit
%            .lambda      requested lambda ([] if unset)
%            .isPenalized true for 'pspline'
%            .knots       knot vector for spline types
%
%   Example
%     bm = struct('type','pspline','numInteriorKnots',35, ...
%                 'penaltyOrder',2,'placement','quantile');
%     [B, info] = buildBiasDesign(t, bm);
%     lam = gcvSelectLambda(B, y, info.penalty);
%
%   See also BSPLINEBASIS, DIFFPENALTYMATRIX, GCVSELECTLAMBDA.

t = t(:);
info = struct('type', lower(biasModel.type), 'nParams', 0, ...
    'penalty', [], 'lambda', [], 'isPenalized', false, 'knots', []);

switch lower(biasModel.type)

    case 'constant'
        B = ones(numel(t),1);

    case 'polynomial'
        p = biasModel.order;
        s = std(t);
        if s == 0, s = 1; end
        tc = (t - mean(t)) / s;
        V = tc .^ (0:p);
        [Q, ~] = qr(V, 0);      % same column space, orthonormal columns
        B = Q;

    case 'spline'
        ord = getOr(biasModel, 'order', 4);
        plc = getOr(biasModel, 'placement', 'quantile');
        [B, info.knots] = bsplineBasis(t, biasModel.numInteriorKnots, ord, plc);

    case 'pspline'
        ord = getOr(biasModel, 'order', 4);
        plc = getOr(biasModel, 'placement', 'quantile');
        [B, info.knots] = bsplineBasis(t, biasModel.numInteriorKnots, ord, plc);
        d = getOr(biasModel, 'penaltyOrder', 2);
        info.penalty = diffPenaltyMatrix(size(B,2), d);
        info.lambda = getOr(biasModel, 'lambda', []);
        info.isPenalized = true;

    otherwise
        error('buildBiasDesign:unknownType', ...
            'Unknown bias model type "%s".', biasModel.type);
end

info.nParams = size(B,2);
if isempty(info.penalty)
    info.penalty = zeros(info.nParams);
end

end

% -------------------------------------------------------------------
function v = getOr(s, f, dflt)
if isfield(s, f) && ~isempty(s.(f))
    v = s.(f);
else
    v = dflt;
end
end
