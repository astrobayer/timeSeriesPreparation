function result = analyzeAccScaleArc(obsFiles, modelFiles, varargin)
%ANALYZEACCSCALEARC  End-to-end accelerometer scale analysis for a GRACE-FO
%   arc of one or many days, in a single call.
%
%   result = analyzeAccScaleArc(obsFiles, modelFiles)
%   result = analyzeAccScaleArc(obsFiles, modelFiles, 'Name', Value, ...)
%
%   Reads the observed accelerometer product (ACC1B / ACT1B) and the
%   modeled non-gravitational acceleration (GROOPS instrument file),
%   reconciles their time systems, makes them CRN-filter-consistent,
%   fits a per-revolution scale factor per axis with observability
%   gating, and reports whether the scale is (a) constant, (b) a genuine
%   time drift, and (c) correlated with modeled drag magnitude -- the
%   signature that separates a force-model deficiency from a sensor
%   calibration error.
%
%   This is the streamlined form of the manual analysis: it is the one
%   call to make on real data. It accepts a single day or a list of
%   consecutive days transparently.
%
%   INPUT
%     obsFiles   - string array / cellstr / char. One or more GRACE-FO
%                  Level-1B observed-acceleration files (ACC1B or ACT1B
%                  ASCII, optionally .gz). Multiple files are read and
%                  concatenated with READGRACEFOL1BMULTI.
%     modelFiles - string array / cellstr / char. One or more GROOPS
%                  instrument-format modeled-force files, in the SAME day
%                  order as obsFiles (or a single file). Read with
%                  READGROOPSINSTRUMENT.
%
%   NAME-VALUE
%     'Product'      ('ACC')   CRN preset for filter consistency
%     'FilterModel'  (true)    CRN-filter the model to match ACC1B's band.
%                              The observed product is already filtered;
%                              set false only to reproduce a raw comparison.
%     'OrbitPeriod'  (5400)    nominal revolution length [s], for the
%                              per-revolution windows
%     'MinObsRelRange' (0.02)  a revolution/axis with model dynamic range
%                              below this (std/|mean|) is marked
%                              unobservable and its scale set to NaN
%     'InterpMethod' ('pchip') model->obs interpolation (amplitude-
%                              preserving; 'linear' biases scale low)
%     'TimeVariable' ("")      forwarded to the L1B reader if needed
%     'Plot'         (true)    draw the summary figures
%     'Verbose'      (true)    print the summary
%     'Save'         ('')      if non-empty, save the result struct there
%                              via ACCELCALIBRATIONIO
%
%   OUTPUT (struct)
%     .scaleGlobal      1x3, whole-arc diagonal scale factor per axis
%     .scaleGlobalCI    3x2, block-bootstrap 95% CI per axis
%     .scaleGlobalSigma 1x3, block-bootstrap 1-sigma
%     .sigmaInflation   1x3, bootstrap sigma / naive iid sigma (how
%                       optimistic naive error bars would have been)
%     .bias             1x3, whole-arc fitted bias per axis [m/s^2]
%     .perRev           struct with per-revolution results:
%                         .tMid       Rx1 window-center time [s from start]
%                         .scale      Rx3 per-rev diagonal scale (NaN where
%                                     unobservable)
%                         .observable Rx3 logical
%                         .dragMag    Rx1 mean modeled |a| per rev
%                         .std        1x3 std of per-rev scale (observable)
%                         .driftSNR   1x3 per-rev std / expected-from-noise
%                         .isDrift    1x3 logical, drift resolved above noise
%     .dragCorr         1x3, corr(per-rev scale, per-rev drag magnitude)
%     .dragCorrCI       3x2, bootstrap 95% CI of that correlation
%     .interpretation   1x3 cellstr, per-axis plain-language verdict
%     .decomp           polar decomposition of the whole-arc full-S matrix
%     .frameCheck       ACCFRAMETOSRF('check', S) result
%     .accel            struct with the two input accelerations, on the
%                       common analysis grid actually used for the fit
%                       (after time-reconciliation, CRN filtering and
%                       observability windowing), so both are directly
%                       comparable:
%                         .t        Nx1  time [s from first obs midnight]
%                         .obs      Nx3  observed acceleration  y_obs [m/s^2]
%                         .model    Nx3  modeled acceleration on the obs
%                                        grid, CRN-filtered if FilterModel
%                                        (the regressor y_mod actually used)
%                         .axisNames 1x3 cellstr axis labels
%                         .filtered logical, true if .model was CRN-filtered
%     .correction       struct: the estimated calibration correction that
%                       reconciles the two input series, from the whole-arc
%                       demeaned diagonal fit y_obs = bias + S.*y_mod:
%                         .scale        1x3  fitted diagonal scale S
%                         .bias         1x3  fitted bias b [m/s^2]
%                         .scalePpm     1x3  (S-1)*1e6, scale error [ppm]
%                         .obsToModel   struct, correction that maps the
%                                       OBSERVATION into model-comparable
%                                       units, y_mod ~= (y_obs-bias)./S:
%                                         .scaleFactor 1x3  = 1./S
%                                         .biasOffset  1x3  = -bias./S
%                                         .apply  fn handle @(yobs) ...
%                                                 = (yobs - bias)./S
%                         .modelToObs   struct, correction that predicts the
%                                       OBSERVATION from the model,
%                                       y_obs ~= bias + S.*y_mod:
%                                         .scaleFactor 1x3  = S
%                                         .biasOffset  1x3  = bias
%                                         .apply  fn handle @(ymod) ...
%                                                 = bias + S.*ymod
%                         .residualStd  1x3  std of y_obs-(bias+S.*y_mod)
%                                            over the analysis grid [m/s^2]
%                         .ci           3x2  block-bootstrap 95% CI on S
%                         .sigma        1x3  block-bootstrap 1-sigma on S
%                         .caveat       char, interpretation warning
%                       NOTE: this is a per-axis diagonal correction. Off-
%                       diagonal (cross-axis) coupling lives in .Sfull /
%                       .decomp, which is untrustworthy over a single day
%                       (see .flags). For a density/Cd force-model issue the
%                       correct action is NOT to apply this scale as an
%                       instrument fix -- see .interpretation.
%     .nDays, .nSamples, .nRevs
%     .startMJD         integer MJD of the first observed midnight; the
%                       absolute-time anchor for perRev.tMid (seconds from
%                       startMJD). Feed this to LOADSPACEWEATHERINDICES.
%     .obsAux, .modelAux   provenance from the readers
%     .provenance       struct: run time/date, toolbox and Claude version
%                       under which this analysis code was authored
%     .flags            consolidated caveats
%
%   INTERPRETATION (encoded in .interpretation)
%     scale ~ 1, flat, no drag corr   -> well calibrated, good model
%     scale != 1, flat, no drag corr  -> a genuine sensor scale error
%     scale varies, anti-corr w/ drag -> FORCE-MODEL (density/Cd) issue on
%                                         the drag axes; NOT the sensor
%     scale drifts, no drag corr      -> sensor drift / aging (or thermal)
%
%   A SINGLE DAY CANNOT separate a density-model error from a Cd error
%   from a real slow drift that merely tracks the orbital drag cycle; the
%   drag magnitude varies only ~10% and only with orbital phase. For that
%   separation, run several days spanning varied solar/geomagnetic
%   activity and regress the per-rev scale against Kp/F10.7/beta (see the
%   note in .flags when only one day is supplied).
%
%   EXAMPLE
%     % single day
%     r = analyzeAccScaleArc('ACT1B_2020-01-01_C_04.txt', ...
%                            'GRACEFO-1_nonConservativeForces_2020-01-01.txt');
%     disp(r.interpretation')
%
%     % multi-day arc
%     obs   = compose("ACT1B_2020-01-%02d_C_04.txt", 1:31);
%     model = compose("GRACEFO-1_nonConservativeForces_2020-01-%02d.txt", 1:31);
%     r = analyzeAccScaleArc(obs, model);
%
%   See also READGRACEFOL1B, READGRACEFOL1BMULTI, READGROOPSINSTRUMENT,
%            CRNFILTER, APPLYCRNFILTER, DECOMPOSESCALEMATRIX,
%            ACCFRAMETOSRF, BLOCKBOOTSTRAP, ACCELCALIBRATIONIO.
%
%   ---------------------------------------------------------------------
%   Authoring provenance (this revision, adding .accel/.correction outputs)
%     Date      : 2026-07-15
%     Time      : 14:00 UTC
%     Author    : Claude (Anthropic), model Claude Opus 4.8
%     Toolbox   : AccelBiasScaleToolbox
%   The per-run execution time/date is recorded at call time in
%   result.provenance; the stamp above records when this code was written.
%   ---------------------------------------------------------------------

ip = inputParser;
ip.addParameter('Product', 'ACC', @ischar);
ip.addParameter('FilterModel', true, @islogical);
ip.addParameter('OrbitPeriod', 5400, @isnumeric);
ip.addParameter('MinObsRelRange', 0.02, @isnumeric);
ip.addParameter('InterpMethod', 'pchip', @ischar);
ip.addParameter('TimeVariable', "", @(x) ischar(x) || isstring(x));
ip.addParameter('Plot', true, @islogical);
ip.addParameter('Verbose', true, @islogical);
ip.addParameter('Save', '', @ischar);
ip.parse(varargin{:});
opt = ip.Results;

obsFiles = string(obsFiles);
modelFiles = string(modelFiles);
flags = {};

%% ---- 1. read observed acceleration ----
if numel(obsFiles) == 1
    [tObs, obs, obsAux] = readGraceFoL1b(obsFiles, 'TimeVariable', opt.TimeVariable);
    obsAux.obsNames = obsAux.obsNames;
else
    [tObs, obs, obsAux] = readGraceFoL1bMulti(obsFiles, 'TimeVariable', opt.TimeVariable);
end
% keep only the 3 linear-acceleration columns
linIdx = findLinAccCols(obsAux.obsNames);
if numel(linIdx) < 3
    error('analyzeAccScaleArc:noLinAcc', ...
        'Could not find 3 linear-acceleration columns in the observed product (found names: %s).', ...
        strjoin(obsAux.obsNames, ', '));
end
Aobs = obs(:, linIdx(1:3));

%% ---- 2. read modeled forces ----
tModAll = cell(numel(modelFiles),1);
AmodAll = cell(numel(modelFiles),1);
for i = 1:numel(modelFiles)
    [tm, am, modelAux] = readGroopsInstrument(modelFiles(i));
    tModAll{i} = tm; AmodAll{i} = am(:,1:3);
end
tMod = vertcat(tModAll{:});
Amod = vertcat(AmodAll{:});

%% ---- 3. time-system reconciliation ----
% Both products carry [intMJD, secOfDay]. Observed is GPS-based; the GROOPS
% model MJD may be GPS or another continuous scale. Rather than assume a
% leap-second offset, align on the shared day structure: convert each to an
% absolute second count from the first observed integer-MJD midnight, then
% (if needed) refine by cross-correlating the along-track signals. Within a
% day the leap-second offset (~18 s) is negligible against the CRN band, but
% we refine anyway to catch a gross time error.
day0 = tObs(1,1);
sObs = (tObs(:,1) - day0)*86400 + tObs(:,2);
sMod = (tMod(:,1) - day0)*86400 + tMod(:,2);

% coarse+fine lag from the strongest (along-track) axis, AC-coupled
lag = estimateLag(sObs, Aobs(:,1), sMod, Amod(:,1), opt.OrbitPeriod);
sMod = sMod + lag;
if abs(lag) > 5
    flags{end+1} = sprintf(['A model/observation time offset of %.1f s was ' ...
        'detected and removed by cross-correlation. Verify your time-system ' ...
        'handling -- a residual offset biases every scale factor.'], lag);
end

%% ---- 4. CRN filter consistency ----
[h, hInfo] = crnFilter(opt.Product);
if opt.FilterModel
    % lift model to the kernel's working rate, filter, sample at obs epochs
    fs = hInfo.fs;
    tw = (sMod(1):1/fs:sMod(end)).';
    Mw = zeros(numel(tw),3);
    for k = 1:3
        Mw(:,k) = interp1(sMod, Amod(:,k), tw, opt.InterpMethod);
    end
    for k = 1:3
        Mw(:,k) = centredConv(Mw(:,k), h);
    end
    edge = hInfo.spanSeconds/2;   % drop CRN half-span at each end
    valid = sObs >= tw(1)+edge & sObs <= tw(end)-edge;
    Amod_on = zeros(nnz(valid),3);
    for k = 1:3
        Amod_on(:,k) = interp1(tw, Mw(:,k), sObs(valid), opt.InterpMethod);
    end
else
    valid = sObs >= sMod(1) & sObs <= sMod(end);
    Amod_on = zeros(nnz(valid),3);
    for k = 1:3
        Amod_on(:,k) = interp1(sMod, Amod(:,k), sObs(valid), opt.InterpMethod);
    end
    flags{end+1} = ['FilterModel=false: the model was NOT CRN-filtered, so it ' ...
        'is compared against ACC1B in a different spectral band. Scale factors ' ...
        'are biased. Set FilterModel=true unless you know why not.'];
end

t = sObs(valid);
Y1 = Aobs(valid,:);
Y2 = Amod_on;
n = numel(t);
nDays = round((tObs(end,1)-tObs(1,1)) + (tObs(end,2)-tObs(1,2))/86400);
nDays = max(1, nDays);

%% ---- 5. whole-arc fit: diagonal + full, demeaned ----
[Sdiag, bias] = fitDiagonal(Y1, Y2);
[Sfull, ~]    = fitFull(Y1, Y2);

%% ---- 6. block-bootstrap uncertainty on the diagonal scale ----
[sig, ci, inflation] = bootstrapScale(Y1, Y2, opt.OrbitPeriod);

%% ---- 7. per-revolution, observability-gated ----
per = perRevolution(t, Y1, Y2, opt.OrbitPeriod, opt.MinObsRelRange);

%% ---- 8. drag correlation ----
dragCorr = nan(1,3); dragCorrCI = nan(3,2);
for i = 1:3
    m = isfinite(per.scale(:,i));
    if nnz(m) >= 4
        dragCorr(i) = corr(per.scale(m,i), per.dragMag(m));
        dragCorrCI(i,:) = bootCorr(per.scale(m,i), per.dragMag(m));
    end
end

%% ---- 9. decomposition + frame check ----
decomp = decomposeScaleMatrix(Sfull);
frameCheck = accFrameToSRF('check', Sfull);
if ~strcmp(frameCheck.verdict, 'plausible')
    flags{end+1} = frameCheck.message;
end

%% ---- 10. per-axis interpretation ----
interp = cell(1,3);
axNames = {'X (along-track)','Y (cross-track)','Z (radial)'};
for i = 1:3
    interp{i} = interpretAxis(Sdiag(i), per.isDrift(i), dragCorr(i), dragCorrCI(i,:), axNames{i});
end

%% ---- caveats ----
if nDays <= 1
    flags{end+1} = ['Single day: modeled drag varies only ~10% and only with ' ...
        'orbital phase, so a density-model error, a Cd error, and a real slow ' ...
        'scale drift are NOT separable here. Run several days spanning varied ' ...
        'F10.7/Kp and regress per-rev scale against them to separate the causes.'];
end
if any(abs([dragCorr]) > 0.5)
    flags{end+1} = ['Scale correlates with modeled drag magnitude on at least one ' ...
        'axis -- the disagreement is structured and drag-dependent, pointing at ' ...
        'the FORCE MODEL (density/Cd) rather than a sensor scale error.'];
end
mi = max(inflation);
if mi > 3
    flags{end+1} = sprintf(['Naive iid error bars are up to %.0fx too small; the ' ...
        'model is smooth so residuals are strongly autocorrelated. Reported CIs ' ...
        'are block-bootstrap.'], mi);
end

%% ---- 11. estimated correction from comparing the two inputs ----
% The whole-arc demeaned diagonal fit  y_obs = bias + S .* y_mod  IS the
% estimated calibration correction. Expose it in both directions plus
% ready-to-use function handles, so the caller does not re-derive it.
correction = buildCorrection(Sdiag, bias, sig, ci, Y1, Y2, dragCorr, dragCorrCI);

%% ---- assemble ----
result.scaleGlobal = Sdiag;
result.scaleGlobalSigma = sig;
result.scaleGlobalCI = ci;
result.sigmaInflation = inflation;
result.bias = bias;
result.Sfull = Sfull;
result.perRev = per;
result.startMJD = day0;   % integer MJD of the first observed midnight; the
                          % anchor for perRev.tMid (= seconds from startMJD)
result.dragCorr = dragCorr;
result.dragCorrCI = dragCorrCI;
result.interpretation = interp;
result.decomp = decomp;
result.frameCheck = frameCheck;
result.correction = correction;
result.accel = struct( ...
    't',         t, ...
    'obs',       Y1, ...
    'model',     Y2, ...
    'axisNames', {axNames}, ...
    'filtered',  logical(opt.FilterModel));
result.nDays = nDays;
result.nSamples = n;
result.nRevs = size(per.scale,1);
result.timeLag = lag;
result.crnInfo = hInfo;
result.obsAux = obsAux;
result.modelAux = modelAux;
runNow = datetime('now');
result.provenance = struct( ...
    'runDatetime',    char(runNow, 'yyyy-MM-dd HH:mm:ss'), ...
    'runDatenum',     datenum(runNow), ...
    'toolbox',        'AccelBiasScaleToolbox', ...
    'codeAuthored',   '2026-07-15', ...
    'claudeVersion',  'Claude Opus 4.8 (Anthropic)', ...
    'filterProduct',  hInfo.product, ...
    'filterDCGain',   hInfo.dcGain);
result.flags = unique(flags, 'stable');

%% ---- report / plot / save ----
if opt.Verbose,  printSummary(result, axNames); end
if opt.Plot,     plotScaleArc(result, t, Y1, Y2); end
if ~isempty(opt.Save)
    fitLike.S = diag(Sdiag); fitLike.covS = []; fitLike.decomp = decomp;
    fitLike.axis = struct('scaleCoef', num2cell(Sdiag), ...
        'sigmaInflation', num2cell(inflation));
    accelCalibrationIO('save', opt.Save, fitLike, 'Meta', ...
        struct('nDays', nDays, 'dragCorr', dragCorr, ...
               'filterProduct', hInfo.product, 'filterDCGain', hInfo.dcGain));
end

end

% ===================================================================
% helpers
% ===================================================================
function idx = findLinAccCols(names)
idx = find(~cellfun('isempty', regexpi(names, '^lin_accl_[xyz]$', 'once')));
if numel(idx) < 3
    % fall back to the first three columns whose name contains x/y/z accel
    idx = find(~cellfun('isempty', regexpi(names, 'acc.*[xyz]|[xyz].*acc', 'once')));
end
if numel(idx) < 3
    idx = 1:min(3, numel(names));   % last resort: first three columns
end
end

% -------------------------------------------------------------------
function lag = estimateLag(sObs, aObs, sMod, aMod, Torb)
% cross-correlate AC-coupled along-track on a common grid to find a lag
dt = 10;                                   % model rate is coarse; 10 s grid
tg = (max(sObs(1),sMod(1)) : dt : min(sObs(end),sMod(end))).';
if numel(tg) < 100, lag = 0; return; end
o = interp1(sObs, aObs, tg, 'linear'); o = o - mean(o,'omitnan');
m = interp1(sMod, aMod, tg, 'linear'); m = m - mean(m,'omitnan');
ok = isfinite(o) & isfinite(m); o = o(ok); m = m(ok);
maxLag = round(Torb/dt);                   % search +/- one revolution
[c, lags] = xcorr(o, m, maxLag, 'coeff');
[~, iM] = max(c);
lag = lags(iM) * dt;
end

% -------------------------------------------------------------------
function [S, b] = fitDiagonal(Y1, Y2)
S = zeros(1,3); b = zeros(1,3);
for i = 1:3
    mu = mean(Y2(:,i));
    X = [ones(size(Y2,1),1), Y2(:,i)-mu];
    c = X \ Y1(:,i);
    S(i) = c(2); b(i) = c(1) - c(2)*mu;
end
end

% -------------------------------------------------------------------
function [S, b] = fitFull(Y1, Y2)
mu = mean(Y2,1); Yc = Y2 - mu;
S = zeros(3,3); b = zeros(1,3);
for i = 1:3
    X = [ones(size(Y2,1),1), Yc];
    c = X \ Y1(:,i);
    S(i,:) = c(2:4).'; b(i) = c(1) - c(2:4).'*mu.';
end
end

% -------------------------------------------------------------------
function c = buildCorrection(Sdiag, bias, sig, ci, Y1, Y2, dragCorr, dragCorrCI)
% Package the whole-arc diagonal calibration (bias, S) as an estimated
% correction, in both directions, with apply() handles and a caveat.
S = Sdiag(:).'; b = bias(:).';

% residual of the forward model  y_obs = b + S.*y_mod  on the analysis grid
resid = Y1 - (b + Y2 .* S);
residStd = std(resid, 0, 1);

% direction 1: OBSERVATION -> model-comparable units,  y_mod = (y_obs-b)./S
o2m = struct( ...
    'scaleFactor', 1 ./ S, ...
    'biasOffset',  -b ./ S, ...
    'apply',       @(yobs) (yobs - b) ./ S);

% direction 2: MODEL -> observation prediction,  y_obs = b + S.*y_mod
m2o = struct( ...
    'scaleFactor', S, ...
    'biasOffset',  b, ...
    'apply',       @(ymod) b + S .* ymod);

% caveat: a drag-correlated scale is a force-model signature, not a fix
if any(isfinite(dragCorr) & abs(dragCorr) > 0.4 & (dragCorrCI(:,1).'.*dragCorrCI(:,2).' > 0))
    caveat = ['At least one axis scale correlates with modeled drag: this ' ...
        'correction reflects a FORCE-MODEL (density/Cd) deficiency, not a ' ...
        'sensor miscalibration. Do NOT apply it as an instrument scale fix; ' ...
        'use it diagnostically and correct the force model instead.'];
else
    caveat = ['Diagonal, whole-arc correction. Verify observability and, for ' ...
        'an instrument fix, confirm the scale is stable and drag-independent.'];
end

c = struct( ...
    'scale',       S, ...
    'bias',        b, ...
    'scalePpm',    (S - 1) * 1e6, ...
    'obsToModel',  o2m, ...
    'modelToObs',  m2o, ...
    'residualStd', residStd, ...
    'ci',          ci, ...
    'sigma',       sig, ...
    'caveat',      caveat);
end

% -------------------------------------------------------------------
function [sig, ci, inflation] = bootstrapScale(Y1, Y2, Torb)
n = size(Y1,1);
blk = min(round(Torb), max(10, floor(n/5)));
nboot = 300;
[S0, b0] = fitDiagonal(Y1, Y2);
pred = b0 + Y2 .* S0;          % per-axis predictor
res = Y1 - pred;
maxStart = n - blk + 1;
nblk = ceil(n/blk);
boot = zeros(nboot,3);
for bI = 1:nboot
    idx = zeros(nblk*blk,1);
    st = randi(maxStart, nblk, 1);
    for k = 1:nblk
        idx((k-1)*blk + (1:blk)) = st(k) + (0:blk-1);
    end
    idx = idx(1:n);
    Yb = pred + res(idx,:);
    boot(bI,:) = fitDiagonal(Yb, Y2);
end
sig = std(boot,0,1);
ci = [quantile(boot,0.025,1).', quantile(boot,0.975,1).'];
% naive iid sigma, computed on a standardized regressor for numerical
% stability (raw accelerations are ~1e-8, so [1, Y2] is badly scaled and
% inv(X'X) triggers RCOND warnings and inaccurate variances). Standardizing
% the slope column and rescaling the resulting standard error back is exact
% and well-conditioned.
ns = zeros(1,3);
for i = 1:3
    xi = Y2(:,i);
    s = std(xi);
    if s <= 0, ns(i) = realmin; continue; end
    xz = (xi - mean(xi)) / s;             % standardized slope regressor
    X = [ones(n,1), xz];
    [Q, Rm] = qr(X, 0);
    c = Rm \ (Q.' * Y1(:,i));
    resi = Y1(:,i) - X*c;
    dof = max(n - 2, 1);
    sigma2 = (resi.' * resi) / dof;
    Rinv = Rm \ eye(2);
    covB = sigma2 * (Rinv * Rinv.');      % cov in standardized units
    ns(i) = sqrt(covB(2,2)) / s;          % rescale slope SE back to raw units
end
inflation = sig ./ max(ns, realmin);
end

% -------------------------------------------------------------------
function per = perRevolution(t, Y1, Y2, Torb, minRel)
t0 = t(1);
nRev = floor((t(end)-t0)/Torb);
per.tMid = nan(nRev,1);
per.scale = nan(nRev,3);
per.observable = false(nRev,3);
per.dragMag = nan(nRev,1);
for r = 1:nRev
    sel = t >= t0+(r-1)*Torb & t < t0+r*Torb;
    if nnz(sel) < 50, continue; end
    per.tMid(r) = (r-0.5)*Torb;
    per.dragMag(r) = mean(sqrt(sum(Y2(sel,:).^2,2)));
    for i = 1:3
        m = Y2(sel,i); o = Y1(sel,i);
        mc = m - mean(m);
        rel = std(mc)/max(abs(mean(m)), realmin);
        if abs(mean(m)) > 1e-12 && rel < minRel
            continue;   % unobservable this rev/axis
        end
        X = [ones(nnz(sel),1), mc];
        c = X \ o;
        per.scale(r,i) = c(2);
        per.observable(r,i) = true;
    end
end
per.std = nan(1,3); per.driftSNR = nan(1,3); per.isDrift = false(1,3);
for i = 1:3
    v = per.scale(isfinite(per.scale(:,i)),i);
    if numel(v) > 3
        per.std(i) = std(v);
        % expected per-rev scatter from noise: residual std / (sqrt(Nrev)*modelStd)
        expSig = median(estPerRevSigma(t, Y1(:,i), Y2(:,i), Torb));
        per.driftSNR(i) = per.std(i) / max(expSig, realmin);
        per.isDrift(i) = per.driftSNR(i) > 3;
    end
end
end

% -------------------------------------------------------------------
function s = estPerRevSigma(t, y1, y2, Torb)
mu = mean(y2); X = [ones(numel(y2),1), y2-mu];
c = X\y1; res = y1 - X*c;
t0 = t(1); nRev = floor((t(end)-t0)/Torb);
s = nan(nRev,1);
for r = 1:nRev
    sel = t >= t0+(r-1)*Torb & t < t0+r*Torb;
    if nnz(sel) < 50, continue; end
    ms = std(y2(sel)-mean(y2(sel)));
    if ms > 0
        s(r) = std(res(sel)) / (sqrt(nnz(sel))*ms);
    end
end
s = s(isfinite(s));
end

% -------------------------------------------------------------------
function ci = bootCorr(x, y)
n = numel(x); nb = 2000; cc = nan(nb,1);
for b = 1:nb
    idx = randi(n, n, 1);
    if numel(unique(idx)) > 3
        cc(b) = corr(x(idx), y(idx));
    end
end
cc = cc(isfinite(cc));
ci = [quantile(cc,0.025), quantile(cc,0.975)];
end

% -------------------------------------------------------------------
function txt = interpretAxis(scale, isDrift, dragCorr, dragCI, name)
dev = (scale-1)*100;
sigCorr = isfinite(dragCorr) && (dragCI(1)*dragCI(2) > 0); % CI excludes 0
if sigCorr && abs(dragCorr) > 0.4
    txt = sprintf(['%s: scale %.3f (%+.1f%%). Scale correlates with drag ' ...
        '(r=%.2f) -> FORCE-MODEL (density/Cd) deficiency, not a sensor error.'], ...
        name, scale, dev, dragCorr);
elseif isDrift
    txt = sprintf(['%s: scale %.3f (%+.1f%%). Scale drifts in time but not with ' ...
        'drag -> possible sensor drift/thermal; needs multi-day data to confirm.'], ...
        name, scale, dev);
elseif abs(dev) > 2
    txt = sprintf(['%s: scale %.3f (%+.1f%%), stable and drag-independent -> ' ...
        'consistent with a genuine sensor scale error.'], name, scale, dev);
else
    txt = sprintf('%s: scale %.3f (%+.1f%%), stable -> well calibrated.', name, scale, dev);
end
end

% -------------------------------------------------------------------
function y = centredConv(x, h)
h = h(:); Nh = (numel(h)-1)/2; n = numel(x);
np = min(round(Nh), n-1);
if np < 1, y = x; return; end
xp = [2*x(1)-flipud(x(2:np+1)); x; 2*x(end)-flipud(x(end-np:end-1))];
yf = conv(xp, h, 'same');
y = yf(np+1:np+n);
end

% -------------------------------------------------------------------
function printSummary(r, axNames)
fprintf('\n===== analyzeAccScaleArc: %d day(s), %d rev(s), %d samples =====\n', ...
    r.nDays, r.nRevs, r.nSamples);
if abs(r.timeLag) > 0.5
    fprintf('time offset removed: %.2f s\n', r.timeLag);
end
for i = 1:3
    fprintf('  %-16s scale %.4f  95%% CI [%.4f, %.4f]  (sigma x%.1f)  per-rev std %.3f%s\n', ...
        axNames{i}, r.scaleGlobal(i), r.scaleGlobalCI(i,1), r.scaleGlobalCI(i,2), ...
        r.sigmaInflation(i), r.perRev.std(i), ternary(r.perRev.isDrift(i),'  [DRIFT]',''));
    if isfinite(r.dragCorr(i))
        fprintf('       corr(scale, drag) = %+.2f  95%% CI [%+.2f, %+.2f]\n', ...
            r.dragCorr(i), r.dragCorrCI(i,1), r.dragCorrCI(i,2));
    end
end
fprintf('\nEstimated correction  (y_obs = bias + S .* y_mod):\n');
for i = 1:3
    fprintf('  %-16s S = %.4f (%+.0f ppm)  bias = %+.3e m/s^2  | obs->model: (y-%.3e)/%.4f\n', ...
        axNames{i}, r.correction.scale(i), r.correction.scalePpm(i), ...
        r.correction.bias(i), r.correction.bias(i), r.correction.scale(i));
end
fprintf('  %s\n', wrapCaveat(r.correction.caveat));

fprintf('\nInterpretation:\n');
for i = 1:3, fprintf('  %s\n', r.interpretation{i}); end
if ~isempty(r.flags)
    fprintf('\nCaveats:\n');
    for k = 1:numel(r.flags), fprintf('  [!] %s\n', r.flags{k}); end
end
fprintf('================================================================\n');
end

function o = ternary(c,a,b), if c, o=a; else, o=b; end, end

function s = wrapCaveat(txt)
% soft-wrap a caveat to ~76 cols for the console, indented under a [note]
s = ['[note] ' regexprep(txt, '(.{1,70})(\s+|$)', '$1\n         ')];
s = regexprep(s, '\n\s*$', '');
end
