# AccelBiasScaleToolbox

> **New here? Read [`ROADMAP.md`](ROADMAP.md) first** — it orients you in one page:
> what the toolbox found, the single-call entry point, and the recommended next step.

Diagnostics and estimation for observed vs. modeled non-gravitational accelerations
(GRACE-FO ACC1B against a force model such as `satforce`).

## The premise

A scale factor that "varies a lot" while bias stays stable is, more often than not,
**an estimation artifact rather than physics**. This toolbox is built to tell those two
apart *before* you commit to an expensive adjustment.

## Quick start

The simplest path is the one-call wrapper, which applies every default this toolbox's analysis
established, in the right order:

```matlab
addpath('src');
out = analyzeAccArc(tAcc, Yacc, tMod, Ymod, 'Save', 'arc001.mat');
disp(out.summary);      % scales, misalignment, per-axis noise verdict
disp(out.flags);        % consolidated caveats
```

Or drive the pieces yourself:


```matlab
addpath('src');
[tObs, Yobs, tMod, Ymod] = syntheticAccelPair();     % or load your own
report = accelSeriesPreflight(tObs, Yobs, tMod, Ymod, ...
    'InterpMethod', 'pchip', 'FilterStrategy', 'commonmode');
```

Read `report.axis(k).flags`. Then `examples/example_02_modelChoice.m`.

## Multi-day: naming the cause of a drifting scale

On a single day, a scale that anti-correlates with drag is a force-model signature, but the
day cannot say *which* term is wrong. Over several days spanning varied space weather, it can.
Feed a multi-day arc's per-rev scale, plus the matching space-weather indices, to
`scaleFactorDiagnostics`, which regresses one against the other and names the cause per axis
(density-model error / Cd-geometry error / sensor drift):

```matlab
addpath('src');
r  = analyzeAccScaleArc(obsFiles, modelFiles, 'Plot', false);   % many days
ix = loadSpaceWeatherIndices(r, 'File', 'Kp_ap_Ap_SN_F107_since_1932.txt', ...
                             'Extra', struct('beta', betaPerRev, 'argLat', argLatPerRev));
d  = scaleFactorDiagnostics(r, ix);
disp(d.summary');       % per-axis verdict: density / geometry / sensor / mixed / unresolved
```

`loadSpaceWeatherIndices` parses the GFZ combined daily file and maps F10.7/F10.7a/Kp/Ap/SN
onto each per-rev window via `r.startMJD` + `r.perRev.tMid`; orbit geometry (β, arg-of-lat,
Dst) merges in through `'Extra'`. See `examples/example_07_multiDayDiagnostics.m` for the full
end-to-end run. `analyzeAccScaleArc` also now returns `.accel` (the observed and modeled
series on the common analysis grid) and `.correction` (the estimated bias+scale calibration,
in both obs→model and model→obs directions, with ready-to-use `apply` handles).

## The filter is now exact

`crnFilter` implements the CRN filter **exactly** as specified in the GRACE Level-1B ATBD
(JPL D-27672, App. B): ACC uses `fs=10 Hz, Nc=7, Tf=140.7 s → 1407 taps, NB=5`, realised
bandwidth `NB/Tf = 0.03554 Hz`.

This matters more than it sounds. An *approximate* CRN filter — the kind one would naturally
construct — leaves a **−11.5% scale error** (measured; truth 1.000 → 0.885). That is larger
than the density/Cd errors one would otherwise be hunting, and it looks exactly like physics.
With the exact kernel the recovered scale is **1.0000**.

**Two traps worth knowing:**

- **The filter is normalised at f0 = 0.37 mHz — which is exactly 2/rev, the J2 line — not at
  DC.** Its true DC gain is **1.0004533**. The response simply droops (DC +453 ppm, 1/rev
  +340 ppm, 2/rev 0, 3/rev −568 ppm); the normalisation only chooses where it crosses 1.

  This does **not** entangle bias with scale. Filter the model with the *same* kernel the L1
  processor used and the scale comes back exactly (measured: −0.0 ppm). But the fitted scale is
  inversely proportional to the regressor's overall gain — so **renormalising the kernel to unit
  DC gain (`sum(h)=1`), the natural thing to do, multiplies your scale by 1.0004533: a +453 ppm
  error.** That was the v2.0 bug.

  One irreducible residue: the fitted *bias* is `1.0004533 × b_true`. Harmless — it's a nuisance
  parameter — unless you compare it against an independently known physical bias, in which case
  divide it out.

- **The bias design matrix must be filtered too.** The correct design is `[H·B, H·a]`, since the
  bias in ACC1B has itself been filtered. Pass `'BiasFilter', h` to `accelBiasScaleModelFit`.
  Measured cost of omitting it: <10 ppm when bias knots are spaced at or above the 140.7 s kernel
  span, but **−1377 ppm at 70 s spacing**. This also gives a hard identifiability floor: **never
  place bias knots closer than the kernel span** — bias structure that fast cannot exist in ACC1B,
  so those coefficients estimate the filter's null space.
- **The ACC→SRF axis relabelling is a proper rotation** (det = +1, 120° about (1,1,1)). Forget
  it, or apply it twice, and it hides inside a fitted `S` as a well-formed "misalignment" —
  the fit will not complain. `accFrameToSRF('check', S)` catches it. A real misalignment is
  milliradians; if you see *degrees*, it's bookkeeping, not physics.

## The four findings that motivated the design

Each was verified numerically against an independent Python implementation
(`scipy`-based) before the MATLAB was written.

1. **Scale is often not observable at all.** In the model `y_obs = bias + scale*y_mod`,
   scale is identifiable only where `y_mod` *varies*. In a quiet window (low drag, no
   eclipse crossing) `y_mod ≈ const`, and `bias + scale*const` is one number written two
   ways: bias and scale become collinear, and least squares returns an arbitrary point in
   a flat valley. Scale swings; bias absorbs the compensating change. `scaleObservability`
   detects this and `slidingWindowFit` returns `NaN` rather than inventing a number.
   *Demeaning the regressor within each window is free and fixes the induced correlation.*

2. **Filter mismatch leaks into scale.** ACC1B is low-pass filtered and decimated by the
   L1 processor; a pointwise-evaluated force model is not. The model's excess broadband
   power is partially absorbed by the scale parameter. `filterConsistency` offers
   `'explicit'` (needs the true ACC1B coefficients), `'commonmode'` (safe, needs nothing),
   and `'empirical'` (diagnostic only).

3. **Naive error bars are ~5x too small.** Both series are smooth, so residuals are
   strongly autocorrelated and `n_eff << n`. In a reference AR(1) ρ=0.95 experiment,
   honest block-bootstrap sigmas were **5.5–6.5× larger** than the naive iid sigmas. Every
   formal sigma, t-test, AIC, BIC and GCV computed under the iid assumption is optimistic
   by roughly that factor. Use `glsLinearFit` (feasible GLS, AR noise model),
   `blockBootstrap`, and `blockedCrossVal`.

4. **AIC/BIC systematically over-select complex bias models** for the same reason, and
   random-fold CV is even worse (a held-out point sits microseconds from a training point,
   so an overfit model interpolates it perfectly). `accelBiasScaleModelCompare` therefore
   ranks by **contiguous-block CV**. AIC/BIC are reported for reference only, and flagged
   as unreliable whenever the noise diagnostic says the residuals are correlated — which
   it almost always will.

## Reading the fitted scale matrix

Don't read the raw entries of a dense 3×3 `S` — the three modeled axes share the orbital
period and are far from independent, so the off-diagonal terms are strongly correlated.
`decomposeScaleMatrix` polar-decomposes `S = R·U`:

- `R` (orthogonal) → **frame misalignment**, reported as small angles in μrad
- `U` (symmetric)  → **scale factors** (diagonal) and **non-orthogonality** (off-diagonal)

A pure misalignment gives `R ≠ I, U ≈ I`; a density/Cd error gives `R ≈ I, U(1,1) ≠ 1`.
Always check `decomp.condS` before trusting off-diagonal terms.

## Bias models

`constant` | `polynomial` (QR-orthogonalized) | `spline` | `pspline`

Prefer **`pspline`**: give it a generous knot count and let a roughness penalty (λ chosen
by blocked CV or GCV) set the flexibility continuously, instead of guessing a knot count.
Knots default to **quantile** placement — uniform placement drops knots inside data gaps
where nothing constrains them (on a gappy test set this raised `cond(B'B)` from 6.7e2 to
6.2e3).

## Known limitations

- **The CRN filter in `crnFilter` is the right *family*, not the operational filter.** The
  exact ACC1B coefficients must come from the GRACE-FO L1 Data Product User Handbook. If
  you don't have them, use `'commonmode'`, which needs no knowledge of them.
- `estimateNoiseModel` fits an **AR** model. True flicker/1-f noise is not AR; a
  high-order AR approximates it but the effective sample size may still be optimistic.
  `blockBootstrap` is the assumption-light fallback.
- The `'empirical'` filter strategy **cannot distinguish a filter from a genuine
  force-model deficiency** — it will happily absorb real physics into the "filter".
  Diagnostic use only.
- AIC/BIC are deliberately *not* used for selection anywhere. If you need them, they are
  in `comparison.table` as `AIC_ref` / `BIC_ref`, next to the `IC_unreliable` flag.
- Rows of `S` are fitted independently, so `covS` is block-diagonal by construction. A
  joint solve would capture cross-row correlation; it isn't implemented.
- **Cause attribution needs a genuinely varied arc.** `scaleFactorDiagnostics` can only
  separate a density-model error from a Cd/geometry error when the space-weather indices
  actually move over the arc; on a quiet week the two stay confounded exactly as they do
  on a single day, and the function flags this rather than guessing.
- **Orbit geometry is not computed here.** `loadSpaceWeatherIndices` reads F10.7/Kp/Ap/SN
  from the GFZ file, but β-angle, argument-of-latitude and Dst come from your orbit/other
  sources and are passed in through its `'Extra'` option.

## Documentation

- `doc/index.html` — function reference (also registered with the MATLAB doc browser via
  `info.xml`; run `doc` after adding the toolbox to the path)
- `doc/AccelBiasScaleToolbox_Reference.pdf` — 7-page mathematical reference: derivations,
  validation figures, known limitations
- `refval/` — the Python implementations used to cross-validate every numeric, and
  `make_figs.py`, which regenerates every figure and number quoted in the PDF

## Tests

```matlab
runAllTests
```

34 test classes. The ones that matter are in `test_integration_endToEnd.m`: they run the
whole pipeline against `syntheticAccelPair`, which injects **every** defect at once
(filter mismatch, AR-colored noise, gaps, glitches, mismatched grids, full misalignment +
scale + non-orthogonality) and scores the recovered parameters against the injected truth.
Per-unit tests on clean data cannot catch interaction bugs; these can.
