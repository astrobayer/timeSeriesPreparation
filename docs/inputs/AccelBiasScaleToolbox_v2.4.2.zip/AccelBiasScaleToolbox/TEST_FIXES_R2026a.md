# Test fixes for R2026a (v2.4.1 / v2.4.2)

A full `runAllTests` on MATLAB R2026a surfaced 37 failures; the first fix pass
took it to 10, and the second pass (below) targets the remaining regressions.
None of the failures were in the v2.4 feature code (`scaleFactorDiagnostics`,
`loadSpaceWeatherIndices`); those suites pass.

## Second pass (v2.4.2): the 3 that the first pass did not clear

After the first pass, three failures remained that were NOT simple tolerance
issues. Root-caused and fixed:

### crnFilter legacy filter over-attenuated the passband
`test_filterConsistency/filterMismatchBiasesScaleAndCorrectionRemovesIt`,
`test_analyzeAccArc/runsEndToEndAndRecoversScales`,
`test_integration_endToEnd/recoversMisalignmentAnglesAndScales`.

The v2.4.1 `legacyLowpass` shim sized its base boxcar as
`0.443*fs/fc * sqrt(nc)` — it should DIVIDE by `sqrt(nc)`. The nc-fold
self-convolution narrows the response, so multiplying made the filter far too
long (its -3 dB point fell near 0.004 Hz instead of the requested 0.02 Hz),
attenuating in-band signal to ~72%. That in-band distortion re-appeared as a
scale bias the single-pass filter-consistency correction could not undo. Fixed
the formula to `0.443*fs/fc / sqrt(nc)`; verified H(0.02) ~ 0.72 (-3 dB at the
stated cutoff), H(0.002) > 0.99 (flat passband), H(0.2) ~ 0 (stopband), unit DC
gain and symmetry preserved. With the corrected filter, both the
filter-consistency correction and the end-to-end scale recovery are exact.

### filterConsistency test double-filtered the observation
`test_filterConsistency/filterMismatchBiasesScaleAndCorrectionRemovesIt` also
built its "ACC1B-like" observation with a forward-backward (double) pass
(`zeroPhaseLocal`, response H^2), while `filterConsistency('explicit')` brings
the model into band with a single centred pass (`centredFIR`, response H). H^2
vs H is itself a scale bias — the very effect the module removes — so the
correction could not land. The test now filters the observation once, centred
(`centredFIRLocal`), matching how ACC_1B is actually produced and what the
'explicit' strategy assumes.

### reportsSigmaInflation ran on noise-free data
`test_analyzeAccScaleArc/reportsSigmaInflation`. The test's `writePair`
generated a perfectly clean observation (`Aobs = bias + Amod.*scale`, no noise),
so the fit residual was ~0 and the "block-bootstrap sigma vs naive iid sigma"
inflation it asserts (> 1.5) had nothing to inflate. The v2.4.1 QR rewrite of
the naive sigma was a genuine stability fix (it removed the RCOND warnings from
`inv(X'X)` on a design conditioned ~1e16) but could not make a noise-free test
pass. `writePair` now takes optional AR(1) noise parameters (default 0, so all
other tests that rely on clean data are unchanged), and the inflation test
injects coloured noise (std 3e-9, rho 0.98); verified inflation ~ 10 >> 1.5.

## First pass (v2.4.1): 27 crnFilter + 4 others -- see git / below

### crnFilter legacy signature (27 failures)
`crnFilter` was redesigned to the ATBD signature `crnFilter('ACC'|'KBR', ...)`,
dropping the older `crnFilter(fs, 'Cutoff', fc, 'NumConv', N)` form still used by
`syntheticAccelPair` and `test_filterConsistency`. Added a backward-compatibility
shim routing numeric-first / `Cutoff` / `NumConv` calls to a local `legacyLowpass`
builder; the ATBD path is unchanged. (The builder's cutoff calibration was then
corrected in the second pass, above.)

### alignAccelSeries NaN handling
R2026a's `interp1` interpolates across NaNs in the source data, so a NaN epoch
was no longer dropped. Now propagates source-NaN explicitly via a resampled
finiteness mask.

### Two brittle test setups
`test_scaleObservability` (`sin(t)` over `[0,10]` is not zero-mean -> now
demeaned) and `test_slidingWindowFit` (large-offset regressor gated
unobservable -> now runs with `GateObservable=false`).

## Left for offline triage (penalized-regression tolerance)

These remain and were deliberately NOT changed, because they depend on
penalized-spline / GCV numerics and shouldn't be "fixed" by loosening tolerances
without verifying against the algorithms in a MATLAB session:

- `test_gcvSelectLambda/heavyPenaltyApproachesLinearFit`
- `test_glsLinearFit/penaltyShrinksTowardNullSpace`
- `test_robustLinearFit/penaltyShrinksTowardNullSpace`
  A very large 2nd-difference penalty is asserted to drive a B-spline fit exactly
  onto a linear function to 1e-2. An independent NumPy reproduction shows the
  residual is intrinsic to the B-spline + difference-penalty boundary geometry
  and saturates regardless of lambda, i.e. the linear trend is not exactly in
  this basis's penalty null space at the boundary knots. Confirm whether
  `bsplineBasis` boundary-knot handling changed, then relax to the interior or
  adjust the basis.

- `test_accelTimeVaryingScaleFit/recoversConstantScaleAsFlat`
- `test_accelTimeVaryingScaleFit/smootherScaleReducesBiasScaleAliasing`
  GCV selects slightly less regularization under the R2026a random stream, so the
  recovered scale shows more drift than the thresholds allow. Check the GCV lambda
  selection and rng-seeded stream.

- `test_crnFilterATBD/derivativeKernelDifferentiatesASinusoid`
  Derivative kernel differs from the analytic derivative by ~1.3% (AbsTol 0.002);
  ATBD derivative-kernel numerics, unrelated to the legacy shim.

## Expected outcome
After the second pass, `runAllTests` should drop to ~6 failures, all in the
penalized-regression / derivative-kernel tolerance group above.
