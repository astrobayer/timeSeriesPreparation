% SIGTOOLS  Signal & time-series analysis toolbox (base MATLAB, no toolboxes).
% Version 1.3.1  2026-07-16
%
%   A single collection of spectral-analysis and time-series-modelling
%   functions that run entirely in base MATLAB -- no toolboxes required.
%   Every function has a standardized help block with sized/typed input
%   and output tables.
%
%   Spectral analysis (sigtools/spectral)
%     plotPowerSpectrum  - Welch-FFT / Lomb-Scargle power & amplitude spectra.
%     allanVariance      - Overlapping Allan variance/deviation + CI + slope.
%     spec2acv           - PSD/ASD -> auto-covariance / -correlation (Wiener-Khinchin).
%     psd2arma           - Fit a discrete-time ARMA process to a target PSD/ASD.
%     arma2psd           - PSD/ASD of an ARMA process (inverse of psd2arma).
%     arma2acv           - Exact ARMA auto-covariance / -correlation (Lyapunov).
%     synthTimeSeries    - Warmup-free noise series from a PSD or ARMA model.
%     sfreqz             - Digital frequency response B(z)/A(z) (base freqz).
%     sinvfreqz          - Fit an IIR filter to a frequency response (SK).
%     sstmcb             - Steiglitz-McBride IIR fit to an impulse response.
%
%   Time-series modelling (sigtools/tsmodels)
%     tsAcf              - Sample autocorrelation (gap-aware).
%     tsPacf             - Sample partial autocorrelation (Durbin-Levinson, PD-repair).
%     tsDiff             - (1-B)^d differencing.
%     tsIntegrate        - Inverse of tsDiff.
%     tsFitArima         - Core ARIMA estimator (exact-ML / CSS / Yule-Walker,
%                          PACF-reparametrised, multi-start).
%     tsFitAR            - AR(p) wrapper.
%     tsFitMA            - MA(q) wrapper.
%     tsFitARMA          - ARMA(p,q) wrapper.
%     tsFitSarima        - Seasonal ARIMA(p,d,q)(P,D,Q)_s by CSS or exact ML (gaps).
%     tsAutoArima        - (p,q) grid search by AIC/BIC.
%     tsAutoSarima       - Seasonal (p,d,q)(P,D,Q)_s grid search by AIC/BIC.
%     tsForecast         - h-step forecasts + intervals (ARIMA/SARIMA, gaps, bootstrap).
%     tsLjungBox         - Ljung-Box portmanteau test.
%     tsCheckResiduals   - Four-panel residual diagnostics.
%     tsModelDisp        - Pretty-print a fitted model.
%
%   Demos (sigtools/demos)
%     demo_plotPowerSpectrum         - Five spectral-estimation scenarios.
%     allanVariance_demo             - Allan deviation of four noise types.
%     gap_filling_spectral_comparison- Gap-handling strategies vs. spectrum.
%     demo_tsmodels                  - End-to-end ARIMA walkthrough.
%     demo_sigtools_new              - New features: spectral<->TS loop,
%                                      SARIMA, residual diagnostics.
%
%   Tests (sigtools/tests)
%     plotPowerSpectrumTest, test_allanVariance, spec2acvTest,
%     psd2armaTest, arma2psdTest, arma2acvTest, spectralIntegrationTest,
%     tsmodelsTest, tsmodelsExtraTest            - class-based unit tests.
%     runSigtoolsTests                           - run the class-based suite.
%     runAllTests                                - legacy tsmodels suite.
%     Run all:  runSigtoolsTests
%
%   Setup
%     Run  sigtools_setup  once per session (or add the folders to your path)
%     to make all functions and demos available.
%
%   Every function is base MATLAB only -- no toolboxes required.
%
%   ------------------------------------------------------------------
%   Author : Assembled by Claude Opus 4.8 (Anthropic)
%   Date   : 2026-07-15  (build time-of-day not available in this environment)
%   ------------------------------------------------------------------
