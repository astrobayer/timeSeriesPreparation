# sigtools — Hand-off & Roadmap

**Version 1.3.1 · 2026-07-16 · assembled by Claude Opus 4.8 (Anthropic)**

> **v1.3.1 — verified on MATLAB R2026a (Update 3).** The full suite was executed
> for the first time on a real MATLAB (previously only static + NumPy checks).
> **All 209 tests pass** (180 class-based across 15 suites + 29 legacy). Nine
> pre-existing R2026a-incompatibilities and test-expectation bugs were found and
> fixed — see §3a. None were in the v1.3 numerical kernels; they were older
> files plus a few over-tight/self-contradictory test assertions.

This document is written so a fresh session (or a new maintainer) can pick the
project up cold. It covers what exists, how it fits together, what has and has
not been verified, the conventions to keep, and a prioritised roadmap.

---

## 1. One-paragraph summary

`sigtools` is a base-MATLAB (no-toolbox) library for spectral analysis and
time-series modelling. It began as nine loose files and was consolidated into a
single documented, tested toolbox, then extended: the Signal Processing Toolbox
dependency was removed, the ARIMA estimator was hardened, and several new
functions were added (`arma2psd`, `synthTimeSeries`, `tsFitSarima`,
`tsCheckResiduals`, and the standalone filter utilities `sfreqz`/`sinvfreqz`/
`sstmcb`). Everything runs in base MATLAB.

---

## 2. Current state (what is DONE)

### Functions (26 total)

**spectral/** (10)
| Function | Purpose | Notes |
|---|---|---|
| `plotPowerSpectrum` | Welch-FFT / Lomb-Scargle power & amplitude spectra | original file, unmodified except doc banner |
| `allanVariance` | Overlapping Allan variance/deviation + CI + slope | original, unmodified except banner |
| `spec2acv` | PSD/ASD → auto-covariance (Wiener-Khinchin) | original, unmodified except banner |
| `psd2arma` | Fit a discrete-time ARMA process to a target PSD/ASD | SPT dependency removed; calls `sfreqz`/`sinvfreqz`/`sstmcb` |
| `arma2psd` | PSD/ASD of an ARMA process (inverse of `psd2arma`) | v1.1 |
| `arma2acv` | **Exact ARMA auto-covariance / -correlation (Lyapunov)** | **new v1.3**; agrees with `arma2psd`→`spec2acv` to ~1e-15 |
| `synthTimeSeries` | Warmup-free noise series from a PSD or ARMA model | v1.1 |
| `sfreqz` | Digital frequency response B(z)/A(z) (base `freqz`) | v1.1, promoted from a local |
| `sinvfreqz` | Fit IIR to a frequency response, Sanathanan-Koerner | v1.1, promoted from a local |
| `sstmcb` | Steiglitz-McBride IIR fit to an impulse response | v1.1, promoted from a local |

**tsmodels/** (15)
| Function | Purpose | Notes |
|---|---|---|
| `tsAcf` / `tsPacf` | Sample (P)ACF, gap-aware | `tsPacf` gained a `makePSD` nearest-PD-projection option |
| `tsDiff` / `tsIntegrate` | (1-B)^d differencing and exact inverse | original |
| `tsFitArima` | Core ARIMA estimator (exact-ML / CSS / Yule-Walker) | reparametrised (see §4) |
| `tsFitAR` / `tsFitMA` / `tsFitARMA` | Convenience wrappers | original |
| `tsFitSarima` | Seasonal ARIMA(p,d,q)(P,D,Q)_s | **v1.3: exact-ML method + NaN-gap support** (was CSS-only) |
| `tsAutoArima` | (p,q) grid search by AIC/BIC | original (unchanged; `Rx6` table contract preserved) |
| `tsAutoSarima` | **Seasonal (p,d,q)(P,D,Q)_s grid search by AIC/BIC** | **new v1.3** |
| `tsForecast` | h-step forecasts + intervals | **v1.2: SARIMA path; v1.3: gap-SARIMA KF + bootstrap intervals** |
| `tsLjungBox` | Ljung-Box portmanteau test | original |
| `tsCheckResiduals` | Four-panel residual diagnostics + Jarque-Bera | v1.1 |
| `tsModelDisp` | Pretty-print a fitted model | original |

**root** (1): `sigtoolsDemo` — **new v1.3** demo launcher / index.

### Support files
- `Contents.m` — `help sigtools` table of contents (version 1.3).
- `sigtools_setup.m` — adds folders to the path; `sigtools_setup(true)` adds tests too.
- `README.md` — user-facing overview and changelog.
- `HANDOFF.md` — this file.
- `doc/html/` — styled HTML pages (one per function + `index.html`). The v1.3
  pages (`arma2acv`, `tsAutoSarima`, `sigtoolsDemo`) and the updated
  `tsForecast`/`tsFitSarima` pages were generated this session; see §6.
- `demos/` — 6 runnable scripts, incl. `demo_sigtools_v13.m` for the newest features.

### Tests (15 suites + 2 runners, all class-based `matlab.unittest` except `runAllTests`)
`runSigtoolsTests` runs the whole class-based suite. Coverage:
- Per-function unit suites for every function.
- `arma2acvTest` — closed forms (AR(1), MA(q)), Lyapunov-vs-psi agreement, acf
  normalisation, noise linearity, non-stationary error, and the round-trip vs
  `spec2acv(arma2psd(...))`.
- `tsForecastSarimaTest` — seasonal forecasting, gap-SARIMA KF forecast, and
  bootstrap intervals (shape, ordering, Gaussian-limit width, reproducibility).
- `tsAutoSarimaTest` — seasonal grid search (table shape/sort, order selection,
  criterion switch, option forwarding, empty-grid error).
- `tsFitSarimaTest` — now also exact-ML recovery, gap handling, and the
  css-rejects-gaps / exact-gaps-reject-differencing guards.
- `tsmodelsExtraTest` — reparametrisation, multi-seed recovery, within-SE
  coverage, SARIMA, residual diagnostics, **non-seasonal bootstrap forecasts**.
- `spectralIntegrationTest` — cross-function round-trips, now incl. `arma2acv`.
- `synthTimeSeriesTest` — variance match, PSD match, warmup-free checks, odd-N.
- `runAllTests` — the legacy function-based tsmodels suite, kept as-is.

---

## 3. Verification status

**As of v1.3.1 the toolbox has been run on MATLAB R2026a (Update 3): all 209
tests pass.** Earlier versions (v1.0–v1.3) were built without a runtime and
verified only by static analysis + NumPy re-derivation; that history is kept
below because the independent numerical re-derivations remain the strongest
evidence for the *correctness* (as opposed to mere runnability) of the kernels.

Static/independent checks done during the build (still valid):
- **Static structural checks**: a custom tokeniser verified `function`/`end`
  block balance on every file (handling `end`-as-index and single-line
  `if…end`). All authored/edited files balance; three original files
  (`plotPowerSpectrum`, `tsModelDisp`, `runAllTests`) show harmless
  `end`-as-index false positives.
- **Independent numerical re-derivation in NumPy/SciPy** of every new numerical
  kernel, porting the *exact* MATLAB logic (indexing, real/imag stacking, etc.):
  - `sinvfreqz` (Sanathanan-Koerner): recovers a known ARMA to ~1e-15; 0.0075 dB
    RMS on a smooth 4th-order low-pass target; stable + minimum-phase.
  - `sstmcb` (Steiglitz-McBride): recovers the generating filter exactly.
  - `arma2psd`: Parseval identity `trapz(f,S) == s2·Σψ²` to ratio 1.0.
  - PACF↔AR reparametrisation: round-trip exact; stationary by construction.
  - Doubling discrete-Lyapunov solve: matches the Kronecker solve to ~1e-15.
  - Exact-ML AR(1) log-likelihood: matches the closed-form Gaussian density to ~1e-12.
  - Richardson Hessian SE for AR(1): matches `sqrt((1-φ²)/n)` to ratio 1.000.
  - `synthTimeSeries` PSD path: **unbiased** (mean bias ~1e-5, error falls as
    1/√M); ARMA path variance matches theory; first-block vs last-block
    mean-square ratio ≈ 1.00 (the no-warmup property); Hermitian assembly
    correct for even and odd N.
  - **Seasonal forecasting** (v1.2): exact port of `local_forecastSarima` vs a
    150k–200k-run Monte-Carlo forecast distribution for SARIMA(1,0,0)(1,1,0)_4
    and (1,1,1)(1,1,0)_4 — point to MC noise, SE within ~0.3%, one-step SE exact.
  - **`arma2acv`** (v1.3): Lyapunov and psi-weight methods agree to ~1e-15 across
    AR(1)/MA(2)/ARMA(2,1)/ARMA(1,3, q>p); AR(1) & MA(q) closed forms exact; and
    `arma2acv == spec2acv(arma2psd(...))` at integer lags to ~1e-15 on a fine grid.
  - **Exact-ML SARIMA** (v1.3): the expanded-ARMA Kalman filter reproduces the
    direct multivariate-normal concentrated log-likelihood to ~1e-14, both full
    and with missing samples (gap KF vs MVN density on the observed subset:
    exact to 0). Parameter recovery confirmed by the class-based tests.
  - **Bootstrap intervals** (v1.3): the residual-resampling propagation
    `err_k = Σ Ψ_{j+1} e*_{k-j}` reproduces the Gaussian analytic half-width to
    ~1–3% for Gaussian residuals and gives ~nominal out-of-sample coverage for
    both Gaussian and skewed (exponential) innovations.

**To re-run (verified working on R2026a):**
```matlab
sigtools_setup(true)
results = runSigtoolsTests;   % 180 class-based tests, all pass on R2026a
runAllTests                   % legacy suite, 29/29 pass
```
Note `runSigtoolsTests` runs every suite in one call and can take several
minutes (multi-start exact-ML SARIMA + bootstrap Monte-Carlo). If a driver
harness has a per-call timeout, run suites individually with
`runtests('<suiteName>')`.

## 3a. R2026a compatibility fixes applied in v1.3.1

The first real MATLAB run (R2026a) surfaced nine issues; all fixed. None were in
the v1.3 numerical kernels. Grouped by kind:

**Genuine R2026a incompatibilities in older files (would break any user):**
1. `spec2acv.m` — `warning("id", ["msg1" "msg2"], arg)` passed a *string array*
   as the message; R2026a requires a scalar char/string. Changed to a
   bracketed char-array (`['..' '..']`). This crashed whenever a non-decayed
   spectrum triggered the ringing warning.
2. `psd2arma.m` — `interp1` now rejects non-unique sample points. A `logspace`
   frequency endpoint sitting a rounding step below `Fs/2` caused a duplicate
   `Fs/2` bin. Fixed with a tolerant Nyquist-append + snap-to-`Fs/2`.
3. `plotPowerSpectrum.m` — `spec(s) = analyseSeries(...)` failed with
   `heterogeneousStrucAssignment` because the preallocated `spec` struct lacked
   the `rayleigh` field the element carries. Added `'rayleigh',{}` to the
   preallocation (it is still stripped from the public output by `rmfieldSafe`).
4. `tsDiff.m` — `validateattributes(...,'finite')` rejected NaN gaps, breaking
   *all* gapped ARIMA fitting (`tsFitArima`/`tsCheckResiduals` gap paths).
   Relaxed to allow NaN when `d==0`; still errors on NaN when `d>0`
   (differencing across gaps is undefined).
5. `tsFitArima.m` — `local_startSet` did `mean(w(obs))` where `obs` is length-N
   but `w` is length N−d, so any `d>0` fit (e.g. ARIMA(1,1,1)) indexed out of
   bounds. Fixed by aligning the mask to `w` (`obs(end-numel(w)+1:end)`).

**Test-expectation bugs (algorithm was right, assertion was wrong):**
6. `spec2acvTest/smoothingPreservesPower` — a trailing positional diagnostic
   string after a `Name=Value` arg is a parse error in R2026a; reordered so the
   diagnostic precedes `RelTol=`.
7. `test_allanVariance` — (a) constant-signal `adev` compared to `AbsTol 1e-18`,
   impossible after `sqrt` of the ~1e-23 variance floor → loosened to 1e-9;
   (b) the ramp test's expected ADEV omitted the per-second drift scaling and
   the `1/√2` ramp factor (off by `fs/√2`); corrected to the standard
   `σ_y(τ)=R·τ/√2`, which the code matches to 1e-6.
8. `spec2acvTest/varianceIdentity` (`RelTol 1e-9`) and `logGridResampling`
   (grid extended to span the Lorentzian's near-DC support) — the direct
   method's R(0) is NUFFT-accurate (~1e-12), and the original log grid simply
   didn't cover `[0,0.01]` Hz where ~0.8% of the variance lives.
9. `arma2psdAcvMatchesTheoryAR1` — asserted the *untapered* AR(1) closed form
   while applying `Window="tukey"`, which provably biases R(0)/lag-1; dropped
   the taper. Plus two of my own new-test premises that became stale once the
   estimators got stricter (`tsFitSarima`/`tsAutoSarima` short-series guards now
   fire at the correct, smaller lengths — test inputs adjusted to `n=14`/`n=8`).

All fixes are byte-verified identical between the MATLAB machine and the shipped
zip (MD5-checked).

---

## 4. Key changes to be aware of (the non-obvious history)

0. **v1.2 / v1.3 additions (this session).**
   - `tsForecast` gained a **SARIMA path** (v1.2) and, in v1.3, a **gap-SARIMA
     Kalman forecast** (`local_forecastSarimaKF`) plus **residual-bootstrap
     intervals** (`local_bootInterval`/`local_empQuantile`). The signature is
     now `tsForecast(model, h, alpha, Name,Value...)` — `alpha` stays
     positional for backward compatibility; bootstrap options are name-value.
     `local_forecastSarima` now returns `[yhat, se, Psi, s2]` (Psi = original-
     scale weights, needed by the bootstrap).
   - `tsFitSarima` gained `'Method','exact'` (Kalman filter on the expanded
     ARMA, `local_exactSarima` + `local_dlyapSar`) and **NaN-gap** support; the
     model gains an `.obs` field in the exact-gap case. Its `x` validation was
     relaxed from `finite` to allow NaN gaps (finiteness is re-checked on the
     observed samples only).
   - `arma2acv` (new) and `tsAutoSarima` (new) added; `sigtoolsDemo` launcher and
     `demo_sigtools_v13` added.
   - **Shared kernel note**: the doubling discrete-Lyapunov solve now appears in
     `tsFitArima` (`local_dlyap`), `tsForecast` (`local_dlyap`), `arma2acv`
     (`local_dlyap`) and `tsFitSarima` (`local_dlyapSar`) — same algorithm,
     duplicated locally to keep each file self-contained (toolbox has no shared
     private/ dir). If you change one, change all four.

1. **`tsForecast.m` had a real, shipped bug**: the `local_psiWeights` function
   declaration line was missing, orphaning its body onto the end of
   `local_dlyap`. Any non-gapped forecast would have errored. Fixed. This is the
   kind of thing to re-check if forecasts behave oddly.

2. **`tsFitArima` was reparametrised.** AR/MA are optimised in an unconstrained
   space via `tanh → PACF → Durbin-Levinson`, so every trial polynomial is
   stationary/invertible **by construction**. Consequences:
   - The old soft-barrier `local_penalty` no longer shapes the optimiser; it
     survives only as a guard.
   - Standard errors are computed on a **penalty-free** objective (`objRaw`) via
     a Richardson-extrapolated Hessian, so the barrier can't corrupt them. If
     you touch the SE code, preserve this separation.
   - Multi-start optimisation was added.
   - The exact concentrated log-likelihood is unchanged (still matches the
     closed form).

3. **SPT removal is isolated to `psd2arma`.** The three replacements live in
   `sfreqz`/`sinvfreqz`/`sstmcb`. `besseli`, `erfinv`, `gammainc`, `gammaln`,
   `nufft` are all base MATLAB (nufft is guarded with a matrix fallback in
   `spec2acv`) — do NOT "fix" those; they are fine.

4. **Naming choice**: the filter utilities are `s`-prefixed, NOT `freqz`/
   `invfreqz`/`stmcb`, to avoid shadowing the toolbox versions when a user has
   the SPT installed. Keep this convention for any future SPT replacements.

---

## 5. Conventions to preserve

- **Base MATLAB only.** No toolbox calls. Before adding a function, check each
  builtin: `corr`/`quantile`/`chi2inv`/`invfreqz`/`freqz`/`stmcb`/`arburg`/
  `plomb`/`periodogram`/`filtfilt` are toolbox; `corrcoef`/`filter`/`fft`/
  `chol`/`eig`/`besseli`/`erfinv`/`gammainc` are base. (A Stats-Toolbox `corr`
  slipped into one test and was replaced with `corrcoef` — watch for this.)
- **PSD scaling**: one-sided `S(f) = (2σ²/Fs)|H(f)|²`, with `trapz(f,S)` = variance.
  `arma2psd`, `synthTimeSeries`, and `plotPowerSpectrum` all follow it. Any new
  spectral function must match so round-trips hold.
- **Help-block standard** (every function): H1 line; `INPUTS` and `OUTPUTS`
  tables with name · size · type · description (optionals flagged); `See also`;
  a `Toolbox / Author / Date` stamp; then the original detailed help.
- **Doc pipeline**: function metadata lives in a Python generator used at build
  time (`docmeta.py` / `gen_html.py` / `inject_banner.py`, kept in the build
  workspace, NOT shipped in the toolbox). To regenerate HTML after adding a
  function, add its entry to `docmeta.py` and rerun `gen_html.py`. If you don't
  have those scripts in the new session, just hand-write the HTML page to match
  the existing style, or ask to have them regenerated.
- **Tests**: prefer multi-seed / within-SE statistical assertions over
  single-seed point checks. Every new function gets its own class-based suite
  and an entry in `runSigtoolsTests.m`.
- **Version/date stamp**: `Claude Opus 4.8 (Anthropic)`, `2026-07-15`. Bump the
  version in `Contents.m` and `README.md` when you cut a release.

---

## 6. Known limitations / rough edges

- **HTML docs**: pages for the v1.3 functions (`arma2acv`, `tsAutoSarima`,
  `sigtoolsDemo`) were generated in this session by a small standalone script
  (not the original `docmeta.py`/`gen_html.py` pipeline) that reuses the shared
  `<head>` style and extracts each help block; `tsForecast.html` /
  `tsFitSarima.html` were regenerated the same way and `index.html` links the new
  pages. If you later re-run the original generator, add these functions to
  `docmeta.py` so the metadata is authoritative. Help blocks in the `.m` files
  are the source of truth and are up to date.
- `tsFitSarima` exact-ML **standard errors are not computed** (the struct has no
  `.stdErr`); CSS never had them either. Reuse `tsFitArima`'s Richardson-Hessian
  `local_stdErr` on the exact objective if SEs are wanted.
- `tsFitSarima` exact-ML with gaps requires `d=D=0` (differencing across missing
  samples is undefined) — same restriction as `tsFitArima`.
- Bootstrap prediction intervals are **not** available for gap-fitted models
  (the KF forecast path has no stored residual sequence to resample); `tsForecast`
  errors clearly in that case.
- `tsAutoSarima` searches d and D inside the grid, but AIC/BIC across different
  differencing orders are not strictly comparable — see its help. Fix d,D for a
  clean comparison.
- `plotPowerSpectrum`, `allanVariance`, `spec2acv` are the original authors'
  code — well-tested by their own suites, but only lightly re-touched here.
- Optimisation is derivative-free `fminsearch` with multi-start; very high
  orders (p+q ≳ 8) may still need more starts or better initialisation.
- `synthTimeSeries` PSD mode produces a Gaussian series; it does not reproduce
  non-Gaussian higher moments (by design).

---

## 7. Roadmap (prioritised)

### High value, self-contained
1. ~~**Seasonal forecasting**~~ — **DONE (v1.2).** `tsForecast` accepts a
   `tsFitSarima` model: forecasts on the fully-expanded ARMA, undoes the
   combined `(1-B)^d (1-B^s)^D` differencing via the observed tail, variance
   through `Ψ = ψ_expanded/Δ`. Gap-fitted seasonal models forecast from the
   Kalman state. Tests: `tsForecastSarimaTest`.
2. ~~**`arma2acv`**~~ — **DONE (v1.3).** Exact state-space Lyapunov
   autocovariance (with a psi-weight cross-check method). Agrees with
   `arma2psd → spec2acv` to ~1e-15. Tests: `arma2acvTest`, plus two new
   `spectralIntegrationTest` cases. Shares the doubling-Lyapunov kernel with
   `tsForecast`/`tsFitArima`.
3. ~~**Exact-ML for `tsFitSarima`**~~ — **DONE (v1.3).** `'Method','exact'`
   runs the Kalman filter on the expanded companion state; matches the direct
   MVN density to ~1e-14 and unlocks **NaN-gap** seasonal fitting (`d=D=0`).
   Tests in `tsFitSarimaTest`.

### Robustness / quality
4. **Analytic gradient for the exact likelihood** — replace `fminsearch` with a
   gradient-based optimiser (still base MATLAB) for speed and reliability at
   higher orders; the reparametrisation already gives an unconstrained space.
   *(still open)*
5. ~~**Seasonal order search**~~ — **DONE (v1.3)** as the new `tsAutoSarima`
   (dedicated function, not an overload of `tsAutoArima`, to preserve the
   latter's `Rx6` table contract). Tests: `tsAutoSarimaTest`.
6. ~~**Bootstrap prediction intervals**~~ — **DONE (v1.3).** `tsForecast`
   `'Bootstrap',true` resamples centred residuals through the original-scale
   MA(∞) weights; `'NBoot'`/`'Seed'` options. Covered in `tsForecastSarimaTest`
   and `tsmodelsExtraTest`.

### Packaging / usability
7. **Ship as a `.mltbx`** — MATLAB Add-On with `ver`-readable version, so users
   get one-click install/uninstall. *(still open — needs the MATLAB packaging
   UI / `matlab.addons.toolbox.packageToolbox`, hard to author blind.)*
8. **Integrate docs into the MATLAB Help browser** — `info.xml` + `helptoc.xml`
   so the HTML pages are searchable in-product. *(still open)*
9. ~~**`sigtoolsDemo` launcher**~~ — **DONE (v1.3).** Lists/runs the demo
   scripts (now six, incl. `demo_sigtools_v13`).

### Nice to have (still open)
10. **Multitaper (Slepian) spectral estimate** in `plotPowerSpectrum` — base
    MATLAB DPSS via the tridiagonal eigenproblem.
11. **Welch/segment support in `synthTimeSeries`** for very long series without
    a single huge FFT.
12. **Cross-spectral / coherence** functions to round out the spectral half.

### Suggested next actions
The self-contained, high-value items left are #12 (cross-spectral/coherence)
and #10 (multitaper) on the spectral side, and #4 (analytic gradient) on the
estimator side. #7/#8 are packaging steps best finished in a real MATLAB
session (they need the Add-On tooling / Help-browser build, which cannot be
verified blind here).

---

## 8. How to resume in a new chat (suggested opening message)

> "I'm continuing work on the `sigtools` MATLAB toolbox (base MATLAB, no
> toolboxes). It's attached as `sigtools.zip`. Read `HANDOFF.md` first. I want
> to [e.g. run the tests and fix any failures / regenerate the v1.3 HTML docs /
> implement roadmap item #12, cross-spectral & coherence]. Keep the conventions
> in §5 — base MATLAB only, the PSD scaling convention, the standard help-block
> format, and per-function class-based tests."

Attach `sigtools.zip`. Everything needed is inside it; the Python doc-generator
scripts are the only build-time pieces not shipped, and they can be regenerated
on request. NOTE: the v1.3 additions (`arma2acv`, `tsAutoSarima`, `sigtoolsDemo`)
still need HTML pages generated — see §6.

---

## 9. File map (quick reference)

```
sigtools/
├── Contents.m            help sigtools  (v1.3)
├── sigtools_setup.m      path setup  (call with true to add tests)
├── sigtoolsDemo.m        demo launcher / index         (new v1.3)
├── README.md             user overview + changelog
├── HANDOFF.md            this document
├── spectral/             10 functions  (+ arma2acv)
├── tsmodels/             15 functions  (+ tsAutoSarima)
├── demos/                6 scripts     (+ demo_sigtools_v13)
├── tests/                18 test files (runSigtoolsTests = class-based runner)
└── doc/html/             HTML pages (v1.3 fns generated; see §6)
```
