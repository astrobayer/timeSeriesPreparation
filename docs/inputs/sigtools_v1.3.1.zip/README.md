# sigtools — Signal & Time-Series Analysis for Base MATLAB

**Version 1.3.1 · 2026-07-16**

> Verified on **MATLAB R2026a** — all 209 tests pass (`runSigtoolsTests` + `runAllTests`).

A single toolbox that collects a set of previously separate spectral-analysis
and time-series-modelling functions into one coherent, documented, and tested
package. **Everything runs in base MATLAB — no toolboxes required.**

Assembled and extended by **Claude Opus 4.8 (Anthropic)**.

> Continuing this project or handing it off? See **`HANDOFF.md`** for the full
> state, verification status, conventions, and roadmap.

---

## Layout

```
sigtools/
├── Contents.m              Toolbox table of contents (help sigtools)
├── sigtools_setup.m        Add all folders to the MATLAB path
├── README.md               This file
├── spectral/               Spectral-domain functions
│   ├── plotPowerSpectrum.m Welch-FFT / Lomb-Scargle spectra
│   ├── allanVariance.m     Overlapping Allan variance/deviation
│   ├── spec2acv.m          PSD/ASD -> auto-covariance (Wiener-Khinchin)
│   ├── psd2arma.m          Fit an ARMA process to a target PSD  (base MATLAB)
│   ├── arma2psd.m          PSD of an ARMA process (inverse of psd2arma)
│   ├── arma2acv.m          Exact ARMA auto-covariance / -correlation (Lyapunov)
│   ├── synthTimeSeries.m   Warmup-free noise series from a PSD or ARMA model
│   ├── sfreqz.m            Digital frequency response B(z)/A(z)  (base freqz)
│   ├── sinvfreqz.m         Fit an IIR filter to a response       (base invfreqz)
│   └── sstmcb.m            Steiglitz-McBride impulse-response fit (base stmcb)
├── tsmodels/               ARIMA / SARIMA time-series functions
│   ├── tsAcf.m   tsPacf.m
│   ├── tsDiff.m  tsIntegrate.m
│   ├── tsFitArima.m  tsFitAR.m  tsFitMA.m  tsFitARMA.m
│   ├── tsFitSarima.m       Seasonal ARIMA(p,d,q)(P,D,Q)_s  (CSS / exact ML, gaps)
│   ├── tsAutoArima.m  tsAutoSarima.m  tsForecast.m
│   ├── tsLjungBox.m  tsModelDisp.m
│   └── tsCheckResiduals.m  Four-panel residual diagnostics
├── demos/                  Runnable example scripts
├── tests/                  Class-based matlab.unittest suites (+ runAllTests)
└── doc/html/               One styled HTML reference page per function
    └── index.html          Start here
```

## Quick start

```matlab
sigtools_setup            % put functions + demos on the path (this session)
% sigtools_setup(true)    % ... and the tests folder too

help sigtools             % table of contents
open doc/html/index.html  % browse the HTML reference
```

### Spectral analysis

```matlab
fs = 100; t = (0:1/fs:60)';
x  = 1.0*sin(2*pi*7*t) + 0.5*randn(size(t));
[pk, S] = plotPowerSpectrum({fs, x, 'sensor'}, ...
    'Type','amplitude', 'NAvg',8, 'NPeaks',1, 'Unit','nT');

[tau, avar, adev, info] = allanVariance(x, fs, [], true);   % Allan deviation plot
[R, lags] = spec2acv(S.frequency, S.power, Window="tukey"); % PSD -> autocovariance

% Fit an ARMA process to a target PSD, then evaluate the fitted PSD back:
Fs = 500; f = logspace(-2, log10(Fs/2), 400)';
Starget = 1 ./ (1 + (f/5).^2).^2;
[b, a, res] = psd2arma(f, Starget, Fs, 'Order', [4 4]);   % base MATLAB, no SPT
[Sfit, ff]  = arma2psd(b, a, Fs, 'NoiseVariance', res.NoiseVariance);

% Synthesise a stationary noise series with a target PSD (no warmup transient):
x = synthTimeSeries('psd', f, Starget, Fs, 2^16);          % or 'arma', b, a, ...
```

### Time-series modelling

```matlab
x = your_series(:);
tsPacf(x, 30);                          % identify AR order (tsAcf for MA order)
m = tsFitARMA(x, 2, 1);                 % exact-ML ARMA(2,1)
tsModelDisp(m)                          % coefficients + standard errors
tsCheckResiduals(m);                    % residual ACF, Q-Q, Ljung-Box ladder

best = tsAutoArima(x, 3, 3, 0, 'Criterion','bic');
[yh, se, lo, hi] = tsForecast(best, 20);

% Seasonal model:
ms = tsFitSarima(x, [1 0 1], [1 1 0], 12);   % SARIMA(1,0,1)(1,1,0)_12
```

## What changed in 1.3

This release adds a direct ARMA autocovariance kernel, exact-ML seasonal
fitting (with NaN-gap support), seasonal + bootstrap forecasting, and a
seasonal order search — all base MATLAB.

### `arma2acv` — exact ARMA autocovariance
`arma2acv(b, a, maxLag)` returns the theoretical auto-covariance (or
auto-correlation) of an ARMA process by an exact state-space Lyapunov solve
(no truncation), with an optional MA(∞) psi-weight method for cross-checking.
It unifies the covariance kernel across the toolbox: `arma2acv` agrees with
the spectral route `arma2psd → spec2acv` to machine precision, closing the
spectral ↔ time-series loop from the covariance side.

```matlab
[R, k] = arma2acv([1 -0.5], [1 -1.2 0.6], 30, 'NoiseVariance', 2);
```

### Exact-ML seasonal ARIMA (`tsFitSarima`, `'Method','exact'`)
`tsFitSarima` gained an exact Gaussian maximum-likelihood method that runs a
Kalman filter on the fully-expanded ARMA companion state space. It matches the
direct multivariate-normal density to machine precision and, unlike CSS,
accepts **NaN gaps** (missing samples at regular timestamps, `d=D=0`): the
filter skips the update at each gap and accrues no likelihood term there.

```matlab
m = tsFitSarima(x, [1 0 1], [1 0 0], 12, 'Method', 'exact');   % or with NaNs in x
```

### Seasonal & bootstrap forecasting (`tsForecast`)
* Seasonal models (`tsFitSarima`) forecast on the fully-expanded ARMA with the
  combined `(1-B)^d (1-B^s)^D` differencing undone; gap-fitted seasonal models
  forecast from the Kalman state. One-step SE equals `sqrt(sigma2)` exactly.
* New `'Bootstrap',true` option builds prediction intervals by resampling the
  (centred) model residuals and propagating them through the original-scale
  MA(∞) weights — capturing skew and heavy tails. `'NBoot'` and `'Seed'`
  control the resampling.

```matlab
[yh, se, lo, hi] = tsForecast(m, 24);                              % Gaussian PI
[yh, se, lo, hi] = tsForecast(m, 24, 0.05, 'Bootstrap', true);     % empirical PI
```

### `tsAutoSarima` — seasonal order search
Grid search over `(p,d,q)(P,D,Q)_s` by AIC/BIC, forwarding any option to
`tsFitSarima` (including `'Method','exact'`).

### Launcher
`sigtoolsDemo` lists and runs the example scripts, including the new
`demo_sigtools_v13`.

## What changed in 1.2

### Seasonal forecasting

`tsForecast` now accepts a **seasonal** model from `tsFitSarima`. A SARIMA
model is detected automatically and forecast on the fully-expanded, stationary
ARMA applied to the doubly-differenced working series, with the combined
`(1-B)^d (1-B^s)^D` differencing undone via the observed tail. The
forecast-error variance uses the original-scale psi-weights
`Ψ(B) = ψ_expanded(B)/Δ(B)`, so `var = σ²·cumsum(Ψ²)` and the one-step SE
equals `sqrt(sigma2)` exactly. New test suite: `tsForecastSarimaTest`.

## What changed in 1.1

This release removes the last toolbox dependency and hardens the estimators.

### Toolbox dependency removed
`psd2arma` no longer needs the Signal Processing Toolbox. Its three SPT calls
were replaced with base-MATLAB equivalents:

* **`freqz`** → `local_freqz`, direct polynomial evaluation of `B(z)/A(z)` on
  the unit circle.
* **`invfreqz`** → `local_invfreqz`, a **Sanathanan–Koerner** iterative
  frequency-domain rational fit (recovers a known ARMA response to machine
  precision; ~0.008 dB RMS on a smooth 4th-order low-pass target).
* **`stmcb`** → `local_stmcb`, a base-MATLAB **Steiglitz–McBride** time-domain
  fit using `filter`.

These three replacements are now exposed as **standalone, path-level
functions** — `sfreqz`, `sinvfreqz`, `sstmcb` — since they are of general use
beyond `psd2arma` (evaluating any `B(z)/A(z)`, fitting an IIR filter to a
measured response, or fitting one to an impulse response). They are named with
an `s` prefix rather than shadowing the toolbox `freqz`/`invfreqz`/`stmcb`, so
the toolbox stays conflict-free whether or not the Signal Processing Toolbox is
installed. `psd2arma` and `arma2psd` now call these shared functions.

### `tsFitArima` reparametrised (correctness + honest SEs)
* AR and MA blocks are now optimised in an **unconstrained space** via
  `tanh → PACF → Durbin–Levinson`, so every trial polynomial is **stationary
  and invertible by construction**. The old soft-barrier penalty (which
  distorted the likelihood surface and biased SEs near the boundary) is gone.
* **Multi-start** optimisation (Yule–Walker seed + zero seed + perturbations)
  reduces local-optimum stalls on higher orders.
* Standard errors use a **Richardson-extrapolated** observed-information
  Hessian with a symmetric-eigenvalue fallback, replacing the single
  fixed-step difference.
* The discrete-Lyapunov solve (initial KF state covariance) now uses a stable
  **doubling iteration** with a Kronecker fallback, instead of forming the
  full `r²×r²` system every call. Applied in both `tsFitArima` and
  `tsForecast`.

The exact concentrated log-likelihood is unchanged: it still matches the
closed-form AR(1) Gaussian likelihood to ~1e-12.

### New functions
* **`arma2psd`** — one-sided PSD/ASD of an ARMA process, the exact inverse of
  `psd2arma`'s scaling (`trapz(f,S)` recovers the process variance). Closes
  the spectral ↔ time-series loop and enables round-trip tests.
* **`tsFitSarima`** — multiplicative seasonal ARIMA `(p,d,q)(P,D,Q)_s` by CSS,
  with the same PACF reparametrisation and multi-start.
* **`tsCheckResiduals`** — standardized residuals, residual ACF with band,
  normal Q-Q, Ljung-Box p-value ladder, and a Jarque–Bera statistic; returns
  all numbers for scripting.

### `tsPacf` robustness
* New optional `makePSD` flag projects a non-positive-definite pairwise ACF
  (common under heavy gapping) onto the nearest valid PSD autocorrelation by
  alternating projection, guaranteeing `|PACF| ≤ 1`.

### Earlier fix (still in place)
* **`tsForecast.m`** — restored the missing `local_psiWeights` function
  header; without it, any non-gapped forecast would have errored.

## Documentation standard

Every function's help block follows the same structure (`help <fn>` or
`doc/html/<fn>.html`): a one-line H1 summary; **INPUTS** and **OUTPUTS** tables
with name · size · type · description; **See also** cross-references; a
toolbox/author/date stamp; then the original detailed help. Size symbols:
`N` samples, `P` channels, `K`/`L` lags/taus, `M` frequency bins,
`h` forecast horizon, `S` series count.

## Testing

```matlab
sigtools_setup(true)
results = runSigtoolsTests;         % all class-based suites (base MATLAB)

% or individually:
runtests('tsmodelsTest')            % core ARIMA + missing-data paths
runtests('tsmodelsExtraTest')       % reparametrisation, multi-seed, SARIMA, SEs
runtests('plotPowerSpectrumTest')
runtests('spec2acvTest')
runtests('test_allanVariance')
runtests('psd2armaTest')            % now runs in base MATLAB
runtests('arma2psdTest')
runtests('spectralIntegrationTest') % arma2psd <-> psd2arma <-> spec2acv round-trips
runtests('tsFitSarimaTest')
runtests('tsForecastSarimaTest')    % seasonal + bootstrap forecasting (v1.2/1.3)
runtests('tsAutoSarimaTest')        % seasonal order search (v1.3)
runtests('arma2acvTest')            % exact ARMA autocovariance (v1.3)
runtests('tsCheckResidualsTest')
runAllTests                         % legacy function-based tsmodels suite
```

Statistical tests use multi-seed / within-SE assertions rather than a single
lucky seed, so they validate the estimator *and* its reported uncertainty.

## Notes & limits

* Exact ARIMA ML is `O(n·r²)` per likelihood evaluation (`r = max(p, q+1)`);
  fine for thousands of points. Optimisation is derivative-free `fminsearch`
  with multi-start.
* `tsFitSarima` uses conditional sum of squares (the standard, robust choice
  for seasonal models); it conditions on the first `max` order observations
  and does not currently accept NaN gaps.
* `plotPowerSpectrum` uses Lomb-Scargle automatically for gapped/uneven series
  and for any custom `'Frequencies'` grid.
* These files were validated in the build environment by static analysis and
  by independent NumPy/SciPy re-derivation of every new numerical kernel
  (SK `invfreqz`, SM `stmcb`, `arma2psd` Parseval identity, the PACF↔AR
  reparametrisation, the doubling Lyapunov solve, and the exact-ML AR(1)
  likelihood). No MATLAB runtime was available, so run `runSigtoolsTests` once
  locally as the final confirmation.
