classdef spec2acvTest < matlab.unittest.TestCase
%SPEC2ACVTEST  Analytic validation suite for SPEC2ACV.
%   Run with:  results = runtests("spec2acvTest")

methods (Test)

    function varianceIdentity(tc)
        % R(0) == trapz(f,S) without smoothing/taper (direct: exact)
        f = (0:0.1:500)';  S = 1./(1 + (f/40).^4);
        [R, ~, nfo] = spec2acv(f, S, Method="direct");
        % R(0) via the direct (NUFFT) cosine transform is accurate to the
        % NUFFT tolerance (~1e-12 rel); nfo.varIn is the exact trapz.
        tc.verifyEqual(R(1), trapz(f, S), RelTol=1e-9);
        tc.verifyEqual(nfo.varIn, trapz(f, S), RelTol=1e-12);
    end

    function bandlimitedWhite(tc)
        % S = S0 for f <= B  <->  R(tau) = S0*sin(2*pi*B*tau)/(2*pi*tau)
        B = 100; S0 = 2; df = 0.05;
        f = (0:df:400)';  S = S0*(f <= B);
        [R, tau] = spec2acv(f, S, Method="direct");
        Ra = S0*sin(2*pi*B*tau)./(2*pi*tau);  Ra(1) = S0*B;
        tc.verifyLessThan(max(abs(R - Ra)), 5e-3*Ra(1));
    end

    function lorentzianExponential(tc)
        % G(f) = 4*a*s2/(a^2 + (2*pi*f)^2)  <->  R(tau) = s2*exp(-a*tau)
        a = 5; s2 = 3; df = 0.1;
        f = (0:df:2000)';  G = 4*a*s2 ./ (a^2 + (2*pi*f).^2);
        [R, tau] = spec2acv(f, G);
        m = tau <= 0.5;
        tc.verifyLessThan(max(abs(R(m) - s2*exp(-a*tau(m)))), 1e-3*s2);
    end

    function gaussianPair(tc)
        % R(tau) = s2*exp(-tau^2/(2*tc^2)) <-> G = 2*s2*sqrt(2*pi)*tc*exp(-2*pi^2*f^2*tc^2)
        tcorr = 0.01; s2 = 3; df = 0.5;
        f = (0:df:200)';
        G = 2*s2*sqrt(2*pi)*tcorr*exp(-2*pi^2*f.^2*tcorr^2);
        [R, tau] = spec2acv(f, G);
        m = tau <= 0.1;
        tc.verifyLessThan(max(abs(R(m) - s2*exp(-tau(m).^2/(2*tcorr^2)))), 1e-6*s2);
    end

    function asdEqualsSquaredPsd(tc)
        f = (0:0.1:500)';  A = 1./(1 + (f/40).^2);
        R1 = spec2acv(f, A, InputType="asd");
        R2 = spec2acv(f, A.^2);
        tc.verifyEqual(R1, R2, AbsTol=1e-12);
    end

    function acfIsUnitAtZero(tc)
        f = (0:0.1:500)';  S = 1./(1 + (f/40).^4);
        R = spec2acv(f, S, Output="acf", Window="cosine");
        tc.verifyEqual(R(1), 1, AbsTol=1e-10);
        tc.verifyLessThanOrEqual(max(abs(R)), 1 + 1e-8);
    end

    function twoSidedEqualsOneSided(tc)
        a = 5; s2 = 3; df = 0.1; fmax = 1000;
        f2 = (-fmax:df:fmax)';                 % two-sided Lorentzian
        S2 = 2*a*s2 ./ (a^2 + (2*pi*f2).^2);
        f1 = (0:df:fmax)';
        G1 = 4*a*s2 ./ (a^2 + (2*pi*f1).^2);
        Ra = spec2acv(f2, S2, Sided="two");
        Rb = spec2acv(f1, G1);
        tc.verifyEqual(Ra, Rb, RelTol=1e-9, AbsTol=1e-12);
    end

    function logGridResampling(tc)
        % log-spaced Lorentzian must reproduce the uniform-grid result
        a = 5; s2 = 3;
        % Log grid must span the Lorentzian's support: it has ~0.8% of its
        % variance below 0.01 Hz, so start the grid at 1e-4 (else R(0) is
        % biased low by the unrepresented near-DC band, not a spec2acv bug).
        fl = logspace(-4, 3, 600)';
        Gl = 4*a*s2 ./ (a^2 + (2*pi*fl).^2);
        [Rl, tl, nfo] = spec2acv(fl, Gl, MaxBins=2^20);
        tc.verifyTrue(nfo.resampled);
        tc.verifyEqual(nfo.resampleSpace, "loglog");
        m = tl <= 0.3;
        tc.verifyLessThan(max(abs(Rl(m) - s2*exp(-a*tl(m)))), 5e-3*s2);
    end

    function smoothingPreservesPower(tc)
        rng(1);
        f = (0:0.1:500)';
        S = (1./(1 + (f/40).^4)) .* (0.5 + rand(size(f)));   % noisy PSD
        for method = ["boxcar","triangle","cosine","gauss","octave"]
            [~, ~, nfo] = spec2acv(f, S, Smooth=method, SmoothWidth=2*(method~="octave") + (1/3)*(method=="octave"));
            tc.verifyEqual(nfo.varOut, nfo.varIn, ...
                "Power not preserved for Smooth=" + method, RelTol=0.05);
        end
    end

    function octaveSmoothingIsRelativeBandwidth(tc)
        % a 1/f^2 spectrum is invariant in shape under octave smoothing
        f = (0:0.05:1000)';  S = 1./max(f, 1).^2;
        [~, ~, n0] = spec2acv(f, S);
        [~, ~, n1] = spec2acv(f, S, Smooth="octave", SmoothWidth=1/3);
        tc.verifyEqual(n1.varOut, n0.varOut, RelTol=0.02);
    end

    function directMatchesIfft(tc)
        f = (0:0.1:500)';  S = 1./(1 + (f/40).^4);
        [Ri, ti] = spec2acv(f, S, Method="ifft");
        [Rd, td] = spec2acv(f, S, Method="direct");
        tc.verifyEqual(td, ti, AbsTol=1e-12);
        tc.verifyEqual(Rd, Ri, RelTol=1e-8, AbsTol=1e-10*max(abs(Ri)));
    end

    function customLags(tc)
        a = 5; s2 = 3; df = 0.1;
        f = (0:df:2000)';  G = 4*a*s2 ./ (a^2 + (2*pi*f).^2);
        tau = (0:1e-4:0.2)';                   % lag grid unrelated to 1/(2*fNyq)
        R = spec2acv(f, G, Method="direct", Lags=tau);
        tc.verifyLessThan(max(abs(R - s2*exp(-a*tau))), 1e-3*s2);
    end

    function interpFactorExtendsLags(tc)
        f = (0:0.5:500)';  S = 1./(1 + (f/40).^4);
        [~, t1] = spec2acv(f, S);
        [~, t4] = spec2acv(f, S, InterpFactor=4);
        tc.verifyEqual(t4(end)/t1(end), 4, RelTol=1e-6);
    end

    function timescalesLorentzian(tc)
        % integral timescale of exp(-a*tau) is 1/a; 1/e time is 1/a
        a = 5; s2 = 3; df = 0.05;
        f = (0:df:2000)';  G = 4*a*s2 ./ (a^2 + (2*pi*f).^2);
        [~, ~, nfo] = spec2acv(f, G);
        tc.verifyEqual(nfo.tauDecorr, 1/a, RelTol=1e-2);
        tc.verifyEqual(nfo.integralTimescale, 1/a, RelTol=5e-2);
    end

    function uncertaintyBasics(tc)
        f = (0:0.1:500)';  S = 1./(1 + (f/40).^4);
        [R, ~, nfo] = spec2acv(f, S, DOF=32);
        tc.verifyNotEmpty(nfo.Rstd);
        tc.verifySize(nfo.Rstd, size(R));
        tc.verifyGreaterThan(nfo.Rstd(1), 0);
        % var R(0) = df^2 * sum(w^2 * 2 S^2/DOF): sanity vs 4x DOF
        [~, ~, nfo2] = spec2acv(f, S, DOF=128);
        tc.verifyEqual(nfo.Rstd(1)/nfo2.Rstd(1), 2, RelTol=1e-10);
        % smoothing must reduce the uncertainty
        [~, ~, nfoS] = spec2acv(f, S, DOF=32, Smooth="boxcar", SmoothWidth=2);
        tc.verifyLessThan(nfoS.Rstd(1), nfo.Rstd(1));
    end

    function nanRepair(tc)
        f = (0:0.1:500)';  S = 1./(1 + (f/40).^4);
        Sn = S; Sn(100:110) = NaN;
        [Rn, ~, nfo] = spec2acv(f, Sn);
        Rc = spec2acv(f, S);
        tc.verifyEqual(nfo.nBadBins, 11);
        tc.verifyEqual(Rn, Rc, RelTol=1e-3, AbsTol=1e-6*max(abs(Rc)));
        tc.verifyError(@() spec2acv(f, Sn, NanPolicy="error"), "spec2acv:badBins");
    end

    function unsortedAndDuplicates(tc)
        f = (0:0.1:500)';  S = 1./(1 + (f/40).^4);
        idx = randperm(numel(f));
        R1 = spec2acv(f(idx), S(idx));         % shuffled
        R2 = spec2acv([f; f(50)], [S; S(50)]); % duplicate bin
        Rc = spec2acv(f, S);
        tc.verifyEqual(R1, Rc, AbsTol=1e-12);
        tc.verifyEqual(R2, Rc, AbsTol=1e-12);
    end

    function singlePrecisionPassesThrough(tc)
        f = single((0:0.1:500)');  S = single(1./(1 + (f/40).^4));
        R = spec2acv(f, S);
        tc.verifyClass(R, "single");
    end

end
end
